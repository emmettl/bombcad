"""Final test-only cleanup-race extension on Linux with the unchanged final production helper."""
import subprocess,tarfile,io,uuid,json,hashlib
from pathlib import Path
root=Path('/private/tmp/bombcad-source-reuse');control='bombcad-sweeps/controls/'+uuid.uuid4().hex
files=['Scripts/remote-sweep.py','Scripts/test-remote-sweep.py','Scripts/ml/remote-train.py'];data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w') as archive:
 for name in files:archive.add(name,arcname=name,recursive=False)
command='mkdir -p '+control+' && tar -xf - -C '+control+' && cd '+control+' && python3 Scripts/test-remote-sweep.py'
p=subprocess.run(['ssh','bombcad-pc',command],input=data.getvalue(),stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(root/'linux-cleanup-race-controls.log').write_bytes(p.stdout);assert p.returncode==0
report=dict(status='complete',controlRoot=control,productionRunnerSHA256=hashlib.sha256(Path(files[0]).read_bytes()).hexdigest(),testsSHA256=hashlib.sha256(Path(files[1]).read_bytes()).hexdigest(),controlsPassed=23,cleanupDuringBasisLinkPreparationExercised=True)
(root/'cleanup-race-controls.json').write_text(json.dumps(report,indent=2)+'\n')
