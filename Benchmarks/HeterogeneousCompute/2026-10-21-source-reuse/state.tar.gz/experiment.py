"""Bounded source-transfer reuse and real CPU lanes; no GPU speed claim."""
import importlib.util,json,hashlib,os,subprocess,time,uuid,shutil
from pathlib import Path
root=Path('/private/tmp/bombcad-source-reuse');repo=Path.cwd()
spec=importlib.util.spec_from_file_location('sweep',repo/'Scripts/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
report=dict(status='running',baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),commands=[],invocations=[])
def save():(root/'study.json').write_text(json.dumps(report,indent=2)+'\n')
def command(args,label,input=None,expected=0):
 p=subprocess.Popen(args,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
 report['liveProcess']=dict(pid=p.pid,label=label,command=args);save();out,_=p.communicate(input);(root/(label+'.log')).write_bytes(out)
 report['commands'].append(dict(label=label,returncode=p.returncode));report.pop('liveProcess',None);save();assert p.returncode==expected,(label,p.returncode,out[-2000:]);return out

def remote(code,label):return command(['ssh','bombcad-pc','python3 -'],label,code.encode())
def transfer(options,label):
 report['invocations'].append(options);save()
 # Keep raw rsync stats and controller logs together, with explicit live process ownership.
 helper=root/(label+'-controller.py');helper.write_text('import importlib.util,json\n'+f"spec=importlib.util.spec_from_file_location('s', {str(repo/'Scripts/remote-sweep.py')!r});s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);s.REPO={str(root/'source')!r}\n"+f"raise SystemExit(s.send_worktree('bombcad-pc',lambda x:print(x,flush=True),json.loads({json.dumps(options)!r})))\n")
 command(['python3',str(helper)],label)
def worker(options,label):
 command(['ssh','-tt','-q','bombcad-pc',f"python3 {s.invocation_path(options['invocation'])}/tools/remote-sweep.py serve-{options['kind']} "+__import__('shlex').quote(json.dumps(options))],label)
try:
 save();frozen=root/'source';frozen.mkdir()
 command(['rsync','-a',*sum((['--exclude',x] for x in sorted(s.EXCLUDED)),[]),str(repo)+'/',str(frozen)+'/'],'freeze')
 control=frozen/'Benchmarks/source-reuse-control';control.mkdir()
 (control/'large.bin').write_bytes(bytes(range(256))*16384);(control/'edit.txt').write_text('A');(control/'mode.txt').write_text('mode')
 for p in control.iterdir():os.utime(p,(1700000000,1700000000))
 full=uuid.uuid4().hex;report['fullReference']=full;save()
 command(['ssh','bombcad-pc',f'mkdir -p bombcad-sweeps/staging/{full}/src'],'full-mkdir')
 command(['rsync','-a','--checksum','--stats','-e','ssh',str(frozen)+'/',f'bombcad-pc:bombcad-sweeps/staging/{full}/src/'],'full-transfer')
 def test_options():return dict(kind='test',invocation=uuid.uuid4().hex,host='bombcad-pc',cores=8,wait=0,suites=['ReceiverLoadStudyTests'])
 a=test_options();transfer(a,'a-transfer');worker(a,'a-test')
 (control/'edit.txt').write_text('B');os.utime(control/'edit.txt',(1700000000,1700000000));(control/'mode.txt').chmod(0o700)
 b=test_options();transfer(b,'b-transfer');worker(b,'b-test');worker(b,'b-cached-test')
 data=root/'dist';(data/'__pycache__').mkdir(parents=True)
 fixture=Path('/Volumes/StudioData/bombcad/experiments/2026-10-21-receiver-fixtures/input-0.0001.json');shutil.copy2(fixture,data/'__pycache__/input.json')
 plan=dict(name='source-reuse-20261021',inputs=[str(data)],cases=[dict(name='fixtures',args=['receiver-fixtures','--input',str(data/'__pycache__/input.json'),'--out','{out}/dist/__pycache__/results.json'])])
 c=dict(kind='run',invocation=uuid.uuid4().hex,host='bombcad-pc',cores=8,wait=0,sweep=plan)
 transfer(c,'c-transfer');worker(c,'c-run');worker(c,'c-cached-run')
 destination=root/'retrieved';assert s.retrieve('bombcad-pc',c,str(destination),0,print)==0
 expected=Path('/Volumes/StudioData/bombcad/experiments/2026-10-21-receiver-fixtures/results/receiver-fixtures-20261021-bombcad-pc/bin-0.0001/results.json')
 assert json.loads((destination/'fixtures/dist/__pycache__/results.json').read_text())==json.loads(expected.read_text())
 report['matchesPreviousCPUStudy']=True
 ids=[x['invocation'] for x in [a,b,c]]
 audit='''import json,hashlib,os,importlib.util
from pathlib import Path
ids=IDS
base=Path('bombcad-sweeps/staging');stages=[base/x for x in ids]
spec=importlib.util.spec_from_file_location('s',stages[-1]/'tools/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
for p in stages:
 m=json.loads((p/'manifest.json').read_text());assert s.tree_manifest(p/'src',s.EXCLUDED)==m['src'];assert json.loads((p/'completion.json').read_text())['exitCode']==0
files=[p/'src/Benchmarks/source-reuse-control' for p in stages]
assert [p.joinpath('edit.txt').read_text() for p in files]==['A','B','B']
assert [p.joinpath('mode.txt').stat().st_mode&0o777 for p in files]==[0o644,0o700,0o700]
assert len({p.joinpath('large.bin').stat().st_ino for p in files})==1
assert files[0].joinpath('mode.txt').stat().st_ino!=files[1].joinpath('mode.txt').stat().st_ino
assert files[1].joinpath('mode.txt').stat().st_ino==files[2].joinpath('mode.txt').stat().st_ino
records=[]
for p in stages:
 m=json.loads((p/'manifest.json').read_text())['src'];paths=[p/'src'/name for name,r in m.items() if 'sha256' in r];records.append(dict(invocation=p.name,regularBytes=sum(q.stat().st_size for q in paths),sharedBytes=sum(q.stat().st_size for q in paths if q.stat().st_nlink>1)))
print(json.dumps(dict(status='complete',stagedSourcesVerified=True,unchangedLargeInodeShared=True,modeAndSameMetadataByteEditsIsolated=True,records=records),indent=2))
'''.replace('IDS',repr(ids))
 result=remote(audit,'remote-audit');report['audit']=json.loads(result)
 command(['ssh','bombcad-pc',f'cd {s.invocation_path(c["invocation"])}/src && python3 Scripts/test-remote-sweep.py'],'linux-controls')
 report['status']='complete';save();print(json.dumps(report,indent=2))
except BaseException as error:
 report.update(status='failed',error=repr(error));save();raise
