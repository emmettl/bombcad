"""Finish the retained study after correcting only the unsupported nested fixture output path."""
import importlib.util,json,subprocess,uuid,hashlib
from pathlib import Path
root=Path('/private/tmp/bombcad-source-reuse');repo=Path.cwd()
spec=importlib.util.spec_from_file_location('s',repo/'Scripts/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
r=json.loads((root/'study.json').read_text());(root/'study-first-attempt.json').write_text(json.dumps(r,indent=2)+'\n');r['status']='running';r['failedAttemptPreserved']=r.pop('error');r['finalRunnerSHA256']=hashlib.sha256((repo/'Scripts/remote-sweep.py').read_bytes()).hexdigest()
def save():(root/'study.json').write_text(json.dumps(r,indent=2)+'\n')
def call(label,fn,expected=0):
 print(label,flush=True);r['activeOperation']=label;save();code=fn();r['commands'].append(dict(label=label,returncode=code));r.pop('activeOperation',None);save();assert code==expected,(label,code)
try:
 failed=r['invocations'][-1];call('cached-failed-run',lambda:s.remote_worker('bombcad-pc',failed),1)
 plan=json.loads(json.dumps(failed['sweep']));plan['cases'][0]['args'][-1]='{out}/results.json'
 d=dict(failed,invocation=uuid.uuid4().hex,sweep=plan);r['invocations'].append(d);save()
 call('d-final-transfer',lambda:s.send_worktree('bombcad-pc',lambda x:print(x,flush=True),d))
 call('d-final-run',lambda:s.remote_worker('bombcad-pc',d));call('d-final-cached-run',lambda:s.remote_worker('bombcad-pc',d))
 call('d-retrieve',lambda:s.retrieve('bombcad-pc',d,str(root/'retrieved'),0,print))
 expected=Path('/Volumes/StudioData/bombcad/experiments/2026-10-21-receiver-fixtures/results/receiver-fixtures-20261021-bombcad-pc/bin-0.0001/results.json')
 assert json.loads((root/'retrieved/fixtures/results.json').read_text())==json.loads(expected.read_text());r['matchesPreviousCPUStudy']=True
 e=dict(kind='test',invocation=uuid.uuid4().hex,host='bombcad-pc',cores=8,wait=0,suites=['ReceiverLoadStudyTests']);r['invocations'].append(e);save()
 call('e-final-transfer',lambda:s.send_worktree('bombcad-pc',lambda x:print(x,flush=True),e));call('e-final-test',lambda:s.remote_worker('bombcad-pc',e));call('e-final-cached-test',lambda:s.remote_worker('bombcad-pc',e))
 with (root/'linux-final-controls.log').open('wb') as out:
  call('linux-final-controls',lambda:subprocess.run(['ssh','bombcad-pc',f'cd {s.invocation_path(e["invocation"])}/src && python3 Scripts/test-remote-sweep.py'],stdout=out,stderr=subprocess.STDOUT).returncode)
 r['status']='complete';save()
except BaseException as error:
 r['status']='failed';r['error']=repr(error);save();raise
