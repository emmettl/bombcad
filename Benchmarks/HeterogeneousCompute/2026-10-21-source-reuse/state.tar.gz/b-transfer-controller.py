import importlib.util,json
spec=importlib.util.spec_from_file_location('s', '/Users/louisemmett/Developer/Projects/bombcad/Scripts/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);s.REPO='/private/tmp/bombcad-source-reuse/source'
raise SystemExit(s.send_worktree('bombcad-pc',lambda x:print(x,flush=True),json.loads('{"kind": "test", "invocation": "71a8316249904bd284b9f1ededfea2c9", "host": "bombcad-pc", "cores": 8, "wait": 0, "suites": ["ReceiverLoadStudyTests"]}')))
