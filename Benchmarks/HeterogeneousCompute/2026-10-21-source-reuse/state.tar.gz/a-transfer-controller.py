import importlib.util,json
spec=importlib.util.spec_from_file_location('s', '/Users/louisemmett/Developer/Projects/bombcad/Scripts/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);s.REPO='/private/tmp/bombcad-source-reuse/source'
raise SystemExit(s.send_worktree('bombcad-pc',lambda x:print(x,flush=True),json.loads('{"kind": "test", "invocation": "f0c7674f83f04fea800d79abb2f6c698", "host": "bombcad-pc", "cores": 8, "wait": 0, "suites": ["ReceiverLoadStudyTests"]}')))
