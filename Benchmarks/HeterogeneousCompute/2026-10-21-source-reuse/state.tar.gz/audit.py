"""Read-only source/result identity and Linux inode audit of all five retained invocations."""
from pathlib import Path
import json,subprocess
root=Path('/private/tmp/bombcad-source-reuse');r=json.loads((root/'study.json').read_text());assert r['status']=='complete'
ids=[x['invocation'] for x in r['invocations']]
code='''import json,importlib.util,os
from pathlib import Path
ids=IDS
base=Path('bombcad-sweeps/staging');stages=[base/x for x in ids]
spec=importlib.util.spec_from_file_location('s',stages[-1]/'tools/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
records=[]
for p in stages:
 options=json.loads((p/'request.json').read_text());_,m=s.verify_snapshot(options);receipt=json.loads((p/'completion.json').read_text());assert receipt['exitCode']==(1 if p==stages[2] else 0)
 if options['kind']=='run':assert s.tree_manifest(p/'results')==receipt['results']
 paths=[p/'src'/name for name,v in m['src'].items() if 'sha256' in v]
 records.append(dict(invocation=p.name,exitCode=receipt['exitCode'],regularBytes=sum(q.stat().st_size for q in paths),sharedBytes=sum(q.stat().st_size for q in paths if q.stat().st_nlink>1),runnerSHA256=m['tools']['remote-sweep.py']['sha256']))
files=[p/'src/Benchmarks/source-reuse-control' for p in stages[:3]]
assert [p.joinpath('edit.txt').read_text() for p in files]==['A','B','B']
assert [p.joinpath('mode.txt').stat().st_mode&0o777 for p in files]==[0o644,0o700,0o700]
assert len({p.joinpath('large.bin').stat().st_ino for p in files})==1
assert files[0].joinpath('mode.txt').stat().st_ino!=files[1].joinpath('mode.txt').stat().st_ino
assert files[1].joinpath('mode.txt').stat().st_ino==files[2].joinpath('mode.txt').stat().st_ino
unique={}
for p in stages[:3]:
 for name,v in json.loads((p/'manifest.json').read_text())['src'].items():
  if 'sha256' in v:
   q=p/'src'/name;stat=q.stat();unique[(stat.st_dev,stat.st_ino)]=(stat.st_size,stat.st_blocks*512)
last=json.loads((stages[-1]/'manifest.json').read_text())['src'];cache=Path('bombcad-sweeps/src')
common=[name for name,v in last.items() if 'sha256' in v and (cache/name).is_file()]
sample=max(common,key=lambda name:(cache/name).stat().st_size)
assert (cache/sample).stat().st_ino!=(stages[-1]/'src'/sample).stat().st_ino
assert s.file_record(cache/sample)==last[sample]
print(json.dumps(dict(status='complete',allSnapshotsAndResultsVerified=True,unchangedLargeInodeShared=True,modeAndSameMetadataEditsIsolated=True,oldSnapshotsUnchangedAfterFinalBuilds=True,cacheSampleIndependent=sample,threeSourceLogicalBytes=sum(x['regularBytes'] for x in records[:3]),uniqueSourceInodeLogicalBytes=sum(v[0] for v in unique.values()),uniqueSourceInodeAllocatedBytes=sum(v[1] for v in unique.values()),records=records),indent=2))
'''.replace('IDS',repr(ids))
(root/'remote-audit.py').write_text(code)
result=subprocess.check_output(['ssh','bombcad-pc','python3 -'],input=code.encode());(root/'remote-audit.json').write_bytes(result);print(result.decode())
args=['tar','-czf','-','-C','bombcad-sweeps/staging']
for ident in ids:
 for name in ['manifest.json','request.json','started.json','completion.json']:args.append(ident+'/'+name)
with (root/'stage-receipts.tar.gz').open('wb') as out:subprocess.run(['ssh','bombcad-pc',*args],stdout=out,check=True)
