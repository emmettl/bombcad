"""Isolated reproduction of direct link-dest permission behavior; no production stage touched."""
import json,os,subprocess,tempfile
from pathlib import Path
with tempfile.TemporaryDirectory() as folder:
 root=Path(folder);source=root/'source';basis=root/'basis';destination=root/'destination'
 for p in [source,basis,destination]:p.mkdir()
 (source/'mode').write_text('mode');(source/'mode').chmod(0o644)
 subprocess.run(['rsync','-a',str(source)+'/',str(basis)+'/'],check=True)
 (source/'mode').chmod(0o700)
 subprocess.run(['rsync','-a','--checksum','--link-dest='+str(basis),str(source)+'/',str(destination)+'/'],check=True)
 print(json.dumps(dict(sourceMode=(source/'mode').stat().st_mode&0o777,basisMode=(basis/'mode').stat().st_mode&0o777,destinationMode=(destination/'mode').stat().st_mode&0o777,sharedInode=(basis/'mode').stat().st_ino==(destination/'mode').stat().st_ino,version=subprocess.check_output(['rsync','--version'],text=True).strip()),indent=2))
