from pathlib import Path
import subprocess,json
root=Path('/private/tmp/bombcad-source-reuse');r=json.loads((root/'study.json').read_text());a=r['invocations'][0]['invocation'];last=r['invocations'][-1]['invocation'];full=r['fullReference']
code=f'''import importlib.util,json,hashlib
from pathlib import Path
base=Path('bombcad-sweeps/staging');spec=importlib.util.spec_from_file_location('s',base/{last!r}/'tools/remote-sweep.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
expected=json.loads((base/{a!r}/'manifest.json').read_text())['src'];actual=s.tree_manifest(base/{full!r}/'src',s.EXCLUDED);assert actual==expected
print(json.dumps(dict(status='complete',fullTransferSourceMatchesA=True,fullReference={full!r},sourceManifestSHA256=hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest()),indent=2))
'''
(root/'baseline-audit.json').write_bytes(subprocess.check_output(['ssh','bombcad-pc','python3 -'],input=code.encode()))
