"""Sequential bounded measured phases; never restart a completed/partial phase automatically."""
from pathlib import Path
import json,subprocess,sys,os
root=Path(__file__).resolve().parent
phases=[('full64',['supervise.py','full64','block64.py','flat512','beirut512']),('full256',['supervise.py','full256','block256.py','flat512','beirut512']),('null-small',['supervise.py','null-small','baseline.py','blast64','cooling32','cooling64','terrain256']),('null-districts',['supervise.py','null-districts','baseline.py','flat512','beirut512']),('diagnostic',['diagnose.py'])]
assert not (root/'campaign.json').exists(),'campaign state exists; observe its handle, do not restart'
assert all(not (root/name).exists() for name,_ in phases),'phase output exists; do not overwrite'
r=dict(status='running',pid=os.getpid(),pgid=os.getpgrp(),phases=[])
def save():(root/'campaign.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for label,args in phases:
 cmd=[sys.executable,str(root/args[0]),*args[1:]]
 with (root/(label+'-supervisor.log')).open('wb') as out:
  p=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);r['liveProcess']=dict(label=label,pid=p.pid,pgid=p.pid,command=cmd);save();code=p.wait()
 r['phases'].append(dict(label=label,returncode=code));r.pop('liveProcess',None);save()
 if code==0 and label!='diagnostic':
  monitor=json.loads((root/(label+'-state.json')).read_text())
  if monitor['externalComputeGroupObserved']:r['externalObservation']=label;code=1
 if code:
  r.update(status='failed',returncode=code);save();raise SystemExit(code)
r.update(status='complete',returncode=0);save();print(json.dumps(r,indent=2))
