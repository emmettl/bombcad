"""Perturbed real-driver launch geometry, tail/axis/startup and failure controls; no timing claims."""
from pathlib import Path
import json,hashlib,importlib.util,ctypes as C,math,sys
from unittest.mock import patch
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root))
def module(name):
 spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(path):return {str(p.relative_to(path)):digest(p) for p in path.rglob('*') if p.is_file() and p.suffix in ('.bin','.npy')}
lock=module('remote-train');lockpath=str(Path.home()/'bombcad-ml/lock')
if not lock.acquire(lockpath,'launch geometry and tail/failure controls',lock.boot_id()):raise SystemExit('GPU held')
try:
 import torch,numpy as np
 torch.cuda.init();out=root/'diagnostic';out.mkdir();workers={name:module(name) for name in ['baseline','block64','block256']};sizes={'baseline':128,'block64':64,'block256':256};real_cdll=C.CDLL
 all_geometry=[]
 def execute(name,job,destination):
  meta=json.loads((job/'job.json').read_text());nx,ny,nz=meta['shape'];counts={};functions={}
  class Driver:
   def __init__(self,driver):self.driver=driver
   def __getattr__(self,key):return getattr(self.driver,key)
   def cuModuleGetFunction(self,pointer,mod,kernel):
    result=self.driver.cuModuleGetFunction(pointer,mod,kernel)
    if result==0:functions[C.cast(pointer,C.POINTER(C.c_void_p)).contents.value]=kernel.decode()
    return result
   def cuLaunchKernel(self,*args):
    kernel=functions[args[0].value];geometry=tuple(int(x) for x in args[1:8]);count=nx*ny if kernel=='cudaFirstPhase' else 1 if kernel in ['cudaPrepare','cudaCoolingClock','cudaCoolingReset'] else meta['terrain']['cutColumnCount'] if kernel=='cudaRedistribute' else nx*ny*nz
    assert geometry==((count+sizes[name]-1)//sizes[name],1,1,sizes[name],1,1,0),(kernel,geometry,count)
    key=(kernel,count,geometry);counts[key]=counts.get(key,0)+1
    return self.driver.cuLaunchKernel(*args)
  def library(path,*args,**kwargs):
   driver=real_cdll(path,*args,**kwargs);return Driver(driver) if str(path)=='libcuda.so.1' else driver
  error=None;r=None
  with patch.object(C,'CDLL',side_effect=library):
   try:r=workers[name].run(job,root/'solver.cu',destination,cache_dir=Path.home()/'bombcad-cuda/ptx-cache')
   except RuntimeError as failure:error=str(failure)
  geometry=[dict(kernel=k,usefulCount=count,grid=list(g[:3]),block=list(g[3:6]),dynamicSharedBytes=g[6],launches=number) for (k,count,g),number in sorted(counts.items())]
  all_geometry.append(dict(worker=name,job=job.name,geometry=geometry))
  return r,error
 pairs=[]
 for case in ['blast64','cooling32','terrain256']:
  rows=[]
  for name in workers:
   dest=out/(case+'-'+name);r,error=execute(name,root/case,dest);assert error is None,error;rows.append(dict(worker=name,steps=r['steps'],hashes=hashes(dest),resultSHA256=digest(dest/'result.json')))
  assert all(r['hashes']==rows[0]['hashes'] for r in rows);pairs.append(dict(case=case,rows=rows))
 for name in workers:
  seen={g['kernel'] for record in all_geometry if record['worker']==name for g in record['geometry']};assert len(seen)==10,(name,seen)
 failures=[]
 for case in ['step-limit','nonphysical']:
  job=out/case;job.mkdir();meta=json.loads((root/'blast64/job.json').read_text());meta['startupSteps']=1
  for f in (root/'blast64').iterdir():
   if f.name!='job.json' and not(case=='nonphysical' and f.name=='state.bin'):(job/f.name).symlink_to(f.resolve())
  if case=='step-limit':meta['steps']=1
  else:
   state=np.frombuffer((root/'blast64/state.bin').read_bytes(),dtype='<f4').copy().reshape(-1,5);state[0,0]=np.float32(1e-5);state[0,4]=np.float32(3e38);state.tofile(job/'state.bin');meta['files']['state.bin']=digest(job/'state.bin')
  (job/'job.json').write_text(json.dumps(meta,indent=2)+'\n')
  for name in workers:
   dest=out/(case+'-'+name);r,error=execute(name,job,dest);expected='step limit reached before duration' if case=='step-limit' else 'nonphysical wave speed';assert r is None and expected in error and not dest.exists();failures.append(dict(worker=name,case=case,error=error,noOutputWritten=True))
 tail=[];source=root/'blast64';old=json.loads((source/'job.json').read_text());n=old['shape'][0];k=31
 for case,shape,start in [('cube-tail',[k,k,k],0),('two-axes-tail',[k,k,1],0),('one-axis-odd-tail',[k,1,1],1)]:
  job=out/case;job.mkdir();meta=json.loads(json.dumps(old));meta.update(shape=shape,axes=[i for i,v in enumerate(shape) if v>1],above=0,startStep=start,startupSteps=8)
  specs={'state.bin':('<f4',5),'species.bin':('<f4',2),'mask.bin':('u1',1),'peak.bin':('<f4',1),'impulse.bin':('<f4',1)}
  for file,(dtype,width) in specs.items():
   a=np.frombuffer((source/file).read_bytes(),dtype=dtype).reshape(n,n,n,width);z=slice(0,k) if shape[2]>1 else slice(n//2,n//2+1);y=slice(0,k) if shape[1]>1 else slice(n//2,n//2+1);a[z,y,:k,:].copy().tofile(job/file)
  plan=shape[0]*shape[1];np.tile(np.array([0,0,0,1],dtype='<f4'),(plan,1)).tofile(job/'columns.bin');np.zeros((plan,4),dtype='<f4').tofile(job/'records.bin');np.zeros(plan,dtype='<f4').tofile(job/'open.bin')
  meta['files']={f.name:digest(f) for f in job.iterdir()};(job/'job.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
  for name in workers:
   dest=out/(case+'-'+name);r,error=execute(name,job,dest);assert error is None,error;rows.append(dict(worker=name,steps=r['steps'],hashes=hashes(dest),resultSHA256=digest(dest/'result.json')))
  assert all(r['hashes']==rows[0]['hashes'] for r in rows);tail.append(dict(case=case,shape=shape,startStep=start,startupSteps=8,rows=rows))
 result=dict(status='complete',scope=__doc__,allOutputsAndTimestepsBitIdentical=True,allTenEntriesGeometryCheckedForAllSizes=True,normal=pairs,failures=failures,tail=tail,launchGeometry=all_geometry)
 (out/'diagnostic.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='complete',successes=sum(len(c['rows']) for c in pairs+tail),failures=len(failures),tailCases=[c['case'] for c in tail]),indent=2))
finally:lock.release(lockpath)
