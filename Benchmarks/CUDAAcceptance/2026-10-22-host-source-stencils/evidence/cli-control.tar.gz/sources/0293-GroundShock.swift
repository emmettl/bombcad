import Foundation
import simd

/// The soil under the ground points: one uniform layer, as deep as it needs to be.
public struct GroundSoil: Codable, Sendable, Equatable {
    /// Bulk density, kg/m³.
    public var density: Float = 1600
    /// The speed of a compression wave loading the soil (its seismic, or loading, wave speed), m/s.
    public var waveSpeed: Float = 300

    public init(density: Float = 1600, waveSpeed: Float = 300) {
        self.density = density
        self.waveSpeed = waveSpeed
    }

    private enum CodingKeys: String, CodingKey {
        case density, waveSpeed
    }

    /// Either field left out takes its default.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = GroundSoil()
        density = try c.decodeIfPresent(Float.self, forKey: .density) ?? d.density
        waveSpeed = try c.decodeIfPresent(Float.self, forKey: .waveSpeed) ?? d.waveSpeed
    }

    /// The soil's acoustic impedance ρc, Pa·s/m: the stress that moves it at a metre a second.
    public var impedance: Float { density * waveSpeed }
}

/// How the ground's shaking under each point is reckoned.
public enum GroundShockModel: String, Codable, Sendable, CaseIterable {
    /// The protective design manuals' one-dimensional estimate from the peak and impulse on the
    /// ground, in uniform soil, worn down with depth by their empirical factor.
    case estimate
    /// A layered soil column under each point, solved step by step through the overpressure's
    /// history on the ground (`SoilColumn`).
    case column
    /// A layered elastic half-space about the charge, driven by the air's ground pressures
    /// averaged round rings centred on it and, inside the crater, by the charge's direct source
    /// (`HalfSpaceGroundShock`): waves that travel sideways and outrun the blast, vertical and
    /// radial motion.
    case halfspace
}

/// Where to estimate the ground's shaking under the blast, and in what soil. An illustrative
/// model, not a validated one: the one-dimensional air-induced ground shock of the protective
/// design manuals, or a layered soil column, driven by the overpressure the run records on the
/// ground.
public struct GroundShockSpec: Codable, Sendable, Equatable {
    /// Points along a straight line on the ground, ends included.
    public struct Line: Codable, Sendable, Equatable {
        public var from: SIMD2<Float>
        public var to: SIMD2<Float>
        public var count: Int

        public init(from: SIMD2<Float>, to: SIMD2<Float>, count: Int) {
            self.from = from
            self.to = to
            self.count = count
        }
    }

    /// The uniform soil of the manuals' estimate, and of the column where no profile is given.
    public var soil = GroundSoil()
    /// The manuals' estimate unless asked otherwise, as descriptions saved before the column were.
    public var model = GroundShockModel.estimate
    /// The column's layers; nil for one elastic layer of `soil` going on for ever.
    public var profile: SoilProfile?
    /// The half-space's axis and charge; nil for `BombCAD run` to set from the scene's charge.
    public var halfSpace: HalfSpaceSetup?
    /// Ground points, (x, y) in metres.
    public var points: [SIMD2<Float>] = []
    public var line: Line?
    /// Depths below each point at which to give the response, metres.
    public var depths: [Float] = [0, 1, 3]
    /// The overpressure, Pa, whose first passing marks the blast's arrival at a point.
    public var arrivalThreshold: Float = 1000
    /// Where the charge stands on the ground, (x, y) in metres, for when the ground's own wave
    /// from it reaches each point (`SoilProfile.firstArrival`); nil for `settingOrigin(from:)`
    /// to set from the scene, or for the regime to go by the air's front speed alone.
    public var origin: SIMD2<Float>?

    public init() {}

    private enum CodingKeys: String, CodingKey {
        case soil, model, profile, halfSpace, points, line, depths, arrivalThreshold, origin
    }

    /// With no origin given, the scene's charge's place on the ground.
    public func settingOrigin(from scenario: Scenario) -> GroundShockSpec {
        guard origin == nil else { return self }
        var spec = self
        spec.origin = SIMD2(scenario.charge.position.x, scenario.charge.position.y)
        return spec
    }

    /// Any field left out takes its default.
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = GroundShockSpec()
        soil = try c.decodeIfPresent(GroundSoil.self, forKey: .soil) ?? d.soil
        model = try c.decodeIfPresent(GroundShockModel.self, forKey: .model) ?? d.model
        profile = try c.decodeIfPresent(SoilProfile.self, forKey: .profile)
        halfSpace = try c.decodeIfPresent(HalfSpaceSetup.self, forKey: .halfSpace)
        points = try c.decodeIfPresent([SIMD2<Float>].self, forKey: .points) ?? d.points
        line = try c.decodeIfPresent(Line.self, forKey: .line)
        depths = try c.decodeIfPresent([Float].self, forKey: .depths) ?? d.depths
        arrivalThreshold = try c.decodeIfPresent(Float.self, forKey: .arrivalThreshold) ?? d.arrivalThreshold
        origin = try c.decodeIfPresent(SIMD2<Float>.self, forKey: .origin)
    }

    /// The column's soil: the profile, or one layer of `soil`.
    public var columnProfile: SoilProfile { profile ?? SoilProfile(uniform: soil) }

    /// The soil at the surface: the profile's top layer for the column, `soil` for the estimate.
    public var surfaceSoil: GroundSoil { model == .estimate ? soil : columnProfile.surface }

    /// The most elements a column may take, and the most element-steps a frame a millisecond
    /// long may cost over all the points, to keep the column light enough to run alongside.
    public static let columnElementLimit = 20_000
    public static let columnWorkLimit = 50_000_000

    /// The points given, then the line's.
    public var allPoints: [SIMD2<Float>] {
        guard let line else { return points }
        return points
            + (0..<line.count).map { n in
                line.from + (line.to - line.from) * Float(n) / Float(max(line.count - 1, 1))
            }
    }

    /// Soil, points and depths a run can handle; with `domain`, points within its ground.
    public func validate(domain: SIMD3<Float>? = nil) throws {
        let all = allPoints
        func finite(_ point: SIMD2<Float>) -> Bool { point.x.isFinite && point.y.isFinite }
        guard soil.density > 0, soil.density.isFinite, soil.waveSpeed > 0, soil.waveSpeed.isFinite,
            (1...10_000).contains(all.count), all.allSatisfy(finite),
            line.map({ (2...10_000).contains($0.count) }) ?? true,
            (1...32).contains(depths.count), depths.allSatisfy({ $0 >= 0 && $0 <= 1000 }),
            arrivalThreshold > 0, arrivalThreshold.isFinite, origin.map(finite) ?? true
        else {
            throw CocoaError(
                .coderInvalidValue,
                userInfo: [
                    NSLocalizedDescriptionKey: "The ground shock description is out of range or incomplete."
                ])
        }
        if model == .column {
            let column = SoilColumn(profile: columnProfile, depth: depths.max() ?? 0)
            guard columnProfile.isValid, column.elementCount <= Self.columnElementLimit,
                Double(column.elementCount * all.count) * 1e-3 / column.timeStep
                    <= Double(Self.columnWorkLimit)
            else {
                throw CocoaError(
                    .coderInvalidValue,
                    userInfo: [
                        NSLocalizedDescriptionKey:
                            "The ground shock's soil profile is out of range, or its columns too fine to run alongside."
                    ])
            }
        }
        if let domain,
            !all.allSatisfy({ $0.x >= 0 && $0.y >= 0 && $0.x <= domain.x && $0.y <= domain.y })
        {
            throw CocoaError(
                .coderInvalidValue,
                userInfo: [NSLocalizedDescriptionKey: "A ground shock point lies outside the domain."])
        }
    }
}

/// How the air's front sweeps over the ground against the soil's wave speed c.
public enum GroundShockRegime: String, Codable, Sendable {
    /// Faster than √2 c: the soil's wave trails the front at under 45° to the ground, the
    /// one-dimensional estimate holds and gives a horizontal motion no larger than the vertical.
    case superseismic
    /// Between c and √2 c: the soil's wave front stands steeply, and the plane-front estimate of
    /// horizontal motion grows without bound as the front slows to c; the vertical estimate is
    /// given, the horizontal left out.
    case transseismic
    /// Slower than c: the soil's wave runs ahead of the air's and shakes the ground before the
    /// blast arrives, which the model does not cover; the vertical estimate is given only as the
    /// air's share.
    case outrunning

    /// By arrival as well as by speed: outrunning wherever the ground's own wave from the charge
    /// (`groundArrival`, through the soil's faster layers below) comes before the air does
    /// (`arrival`), however fast the air's front then is; otherwise by the front's speed.
    public init(frontSpeed: Float, soil: GroundSoil, arrival: Double?, groundArrival: Double?) {
        if let arrival, let groundArrival, groundArrival < arrival {
            self = .outrunning
        } else {
            self.init(frontSpeed: frontSpeed, soil: soil)
        }
    }

    public init(frontSpeed: Float, soil: GroundSoil) {
        if frontSpeed >= soil.waveSpeed * Float(2).squareRoot() {
            self = .superseismic
        } else if frontSpeed > soil.waveSpeed {
            self = .transseismic
        } else {
            self = .outrunning
        }
    }
}

/// The ground's peak response at one depth below a point.
public struct GroundResponse: Codable, Sendable, Equatable {
    public var depth: Float
    /// Peak vertical stress, Pa.
    public var stress: Float
    /// Peak vertical particle velocity, m/s, downwards.
    public var verticalVelocity: Float
    /// Peak vertical displacement, m, downwards.
    public var verticalDisplacement: Float
    /// Peak horizontal particle velocity, m/s, away from the blast; nil unless the front is
    /// superseismic (see `GroundShockRegime`).
    public var horizontalVelocity: Float?
    /// When the stress wave reaches this depth, s; nil if the blast never reached the point.
    public var arrival: Double?
    /// The column's only: the downward displacement at the last frame, m, what the soil's
    /// compaction leaves once the wave has passed; and the downward velocity at each frame, m/s.
    public var residualDisplacement: Float?
    public var history: [Float]?
    /// The column's only: the peak downward and upward vertical acceleration, m/s², both positive.
    /// At the front it is the rebuilt load's rise over the soil's impedance, so it is only as
    /// fine as that rise: the solver's own shock, or twelve of the column's steps.
    public var verticalAcceleration: Float?
    public var upwardAcceleration: Float?

    public init(
        depth: Float, stress: Float, verticalVelocity: Float, verticalDisplacement: Float,
        horizontalVelocity: Float?, arrival: Double?, residualDisplacement: Float? = nil,
        history: [Float]? = nil, verticalAcceleration: Float? = nil, upwardAcceleration: Float? = nil
    ) {
        self.depth = depth
        self.stress = stress
        self.verticalVelocity = verticalVelocity
        self.verticalDisplacement = verticalDisplacement
        self.horizontalVelocity = horizontalVelocity
        self.arrival = arrival
        self.residualDisplacement = residualDisplacement
        self.history = history
        self.verticalAcceleration = verticalAcceleration
        self.upwardAcceleration = upwardAcceleration
    }
}

/// Air-induced ground shock as the protective design manuals estimate it, away from the charge
/// where the soil is driven only by the air pressing on it. Each point is a column of soil
/// loaded by a plane wave: a compression wave runs down at the soil's wave speed c carrying the
/// surface stress, so the particles move at σ/(ρc), and the column's top sinks by the impulse
/// over ρc. Real soil gives way more on unloading than on loading, which shaves the peak as the
/// wave goes down; the manuals' factor 1/(1 + z/(c t_d)) stands in for that. Where the air's
/// front sweeps over the ground well over c, the soil's wave trails behind it at an angle and
/// the particles also move outwards.
public enum AirInducedGroundShock {
    /// The duration, s, of the triangular pulse with the same peak and impulse: 2I/P.
    public static func duration(peak: Float, impulse: Float) -> Float {
        peak > 0 ? 2 * impulse / peak : 0
    }

    /// How much of the surface's peak stress reaches `depth` for a pulse lasting `duration`:
    /// 1/(1 + z/L), L = c t_d the pulse's length in the soil.
    public static func attenuation(depth: Float, soil: GroundSoil, duration: Float) -> Float {
        let length = soil.waveSpeed * duration
        guard depth > 0 else { return 1 }
        return length > 0 ? 1 / (1 + depth / length) : 0
    }

    /// The speed, m/s, of an air shock of `overpressure` (Pa) running into still air, by the
    /// Rankine–Hugoniot relations: c₀ √(1 + (γ+1)/(2γ) · P/p₀).
    public static func frontSpeed(
        overpressure: Float, ambientPressure: Float, ambientDensity: Float, gamma: Float
    ) -> Float {
        let sound = sqrt(gamma * ambientPressure / ambientDensity)
        return sound * sqrt(1 + (gamma + 1) / (2 * gamma) * max(overpressure, 0) / ambientPressure)
    }

    /// The horizontal velocity, m/s, of soil moving down at `vertical` where its loading wave
    /// speed is `waveSpeed`, under a front sweeping over the ground at `frontSpeed`: the soil's
    /// wave trails at θ, sin θ = c/U (Snell's law carries the front's horizontal slowness 1/U into
    /// every layer), and its particles move square to the front. Nil short of superseismic.
    public static func horizontalVelocity(vertical: Float, waveSpeed: Float, frontSpeed: Float) -> Float? {
        guard frontSpeed >= waveSpeed * Float(2).squareRoot() else { return nil }
        let sine = waveSpeed / frontSpeed
        return vertical * sine / sqrt(1 - sine * sine)
    }

    /// The response at `depth` to a surface overpressure with this peak (Pa), positive impulse
    /// (Pa·s) and arrival (s), its front sweeping over the ground at `frontSpeed` (m/s).
    public static func response(
        peak: Float, impulse: Float, arrival: Double?, depth: Float, soil: GroundSoil, frontSpeed: Float
    ) -> GroundResponse {
        guard peak > 0 else {
            return GroundResponse(
                depth: depth, stress: 0, verticalVelocity: 0, verticalDisplacement: 0,
                horizontalVelocity: 0, arrival: nil)
        }
        let alpha = attenuation(depth: depth, soil: soil, duration: duration(peak: peak, impulse: impulse))
        let stress = alpha * peak
        let vertical = stress / soil.impedance
        let horizontal = horizontalVelocity(
            vertical: vertical, waveSpeed: soil.waveSpeed, frontSpeed: frontSpeed)
        return GroundResponse(
            depth: depth, stress: stress, verticalVelocity: vertical,
            // An elastic column's top sinks by I/(ρc) at every depth: the unloading that shaves
            // the peak is left out here, so this is an upper value.
            verticalDisplacement: impulse / soil.impedance, horizontalVelocity: horizontal,
            arrival: arrival.map { $0 + Double(depth / soil.waveSpeed) })
    }
}
