import simd

/// A mesh of shells and beams for a structure whose solids are all walls, slabs and columns.
///
/// Each wall or slab becomes a plate of shells on its midsurface, and each column a line of
/// beams on its centreline. Their nodes lie on one grid shared by the whole structure, a set of
/// breakpoints along each axis, so that members that meet share the nodes where they meet and
/// are joined rigidly. A member that ends inside another (a wall under a slab, two walls at a
/// corner, a column under a slab, a panel between columns) is extended or shortened to end on
/// the other's midsurface or centreline.
package struct ShellMesh {
    /// Points through a wall's thickness, and along each side of a column, at which the base's
    /// connection is evaluated, from face to face (`ShellSolver.fibresAcross` is this).
    package static let fibresAcross = 9
    package struct Element {
        /// Corners in order around the element: (0, 0), (1, 0), (1, 1), (0, 1) in its own axes.
        package var nodes: SIMD4<UInt32>
        /// The axis through the thickness; the element's own axes are the next two, in order.
        package var axis: Int
        package var material: Int
        package var thickness: Float
        /// Side lengths along the element's first and second axes.
        package var size: SIMD2<Float>
        /// Bar layers: position through the thickness from -1 to 1, and bar area per unit width
        /// along the element's first and second axes.
        package var bars: [SIMD3<Float>]
        /// The solid it was made from.
        package var solid: Int
        /// The elements of the same plate beyond its edges at -first, +first, -second and +second,
        /// or -1 where there is none.
        package var neighbours = SIMD4<Int32>(repeating: -1)
    }

    package struct Beam {
        package var nodes: SIMD2<UInt32>
        /// The axis along the beam; its section's sides are along the next two, in order.
        package var axis: Int
        package var material: Int
        /// Sides of the section along the next two axes.
        package var section: SIMD2<Float>
        package var length: Float
        /// Bars along the beam: position across the section (-1 to 1 along each side) and area.
        package var bars: [SIMD3<Float>]
        /// Area of ties per unit area of concrete, for confinement.
        package var tieRatio: Float
        package var solid: Int
    }

    package var positions: [SIMD3<Float>] = []
    package var elements: [Element] = []
    package var beams: [Beam] = []
    /// Nodes tied rigidly to another: the slab nodes within a column's footprint, tied to the
    /// column's node where it meets the slab, so that the column bears on the slab over its whole
    /// section instead of at one point.
    package var ties: [(slave: UInt32, master: UInt32)] = []
    /// Where `StructureModel.tiesTouching` tied members that touch but shared no node: the two
    /// solids and the nodes tied.
    var contactTies: [(first: Int, second: Int, nodes: Int)] = []
    /// A fastened sheet's node and the beam's node it lies on (`StructureModel.sheetFastenings`):
    /// the sheet's normal axis and the way along it that pulls the sheet off the beam (+1 or -1),
    /// the beam's length the link stands for (m), and the fastening's index.
    package struct Link {
        package var sheet: UInt32
        package var beam: UInt32
        package var normal: Int
        package var off: Float
        package var length: Float
        package var fastening: Int
    }
    package var links: [Link] = []
    /// A steel beam's end held to the joint it stops at by a connection's springs
    /// (`StructureModel.steelConnection`): the beam's own end node and the joint's; the beam's
    /// axis, section and material, and its element's length.
    package struct Hinge {
        package var beamNode: UInt32
        package var jointNode: UInt32
        package var axis: Int
        package var section: SIMD2<Float>
        package var material: Int
        package var length: Float
    }

    package var hinges: [Hinge] = []
    /// For each element beside a column head, the mean shear stress through its thickness at
    /// which the connection punches (see `punchingStrength`); zero for the rest.
    package var punching: [Float] = []
    /// The ring of elements around each column head, which punches as one.
    package var punchingRings: [[Int]] = []
    /// Elements of a slab within two effective depths of a column's face, where the shear is
    /// two-way and punching, not the one-way strength of a section, decides it.
    package var punchingZone: [Bool] = []
    /// Breakpoints along each axis.
    var grid: [[Float]] = [[], [], []]

    /// Most bar layers an element can carry.
    static let maxBars = 4

    private struct Plate {
        var solid: Int
        var axis: Int
        var box: Box
        var thickness: Float
        /// Midsurface coordinate along `axis`.
        var mid: Float
        /// In-plane extents, after being made to end on the plates they meet.
        var low: SIMD3<Float>
        var high: SIMD3<Float>
    }

    private struct Column {
        var solid: Int
        var axis: Int
        var box: Box
        /// Centreline: the middle of the section, along the other two axes.
        var centre: SIMD3<Float>
        /// Ends along `axis`, after being made to end on the plates they meet.
        var low: Float
        var high: Float
    }

    /// Cover from a column's face to the centre of its corner bars.
    static let columnCover: Float = 0.04
    /// Most bar groups a beam can carry.
    package static let maxBeamBars = 8

    package init(model: StructureModel) throws {
        let size = model.elementSize
        let tolerance: Float = 1e-4
        var plates: [Plate] = []
        var columns: [Column] = []
        // Solids laid at a pitch are meshed in their own planes below; the walls under one that trims
        // lose their elements above it.
        var inclined: [(solid: Int, box: Box, inclination: Inclination)] = []
        for (index, box) in model.solids.enumerated() {
            guard let inclination = model.inclination(of: index) else { continue }
            try inclination.validate()
            inclined.append((index, box, inclination))
        }
        let trimmers = inclined.filter(\.inclination.trimsWalls)
        func trimmed(_ centre: SIMD3<Float>) -> Bool {
            trimmers.contains { trimmer in
                guard let height = trimmer.inclination.height(at: SIMD2(centre.x, centre.y), in: trimmer.box)
                else { return false }
                return centre.z > height + tolerance
            }
        }
        for (index, box) in model.solids.enumerated() {
            if model.inclination(of: index) != nil { continue }
            let extent = box.size
            let axis = (0..<3).min { extent[$0] < extent[$1] } ?? 0
            let others = (0..<3).filter { $0 != axis }
            let long = (0..<3).max { extent[$0] < extent[$1] } ?? 2
            let across = (0..<3).filter { $0 != long }
            if extent[axis] > 0, !others.allSatisfy({ extent[axis] <= 0.5 * extent[$0] }) {
                // Not a wall or slab: a column if it is at least twice as long as it is wide.
                guard across.allSatisfy({ extent[$0] > 0 && 2 * extent[$0] <= extent[long] }) else {
                    throw BlastError.notPlateLike(index)
                }
                columns.append(
                    Column(
                        solid: index, axis: long, box: box, centre: 0.5 * (box.min + box.max),
                        low: box.min[long], high: box.max[long]))
                continue
            }
            guard extent[axis] > 0 else { throw BlastError.notPlateLike(index) }
            let mid = 0.5 * (box.min[axis] + box.max[axis])
            var low = box.min
            var high = box.max
            low[axis] = mid
            high[axis] = mid
            plates.append(
                Plate(
                    solid: index, axis: axis, box: box, thickness: extent[axis], mid: mid, low: low,
                    high: high))
        }

        // A pane set in a wall's opening (a solid the opening holds whole, in the plane of a wall
        // it cuts) lies on the wall's midsurface and fills the opening to its reveal, so that it
        // shares the wall's nodes round the opening, keeping its own thickness and material.
        for n in plates.indices {
            let axis = plates[n].axis
            guard let opening = model.openings.first(where: { $0.holds(plates[n].box) }),
                let wall = plates.first(where: { wall in
                    wall.axis == axis && !opening.holds(wall.box)
                        && (0..<3).allSatisfy {
                            opening.max[$0] > wall.box.min[$0] && opening.min[$0] < wall.box.max[$0]
                        }
                })
            else { continue }
            plates[n].mid = wall.mid
            for k in 0..<3 {
                plates[n].low[k] = k == axis ? wall.mid : max(opening.min[k], wall.box.min[k])
                plates[n].high[k] = k == axis ? wall.mid : min(opening.max[k], wall.box.max[k])
            }
        }

        // A plate edge that lies within (or on the face of) another plate it touches ends on that
        // plate's midsurface instead.
        func touches(_ p: Plate, _ q: Plate, along k: Int) -> Bool {
            for j in 0..<3 where j != k {
                if p.box.max[j] < q.box.min[j] - tolerance || q.box.max[j] < p.box.min[j] - tolerance {
                    return false
                }
            }
            return true
        }
        func boxesTouch(_ a: Box, _ b: Box, along k: Int) -> Bool {
            (0..<3).allSatisfy { j in
                j == k || (a.max[j] >= b.min[j] - tolerance && b.max[j] >= a.min[j] - tolerance)
            }
        }
        for n in plates.indices {
            for k in 0..<3 where k != plates[n].axis {
                for q in plates
                where q.axis == k && q.solid != plates[n].solid && touches(plates[n], q, along: k) {
                    let within = (q.box.min[k] - tolerance)...(q.box.max[k] + tolerance)
                    if within.contains(plates[n].box.min[k]) { plates[n].low[k] = q.mid }
                    if within.contains(plates[n].box.max[k]) { plates[n].high[k] = q.mid }
                }
                // A panel that ends against a column ends on its centreline.
                for column in columns
                where column.axis != k && boxesTouch(plates[n].box, column.box, along: k) {
                    let within = (column.box.min[k] - tolerance)...(column.box.max[k] + tolerance)
                    if within.contains(plates[n].box.min[k]) { plates[n].low[k] = column.centre[k] }
                    if within.contains(plates[n].box.max[k]) { plates[n].high[k] = column.centre[k] }
                }
            }
        }
        // A column that ends inside a slab ends on its midsurface.
        for n in columns.indices {
            let k = columns[n].axis
            for plate in plates where plate.axis == k && boxesTouch(columns[n].box, plate.box, along: k) {
                let within = (plate.box.min[k] - tolerance)...(plate.box.max[k] + tolerance)
                if within.contains(columns[n].box.min[k]) { columns[n].low = plate.mid }
                if within.contains(columns[n].box.max[k]) { columns[n].high = plate.mid }
            }
        }

        // Breakpoints, most important first: midsurfaces, then plate edges, then the edges of
        // openings. A point closer than half an element to one already kept is dropped, so that
        // no element is much smaller than the rest.
        for k in 0..<3 {
            var kept: [Float] = []
            func offer(_ value: Float, spacing: Float) {
                if !kept.contains(where: { abs($0 - value) < spacing }) { kept.append(value) }
            }
            // Parallel plates within a fifth of an element of each other share the first one's
            // midsurface (two near ones would leave a sliver of elements in every plate that
            // crosses both, and a time step to match); further apart, as a cavity wall's leaves
            // are, they stay apart.
            for plate in plates where plate.axis == k {
                offer(plate.mid, spacing: max(tolerance, 0.2 * size))
            }
            // A column's centreline within half an element of a midsurface moves onto it (cladding
            // flush with a column's face would otherwise leave a sliver of elements, and a time
            // step to match).
            for column in columns where column.axis != k { offer(column.centre[k], spacing: 0.5 * size) }
            // Column faces, so that slabs have nodes around a column's footprint to tie to it.
            for column in columns where column.axis != k {
                offer(column.box.min[k], spacing: 0.5 * size + tolerance)
                offer(column.box.max[k], spacing: 0.5 * size + tolerance)
            }
            for column in columns where column.axis == k {
                offer(column.low, spacing: 0.5 * size + tolerance)
                offer(column.high, spacing: 0.5 * size + tolerance)
            }
            for plate in plates where plate.axis != k {
                offer(plate.low[k], spacing: 0.5 * size + tolerance)
                offer(plate.high[k], spacing: 0.5 * size + tolerance)
            }
            for opening in model.openings {
                let cuts = plates.contains { plate in
                    plate.axis != k
                        && (0..<3).allSatisfy { j in
                            opening.max[j] > plate.box.min[j] && opening.min[j] < plate.box.max[j]
                        }
                }
                if cuts {
                    offer(opening.min[k], spacing: 0.5 * size + tolerance)
                    offer(opening.max[k], spacing: 0.5 * size + tolerance)
                }
            }
            kept.sort()
            // Then each interval is split into equal parts no longer than an element.
            var points: [Float] = []
            for (a, b) in zip(kept, kept.dropFirst()) {
                let parts = max(1, Int(((b - a) / size - 1e-3).rounded(.up)))
                for part in 0..<parts { points.append(a + (b - a) * Float(part) / Float(parts)) }
            }
            if let last = kept.last { points.append(last) }
            grid[k] = points
        }
        // Plate edges that were dropped move to the nearest breakpoint kept (the breakpoints are
        // in order).
        func nearest(_ value: Float, _ k: Int) -> Int {
            let line = grid[k]
            guard !line.isEmpty else { return 0 }
            var (low, high) = (0, line.count - 1)
            while high - low > 1 {
                let middle = (low + high) / 2
                if line[middle] <= value { low = middle } else { high = middle }
            }
            return abs(line[high] - value) < abs(line[low] - value) ? high : low
        }

        let materials = model.materials
        var nodeIndex: [SIMD3<Int32>: UInt32] = [:]
        // A fastened sheet's solids have nodes of their own, a layer for each sheet.
        var layerOf: [Int: Int32] = [:]
        for (n, fastened) in model.sheetFastenings.enumerated() {
            for solid in fastened.solids { layerOf[solid] = Int32(n + 1) }
        }
        var layeredIndex: [SIMD4<Int32>: UInt32] = [:]
        func node(_ key: SIMD3<Int32>, solid: Int = -1) -> UInt32 {
            if let layer = layerOf[solid] {
                let layered = SIMD4(key, layer)
                if let index = layeredIndex[layered] { return index }
                let index = UInt32(positions.count)
                layeredIndex[layered] = index
                positions.append(SIMD3(grid[0][Int(key.x)], grid[1][Int(key.y)], grid[2][Int(key.z)]))
                return index
            }
            if let index = nodeIndex[key] { return index }
            let index = UInt32(positions.count)
            nodeIndex[key] = index
            positions.append(SIMD3(grid[0][Int(key.x)], grid[1][Int(key.y)], grid[2][Int(key.z)]))
            return index
        }
        // Coplanar plates that overlap give one element, of the later plate's material.
        var claimed: [SIMD4<Int32>: Int] = [:]
        for plate in plates {
            let k = plate.axis
            let first = (k + 1) % 3
            let second = (k + 2) % 3
            let level = Int32(nearest(plate.mid, k))
            // The openings that cut this plate: those crossing it that do not hold it whole.
            let cutting = model.openings.filter { opening in
                !opening.holds(plate.box)
                    && (0..<3).allSatisfy {
                        opening.max[$0] >= plate.box.min[$0] && opening.min[$0] <= plate.box.max[$0]
                    }
            }
            let range1 = nearest(plate.low[first], first)..<nearest(plate.high[first], first)
            let range2 = nearest(plate.low[second], second)..<nearest(plate.high[second], second)
            for u in range1 {
                for v in range2 {
                    let a = grid[first][u + 1] - grid[first][u]
                    let b = grid[second][v + 1] - grid[second][v]
                    var centre = SIMD3<Float>(repeating: 0)
                    centre[k] = plate.mid
                    centre[first] = 0.5 * (grid[first][u] + grid[first][u + 1])
                    centre[second] = 0.5 * (grid[second][v] + grid[second][v + 1])
                    if cutting.contains(where: { $0.contains(centre) }) { continue }
                    if !trimmers.isEmpty && trimmed(centre) { continue }
                    var keys: [SIMD3<Int32>] = []
                    for (du, dv) in [(0, 0), (1, 0), (1, 1), (0, 1)] {
                        var key = SIMD3<Int32>(repeating: 0)
                        key[k] = level
                        key[first] = Int32(u + du)
                        key[second] = Int32(v + dv)
                        keys.append(key)
                    }
                    let corners = SIMD4(
                        node(keys[0], solid: plate.solid), node(keys[1], solid: plate.solid),
                        node(keys[2], solid: plate.solid), node(keys[3], solid: plate.solid))
                    let material = materials.firstIndex(of: model.material(of: plate.solid)) ?? 0
                    var bars: [SIMD3<Float>] = []
                    if materials[material].steel != nil {
                        bars = Self.bars(in: plate, at: centre, model: model)
                    }
                    let element = Element(
                        nodes: corners, axis: k, material: material, thickness: plate.thickness,
                        size: SIMD2(a, b), bars: bars, solid: plate.solid)
                    let key = SIMD4(Int32(k), level, Int32(u), Int32(v))
                    if let existing = claimed[key] {
                        elements[existing] = element
                    } else {
                        claimed[key] = elements.count
                        elements.append(element)
                    }
                }
            }
        }
        for column in columns {
            let k = column.axis
            let first = (k + 1) % 3
            let second = (k + 2) % 3
            let material = materials.firstIndex(of: model.material(of: column.solid)) ?? 0
            let section = SIMD2(column.box.size[first], column.box.size[second])
            // Bars from the reinforcement regions that cross the section: a region filling the
            // section (a column's smeared steel) becomes four corner bars at the cover; one
            // filling part of it (a mat near one face) becomes a bar at its middle. Ties come from
            // the ratios across the beam.
            var bars: [SIMD3<Float>] = []
            var ties: Float = 0
            if materials[material].steel != nil {
                let cover = min(Self.columnCover, 0.25 * section.min())
                let inset = SIMD2(1 - 2 * cover / section.x, 1 - 2 * cover / section.y)
                for layer in model.reinforcement {
                    let region = layer.region
                    guard region.min[k] <= column.centre[k], column.centre[k] <= region.max[k] else {
                        continue
                    }
                    let low = SIMD2(
                        max(region.min[first], column.box.min[first]),
                        max(region.min[second], column.box.min[second]))
                    let high = SIMD2(
                        min(region.max[first], column.box.max[first]),
                        min(region.max[second], column.box.max[second]))
                    let overlap = high - low
                    guard overlap.x > 0, overlap.y > 0, layer.ratio[k] > 0 else { continue }
                    ties = max(ties, max(layer.ratio[first], layer.ratio[second]))
                    let area = layer.ratio[k] * overlap.x * overlap.y
                    if overlap.x >= 0.99 * section.x && overlap.y >= 0.99 * section.y {
                        for corner in 0..<4 where bars.count < Self.maxBeamBars {
                            let sign = SIMD2<Float>(corner & 1 == 0 ? -1 : 1, corner & 2 == 0 ? -1 : 1)
                            bars.append(SIMD3(sign * inset, area / 4))
                        }
                    } else if bars.count < Self.maxBeamBars {
                        let middle = 0.5 * (low + high)
                        let centre = SIMD2(column.centre[first], column.centre[second])
                        let position = simd_clamp(2 * (middle - centre) / section, -inset, inset)
                        bars.append(SIMD3(position, area))
                    }
                }
            }
            var key = SIMD3<Int32>(repeating: 0)
            key[first] = Int32(nearest(column.centre[first], first))
            key[second] = Int32(nearest(column.centre[second], second))
            for w in nearest(column.low, k)..<nearest(column.high, k) {
                var lower = key
                var upper = key
                lower[k] = Int32(w)
                upper[k] = Int32(w + 1)
                beams.append(
                    Beam(
                        nodes: SIMD2(node(lower, solid: column.solid), node(upper, solid: column.solid)),
                        axis: k,
                        material: material, section: section,
                        length: grid[k][w + 1] - grid[k][w], bars: bars, tieRatio: ties, solid: column.solid))
            }
        }
        // Planes at a pitch, each in its own plane: elements square to it, `elementSize` or less a
        // side, their corners in order along the low edge and up the slope (axis 3: the kernels
        // take their axes from their corners). Planes meeting along an edge, as a roof's two slopes
        // at its ridge, share their nodes there.
        var inclinedNode: [SIMD3<Int32>: UInt32] = [:]
        func inclinedNodeAt(_ position: SIMD3<Float>) -> UInt32 {
            let key = SIMD3<Int32>((position / tolerance).rounded(.toNearestOrEven))
            if let index = inclinedNode[key] { return index }
            let index = UInt32(positions.count)
            inclinedNode[key] = index
            positions.append(position)
            return index
        }
        for piece in inclined {
            let plane = piece.inclination.plane(in: piece.box)
            let counts = SIMD2<Int>(
                max(1, Int((plane.lengths.x / size).rounded(.up))),
                max(1, Int((plane.lengths.y / size).rounded(.up))))
            let step = plane.lengths / SIMD2<Float>(counts)
            let material = materials.firstIndex(of: model.material(of: piece.solid)) ?? 0
            let first = elements.count
            for v in 0..<counts.y {
                for u in 0..<counts.x {
                    func corner(_ du: Int, _ dv: Int) -> UInt32 {
                        inclinedNodeAt(
                            plane.origin + Float(u + du) * step.x * plane.along + Float(v + dv) * step.y
                                * plane.up)
                    }
                    var element = Element(
                        nodes: SIMD4(corner(0, 0), corner(1, 0), corner(1, 1), corner(0, 1)), axis: 3,
                        material: material, thickness: piece.inclination.thickness, size: step, bars: [],
                        solid: piece.solid)
                    // Its neighbours in the plane: −first, +first, −second, +second.
                    let index = first + u + counts.x * v
                    element.neighbours = SIMD4(
                        u > 0 ? Int32(index - 1) : -1, u + 1 < counts.x ? Int32(index + 1) : -1,
                        v > 0 ? Int32(index - counts.x) : -1, v + 1 < counts.y ? Int32(index + counts.x) : -1)
                    elements.append(element)
                }
            }
        }
        // Column heads: where a column meets a slab, the slab's nodes within the column's footprint
        // are tied to the column's node there.
        var tied = Set<UInt32>()
        var heads: [(master: UInt32, column: Column)] = []
        let plateLevels = plates.map { nearest($0.mid, $0.axis) }
        // The grid lines within `reach` of `centre` along `k`.
        func lines(_ k: Int, within reach: Float, of centre: Float) -> ClosedRange<Int>? {
            let line = grid[k]
            guard let low = line.firstIndex(where: { $0 >= centre - reach }),
                let high = line.lastIndex(where: { $0 <= centre + reach }), low <= high
            else { return nil }
            return low...high
        }
        // The nodes on the plane through `centre` square to `k`, within `half` of it in that
        // plane, in the order they were made.
        func nodes(around centre: SIMD3<Float>, axis k: Int, half: SIMD2<Float>) -> [UInt32] {
            let first = (k + 1) % 3
            let second = (k + 2) % 3
            guard let us = lines(first, within: half.x, of: centre[first]),
                let vs = lines(second, within: half.y, of: centre[second])
            else { return [] }
            let level = Int32(nearest(centre[k], k))
            var found: [UInt32] = []
            for u in us {
                for v in vs {
                    var key = SIMD3<Int32>(repeating: 0)
                    key[k] = level
                    key[first] = Int32(u)
                    key[second] = Int32(v)
                    if let node = nodeIndex[key] { found.append(node) }
                }
            }
            return found.sorted()
        }
        let masters = Set(beams.flatMap { [$0.nodes.x, $0.nodes.y] })
        for column in columns {
            let k = column.axis
            let first = (k + 1) % 3
            let second = (k + 2) % 3
            let half = 0.5 * SIMD2(column.box.size[first], column.box.size[second]) + tolerance
            let ends = Set(
                beams.filter { $0.solid == column.solid }.flatMap { [$0.nodes.x, $0.nodes.y] })
            // In order: a node near two heads is tied to the first, and a set's order changes from
            // one process to the next.
            for master in ends.sorted() {
                let position = positions[Int(master)]
                let level = position[k]
                // A head where the column meets a plate square to it, within the plate.
                guard
                    plates.indices.contains(where: { n in
                        let plate = plates[n]
                        return plate.axis == k && abs(grid[k][plateLevels[n]] - level) < tolerance
                            && [first, second].allSatisfy {
                                position[$0] >= plate.low[$0] - tolerance
                                    && position[$0] <= plate.high[$0] + tolerance
                            }
                    })
                else { continue }
                heads.append((master, column))
                let centre = positions[Int(master)]
                for node in nodes(around: centre, axis: k, half: half) {
                    let position = positions[Int(node)]
                    guard node != master, !masters.contains(node), !tied.contains(node),
                        abs(position[k] - level) < tolerance,
                        abs(position[first] - centre[first]) <= half.x,
                        abs(position[second] - centre[second]) <= half.y
                    else { continue }
                    ties.append((node, master))
                    tied.insert(node)
                }
            }
        }
        let punchingHeads = heads.map { (master: $0.master, axis: $0.column.axis, box: $0.column.box) }
        var elementsOfNode = [[Int]](repeating: [], count: positions.count)
        for (index, element) in elements.enumerated() {
            for corner in 0..<4 { elementsOfNode[Int(element.nodes[corner])].append(index) }
        }
        let strengths = Self.punchingStrengths(
            elements: elements, heads: punchingHeads, ties: ties, materials: materials,
            elementsOfNode: elementsOfNode)
        punching = strengths.strengths
        punchingRings = strengths.rings
        punchingZone = [Bool](repeating: false, count: elements.count)
        let thickest = elements.map(\.thickness).max() ?? 0
        for head in punchingHeads {
            let k = head.axis
            let level = positions[Int(head.master)][k]
            let centre = positions[Int(head.master)]
            // The elements round it: those with a corner within the widest reach and an element.
            let first = (k + 1) % 3
            let second = (k + 2) % 3
            let margin = 2 * 0.8 * thickest + 2 * size + tolerance
            let around = Set(
                nodes(
                    around: centre, axis: k,
                    half: SIMD2(0.5 * head.box.size[first] + margin, 0.5 * head.box.size[second] + margin)
                ).flatMap { elementsOfNode[Int($0)] })
            for index in around.sorted() where elements[index].axis == k {
                let element = elements[index]
                let middle = (0..<4).reduce(SIMD3<Float>.zero) { $0 + positions[Int(element.nodes[$1])] } / 4
                guard abs(middle[k] - level) < tolerance else { continue }
                let reach = 0.5 * head.box.size + SIMD3(repeating: 2 * 0.8 * element.thickness)
                let inside = (0..<3).allSatisfy { $0 == k || abs(middle[$0] - centre[$0]) <= reach[$0] }
                if inside { punchingZone[index] = true }
            }
        }
        for (key, index) in claimed {
            let offsets: [SIMD4<Int32>] = [
                SIMD4(0, 0, -1, 0), SIMD4(0, 0, 1, 0), SIMD4(0, 0, 0, -1), SIMD4(0, 0, 0, 1),
            ]
            for (side, offset) in offsets.enumerated() {
                elements[index].neighbours[side] = Int32(claimed[key &+ offset] ?? -1)
            }
        }
        if model.tiesTouching == true { tieTouching(model: model, tolerance: tolerance) }
        // Fastened sheets: a link wherever a sheet's node lies on a beam's running across its ribs
        // (a purlin's or rail's, not a rafter's or column's along them), pulling off away from the
        // beam's side of the sheet; each standing for the beam's length halfway to its neighbours
        // along it.
        var ribAxis: [Int32: Int] = [:]
        for beam in beams { if let layer = layerOf[beam.solid] { ribAxis[layer] = beam.axis } }
        var beamOfNode: [UInt32: Int] = [:]
        for beam in beams where layerOf[beam.solid] == nil {
            beamOfNode[beam.nodes.x] = beam.solid
            beamOfNode[beam.nodes.y] = beam.solid
        }
        var found: [Link] = []
        for (layered, sheetNode) in layeredIndex {
            let key = SIMD3(layered.x, layered.y, layered.z)
            guard let beamNode = nodeIndex[key], let solid = beamOfNode[beamNode],
                let column = columns.first(where: { $0.solid == solid }),
                let skin = plates.first(where: { layerOf[$0.solid] == layered.w }),
                column.axis != ribAxis[layered.w]
            else { continue }
            let normal = skin.axis
            // Off the beam: away from its side of the sheet, or, where it lies in the sheet's plane,
            // towards the sheet's crests.
            let side = column.centre[normal] - skin.mid
            let off: Float =
                abs(side) > tolerance
                ? (side < 0 ? 1 : -1) : Float(model.sheetFastenings[Int(layered.w) - 1].crestSide)
            found.append(
                Link(
                    sheet: sheetNode, beam: beamNode, normal: normal, off: off, length: 0,
                    fastening: Int(layered.w) - 1))
        }
        found.sort { ($0.beam, $0.sheet) < ($1.beam, $1.sheet) }
        var byBeam: [Int: [Int]] = [:]
        for (n, link) in found.enumerated() { byBeam[beamOfNode[link.beam]!, default: []].append(n) }
        for (solid, members) in byBeam {
            guard let column = columns.first(where: { $0.solid == solid }) else { continue }
            let along = column.axis
            let stations = members.map { positions[Int(found[$0].beam)][along] }
            let sorted = Array(Set(stations)).sorted()
            for (n, member) in members.enumerated() {
                let value = stations[n]
                guard let i = sorted.firstIndex(of: value) else { continue }
                let low = i > 0 ? sorted[i - 1] : value
                let high = i + 1 < sorted.count ? sorted[i + 1] : value
                found[member].length = 0.5 * (high - low)
            }
        }
        links = found
        if model.steelConnection != nil { hinge(model: model, materials: materials) }
    }

    /// Gives each steel beam that stops at another member its own end node there, held to the
    /// joint's by a hinge (`SteelConnection`). The joint's node stays with what holds it: a column
    /// (a beam upright), a member that runs on through it, or a shell. A beam whose end meets
    /// nothing, or only other beams that stop there too, keeps its node.
    private mutating func hinge(model: StructureModel, materials: [StructureMaterial]) {
        var solidsOfNode = [Set<Int>](repeating: [], count: positions.count)
        var inShell = [Bool](repeating: false, count: positions.count)
        for element in elements {
            for corner in 0..<4 { inShell[Int(element.nodes[corner])] = true }
        }
        var beamsOfSolid: [Int: [Int]] = [:]
        for (b, beam) in beams.enumerated() {
            beamsOfSolid[beam.solid, default: []].append(b)
            for end in 0..<2 { solidsOfNode[Int(beam.nodes[end])].insert(beam.solid) }
        }
        // Each line's two ends.
        var endsOf: [Int: (low: UInt32, high: UInt32, axis: Int)] = [:]
        for (solid, members) in beamsOfSolid {
            let k = beams[members[0]].axis
            let nodes = Set(members.flatMap { [beams[$0].nodes.x, beams[$0].nodes.y] }).sorted()
            guard let low = nodes.min(by: { positions[Int($0)][k] < positions[Int($1)][k] }),
                let high = nodes.max(by: { positions[Int($0)][k] < positions[Int($1)][k] })
            else { continue }
            endsOf[solid] = (low, high, k)
        }
        func holds(_ node: UInt32, other solid: Int) -> Bool {
            guard let ends = endsOf[solid] else { return false }
            return ends.axis == 2 || (ends.low != node && ends.high != node)
        }
        for (solid, members) in beamsOfSolid.sorted(by: { $0.key < $1.key }) {
            let first = beams[members[0]]
            guard first.axis != 2, let ends = endsOf[solid], materials.indices.contains(first.material),
                materials[first.material].model == .vonMises, materials[first.material].steel == nil,
                materials[first.material].yieldStress < 0.05 * materials[first.material].youngsModulus
            else { continue }
            for end in [ends.low, ends.high] {
                let others = solidsOfNode[Int(end)].subtracting([solid])
                guard inShell[Int(end)] || others.contains(where: { holds(end, other: $0) }) else { continue }
                guard let b = members.first(where: { beams[$0].nodes.x == end || beams[$0].nodes.y == end })
                else { continue }
                let fresh = UInt32(positions.count)
                positions.append(positions[Int(end)])
                if beams[b].nodes.x == end { beams[b].nodes.x = fresh } else { beams[b].nodes.y = fresh }
                hinges.append(
                    Hinge(
                        beamNode: fresh, jointNode: end, axis: first.axis, section: beams[b].section,
                        material: beams[b].material, length: beams[b].length))
            }
        }
    }

    /// Members that touch but share no node (layers stacked face to face, a beam meeting a column
    /// off its centreline, a plate against a beam's side) are tied: each node of the lighter one
    /// near where they touch to the other's nearest, rigidly, as a column's head is to a slab.
    /// Nodes already tied, holding others, or held by a support are left as they are.
    private mutating func tieTouching(model: StructureModel, tolerance: Float) {
        let solids = model.solids
        var sets = [Set<UInt32>](repeating: [], count: solids.count)
        for element in elements { for k in 0..<4 { sets[element.solid].insert(element.nodes[k]) } }
        for beam in beams {
            sets[beam.solid].insert(beam.nodes.x)
            sets[beam.solid].insert(beam.nodes.y)
        }
        let nodes = sets.map { $0.sorted() }
        var masterOf: [UInt32: UInt32] = [:]
        var masters = Set<UInt32>()
        for tie in ties {
            masterOf[tie.slave] = tie.master
            masters.insert(tie.master)
        }
        func touch(_ a: Box, _ b: Box) -> Bool {
            (0..<3).allSatisfy { a.max[$0] >= b.min[$0] - tolerance && b.max[$0] >= a.min[$0] - tolerance }
        }
        // Members already joined, through shared nodes or ties, directly or through others.
        var group = Array(solids.indices)
        func root(_ n: Int) -> Int {
            var n = n
            while group[n] != n {
                group[n] = group[group[n]]
                n = group[n]
            }
            return n
        }
        var owner: [UInt32: Int] = [:]
        for (n, set) in sets.enumerated() {
            for node in set {
                if let other = owner[node] { group[root(n)] = root(other) } else { owner[node] = n }
            }
        }
        for tie in ties {
            if let a = owner[tie.slave], let b = owner[tie.master] { group[root(a)] = root(b) }
        }
        func linked(_ i: Int, _ j: Int) -> Bool { root(i) == root(j) }
        func volume(_ n: Int) -> Float { solids[n].size.x * solids[n].size.y * solids[n].size.z }
        // Nodes a connection will hold, through points of their faces as the solver finds them,
        // or that are clamped: never made to follow another.
        var anchored = Set<Int>()
        if model.connectionStiffness != nil {
            let points = jointPoints(across: ShellMesh.fibresAcross, normals: model.connectionNormals) {
                point, node in
                guard let slot = model.connectionSlot(at: point), slot != 0 || model.isOnGround(node),
                    let law = model.connection(inSlot: slot)
                else { return nil }
                return (slot, law.across)
            }
            for (n, list) in points.enumerated() where !list.isEmpty { anchored.insert(n) }
        }
        func held(_ p: SIMD3<Float>) -> Bool {
            model.isClampedBySupport(at: p) || (model.fixedBase && model.isOnGround(p))
        }
        for i in solids.indices where !sets[i].isEmpty {
            for j in (i + 1)..<solids.count
            where !sets[j].isEmpty && touch(solids[i], solids[j]) && !linked(i, j) {
                let (light, heavy) = volume(i) <= volume(j) ? (i, j) : (j, i)
                // Where they touch, widened to take in both midsurfaces or centrelines.
                let reach =
                    max(0.5 * model.elementSize, 0.5 * solids[i].size.min(), 0.5 * solids[j].size.min())
                    + tolerance
                var region = Box(
                    min: simd_max(solids[i].min, solids[j].min), max: simd_min(solids[i].max, solids[j].max))
                region.min -= SIMD3(repeating: reach)
                region.max += SIMD3(repeating: reach)
                func inside(_ p: SIMD3<Float>) -> Bool {
                    (0..<3).allSatisfy { p[$0] >= region.min[$0] && p[$0] <= region.max[$0] }
                }
                let candidates = nodes[heavy].filter { inside(positions[Int($0)]) }
                var count = 0
                for slave in nodes[light] where inside(positions[Int(slave)]) {
                    guard masterOf[slave] == nil, !masters.contains(slave), !anchored.contains(Int(slave)),
                        !held(positions[Int(slave)])
                    else { continue }
                    let p = positions[Int(slave)]
                    guard
                        var master = candidates.min(by: {
                            simd_distance_squared(positions[Int($0)], p)
                                < simd_distance_squared(positions[Int($1)], p)
                        }), simd_distance(positions[Int(master)], p) <= 2 * reach + model.elementSize
                    else { continue }
                    if let up = masterOf[master] { master = up }
                    guard master != slave else { continue }
                    ties.append((slave, master))
                    masterOf[slave] = master
                    masters.insert(master)
                    count += 1
                }
                if count > 0 {
                    contactTies.append((i, j, count))
                    group[root(i)] = root(j)
                }
            }
        }
        // A wall turned in plan (a plane given outright, `Inclination.frame`) meets the walls at its
        // ends, the slabs over and under it and the chords beside it, none on its grid: each of its
        // nodes within another member's reach follows that member's nearest node, whatever joins
        // them already elsewhere.
        for i in solids.indices where model.inclination(of: i)?.frame != nil && !sets[i].isEmpty {
            for j in solids.indices where j != i && !sets[j].isEmpty && touch(solids[i], solids[j]) {
                // Chords of one curved wall share their edges' nodes already.
                if model.inclination(of: j)?.frame != nil { continue }
                let reach = max(0.5 * model.elementSize, 0.5 * solids[j].size.min()) + tolerance
                var region = solids[j]
                region.min -= SIMD3(repeating: reach)
                region.max += SIMD3(repeating: reach)
                let candidates = nodes[j].filter { node in
                    let p = positions[Int(node)]
                    return (0..<3).allSatisfy { p[$0] >= region.min[$0] && p[$0] <= region.max[$0] }
                }
                guard !candidates.isEmpty else { continue }
                var count = 0
                for slave in nodes[i] where !sets[j].contains(slave) {
                    let p = positions[Int(slave)]
                    guard (0..<3).allSatisfy({ p[$0] >= region.min[$0] && p[$0] <= region.max[$0] }),
                        masterOf[slave] == nil, !masters.contains(slave), !anchored.contains(Int(slave)),
                        !held(p)
                    else { continue }
                    guard
                        var master = candidates.min(by: {
                            simd_distance_squared(positions[Int($0)], p)
                                < simd_distance_squared(positions[Int($1)], p)
                        }), simd_distance(positions[Int(master)], p) <= 2 * reach + model.elementSize
                    else { continue }
                    if let up = masterOf[master] { master = up }
                    guard master != slave else { continue }
                    ties.append((slave, master))
                    masterOf[slave] = master
                    masters.insert(master)
                    count += 1
                }
                if count > 0 { contactTies.append((i, j, count)) }
            }
        }
    }

    /// The punching strength of the slab elements around each column head, as the mean shear
    /// stress through their thickness at which the connection punches, and the ring of elements
    /// around each head.
    ///
    /// Eurocode 2 (EN 1992-1-1, 6.4.4) gives the punching strength of a slab without shear
    /// reinforcement as v = 0.18 k (100 rho f_c)^(1/3) MPa, at least 0.035 k^1.5 f_c^0.5, with
    /// k = 1 + sqrt(200 / d) (d in mm) no more than 2, on a control perimeter u1 two effective
    /// depths d from the column's face: u1 = 2 (c1 + c2) + 4 pi d. The ring of elements touching
    /// the column's footprint carries the same force through a perimeter u through their
    /// centres, 2 (c1 + c2) + 4 s for elements of side s, and the slab's whole thickness t, so
    /// they punch at a mean shear of v u1 d / (u t). The tension face is taken as the top (the
    /// face towards +axis), where a slab hogs over its column; d is to its outermost bars and rho
    /// the geometric mean of its bars each way, at most 2%. This is a characteristic strength,
    /// below the mean of tests.
    static func punchingStrengths(
        elements: [Element], heads: [(master: UInt32, axis: Int, box: Box)],
        ties: [(slave: UInt32, master: UInt32)], materials: [StructureMaterial],
        elementsOfNode: [[Int]]? = nil
    ) -> (strengths: [Float], rings: [[Int]]) {
        var strengths = [Float](repeating: 0, count: elements.count)
        var rings: [[Int]] = []
        var claimed = Set<Int>()
        for head in heads {
            var ring: [Int] = []
            var footprint = Set(ties.filter { $0.master == head.master }.map(\.slave))
            footprint.insert(head.master)
            let first = (head.axis + 1) % 3
            let second = (head.axis + 2) % 3
            let c1 = head.box.size[first]
            let c2 = head.box.size[second]
            // Only elements with a corner in the footprint count; with the map, only they are seen.
            let candidates =
                elementsOfNode.map { map in Set(footprint.flatMap { map[Int($0)] }).sorted() }
                ?? Array(elements.indices)
            for index in candidates where elements[index].axis == head.axis {
                let element = elements[index]
                let inside = (0..<4).filter { footprint.contains(element.nodes[$0]) }.count
                let material = materials[element.material]
                guard inside > 0, inside < 4, material.model == .concrete else { continue }
                let t = element.thickness
                let top = element.bars.filter { $0.x > 0 }
                let face = top.isEmpty ? element.bars.map { SIMD3(-$0.x, $0.y, $0.z) } : top
                let outermost = face.map(\.x).max() ?? 0.6
                let d = 0.5 * t * (1 + outermost)
                let areas = face.reduce(SIMD2<Float>.zero) { $0 + SIMD2($1.y, $1.z) }
                let ratio = min((areas.x * areas.y).squareRoot() / d, 0.02)
                let fc = material.compressiveStrength / 1e6
                let k = min(1 + (0.2 / d).squareRoot(), 2)
                let v =
                    max(0.18 * k * pow(100 * ratio * fc, 1 / 3), 0.035 * pow(k, 1.5) * fc.squareRoot()) * 1e6
                let s = 0.5 * (element.size.x + element.size.y)
                let u1 = 2 * (c1 + c2) + 4 * Float.pi * d
                let perimeter = 2 * (c1 + c2) + 4 * s
                let strength = v * u1 * d / (perimeter * t)
                // An element in two rings (columns closer than two elements) stays in the first.
                guard !claimed.contains(index) else { continue }
                claimed.insert(index)
                strengths[index] = strength
                ring.append(index)
            }
            if !ring.isEmpty { rings.append(ring) }
        }
        return (strengths, rings)
    }

    /// For each element, the nearest element of another member below and above it (along its
    /// axis, -1 where there is none): parallel to it, over its centre, and no more than a metre
    /// beyond its faces. The air does not resolve a gap thinner than its cells, so a face that
    /// such an element faces across one sees ambient air instead of the air beyond both
    /// (`shellShielded` in Shell.metal): the leaves of a cavity wall each take their own side.
    package func shields() -> [(below: Int32, above: Int32)] {
        let reach: Float = 1
        let side = elements.reduce(Float(0)) { max($0, $1.size.x, $1.size.y) }
        guard side > 0 else { return [] }
        func centre(_ element: Element) -> SIMD3<Float> {
            (0..<4).reduce(SIMD3<Float>.zero) { $0 + positions[Int(element.nodes[$1])] } / 4
        }
        let centres = elements.map(centre)
        // Elements by axis and by the cell their centre falls in, across that axis.
        var cells: [SIMD3<Int32>: [Int]] = [:]
        func key(_ axis: Int, _ point: SIMD3<Float>, _ di: Int32 = 0, _ dj: Int32 = 0) -> SIMD3<Int32> {
            let (i1, i2) = ((axis + 1) % 3, (axis + 2) % 3)
            return SIMD3(
                Int32(axis), Int32((point[i1] / side).rounded(.down)) + di,
                Int32((point[i2] / side).rounded(.down)) + dj)
        }
        for (e, element) in elements.enumerated() where element.axis < 3 {
            cells[key(element.axis, centres[e]), default: []].append(e)
        }
        // Elements at a pitch shield and are shielded by others at the same pitch (a roof's tiles
        // over its slope), never by those square to the axes: keyed by their plane's normal and
        // where they lie along its two axes, so that parallel planes' elements share a key.
        struct PlaneKey: Hashable {
            var normal: SIMD3<Int32>
            var at: SIMD2<Int32>
        }
        func planeKey(_ e: Int, _ di: Int32 = 0, _ dj: Int32 = 0) -> PlaneKey {
            let (first, second, normal) = frame(of: elements[e])
            return PlaneKey(
                normal: SIMD3<Int32>((normal * 1000).rounded(.toNearestOrEven)),
                at: SIMD2(
                    Int32((simd_dot(centres[e], first) / side).rounded(.down)) + di,
                    Int32((simd_dot(centres[e], second) / side).rounded(.down)) + dj))
        }
        var pitched: [PlaneKey: [Int]] = [:]
        for (e, element) in elements.enumerated() where element.axis == 3 {
            pitched[planeKey(e), default: []].append(e)
        }
        func inclinedShields(_ e: Int) -> (below: Int32, above: Int32) {
            let element = elements[e]
            let (first, second, normal) = frame(of: element)
            let at = centres[e]
            var below: (index: Int32, distance: Float) = (-1, .infinity)
            var above: (index: Int32, distance: Float) = (-1, .infinity)
            for di: Int32 in -1...1 {
                for dj: Int32 in -1...1 {
                    for f in pitched[planeKey(e, di, dj)] ?? [] where elements[f].solid != element.solid {
                        let other = elements[f]
                        let d = centres[f] - at
                        guard abs(simd_dot(d, first)) <= 0.5 * other.size.x + 1e-4,
                            abs(simd_dot(d, second)) <= 0.5 * other.size.y + 1e-4
                        else { continue }
                        let offset = simd_dot(d, normal)
                        let gap = abs(offset) - 0.5 * (element.thickness + other.thickness)
                        guard abs(offset) > 1e-4, gap <= reach else { continue }
                        if offset > 0, offset < above.distance { above = (Int32(f), offset) }
                        if offset < 0, -offset < below.distance { below = (Int32(f), -offset) }
                    }
                }
            }
            return (below.index, above.index)
        }
        return elements.indices.map { e in
            let element = elements[e]
            guard element.axis < 3 else { return inclinedShields(e) }
            let k = element.axis
            let (i1, i2) = ((k + 1) % 3, (k + 2) % 3)
            let at = centres[e]
            var below: (index: Int32, distance: Float) = (-1, .infinity)
            var above: (index: Int32, distance: Float) = (-1, .infinity)
            for di: Int32 in -1...1 {
                for dj: Int32 in -1...1 {
                    for f in cells[key(k, at, di, dj)] ?? [] where elements[f].solid != element.solid {
                        let other = elements[f]
                        let c = centres[f]
                        guard abs(at[i1] - c[i1]) <= 0.5 * other.size.x + 1e-4,
                            abs(at[i2] - c[i2]) <= 0.5 * other.size.y + 1e-4
                        else { continue }
                        let offset = c[k] - at[k]
                        let gap = abs(offset) - 0.5 * (element.thickness + other.thickness)
                        guard abs(offset) > 1e-4, gap <= reach else { continue }
                        if offset > 0, offset < above.distance { above = (Int32(f), offset) }
                        if offset < 0, -offset < below.distance { below = (Int32(f), -offset) }
                    }
                }
            }
            return (below.index, above.index)
        }
    }

    /// Each node's volume as loose debris: its share of the elements it belongs to.
    package func debrisVolumes() -> [Float] {
        var volumes = [Float](repeating: 0, count: max(positions.count, 1))
        for element in elements {
            for corner in 0..<4 {
                volumes[Int(element.nodes[corner])] += element.size.x * element.size.y * element.thickness / 4
            }
        }
        for beam in beams {
            for end in 0..<2 {
                volumes[Int(beam.nodes[end])] += beam.section.x * beam.section.y * beam.length / 2
            }
        }
        return volumes
    }

    /// The bar layers of the reinforcement regions that cross a plate at `centre`. A region is
    /// taken as a mat at its centre, of its own thickness; its ratios along the plate's axes
    /// give the bar area per unit width.
    private static func bars(in plate: Plate, at centre: SIMD3<Float>, model: StructureModel) -> [SIMD3<
        Float
    >] {
        let k = plate.axis
        let first = (k + 1) % 3
        let second = (k + 2) % 3
        var layers: [SIMD3<Float>] = []
        for layer in model.reinforcement {
            let region = layer.region
            guard
                region.min[first] <= centre[first], centre[first] <= region.max[first],
                region.min[second] <= centre[second], centre[second] <= region.max[second]
            else { continue }
            let depth = 0.5 * (region.min[k] + region.max[k])
            guard plate.box.min[k] <= depth, depth <= plate.box.max[k] else { continue }
            let band = region.max[k] - region.min[k]
            let zeta = max(-1, min(1, 2 * (depth - plate.mid) / plate.thickness))
            let areas = SIMD2(layer.ratio[first], layer.ratio[second]) * band
            guard areas.x + areas.y > 0 else { continue }
            if let same = layers.firstIndex(where: { abs($0.x - zeta) < 1e-3 }) {
                layers[same].y += areas.x
                layers[same].z += areas.y
            } else if layers.count < maxBars {
                layers.append(SIMD3(zeta, areas.x, areas.y))
            }
        }
        // A laminated pane's interlayer, at its midsurface both ways.
        if let interlayer = model.material(of: plate.solid).interlayerThickness, layers.count < maxBars {
            layers.append(SIMD3(0, interlayer, interlayer))
        }
        return layers
    }

    /// A point of a face of a wall, slab or beam that a connection ties (`Anchorage`): its offset
    /// from the node it moves with, the area it stands for, and the connection's slot (as
    /// `StructureModel.connectionSlot`).
    package struct JointPoint {
        package var arm: SIMD3<Float>
        package var area: Float
        package var slot: Int
    }

    /// Where each node carries its share of a connection: points of the faces of its walls, slabs
    /// and beams that face the connection's joint. `joint` gives the slot and the normal (across
    /// the joint into the body) of the connection that holds a point, given the point and its
    /// node, or nil where none does; `normals` are all the normals it may give, so that faces none
    /// can face are passed over. Each face that faces the support carries its area weighted
    /// by the cosine between them, as solid elements' faces do:
    /// - a free edge of a wall or slab (one with no element of its plate beyond), `across` points
    ///   through its thickness at each of its two nodes, over half the edge each;
    /// - either face of a wall or slab, one point at each corner, over a quarter of it;
    /// - a free end of a beam, `across` × `across` points over its section;
    /// - a side of a beam, `across` points across it at each end, over half its length.
    /// The points run from face to face with the trapezoid rule's weights, so that a base rocking
    /// on its toe bears at the face, as solid elements' corner nodes do.
    /// An element's own axes, in order, and its normal: the global axes after its `axis`, or for
    /// an element at a pitch (axis 3), along its first and second edges from its corners.
    func frame(of element: Element) -> (
        first: SIMD3<Float>, second: SIMD3<Float>, normal: SIMD3<Float>
    ) {
        guard element.axis == 3 else {
            let k = element.axis
            var first = SIMD3<Float>.zero
            var second = SIMD3<Float>.zero
            var normal = SIMD3<Float>.zero
            first[(k + 1) % 3] = 1
            second[(k + 2) % 3] = 1
            normal[k] = 1
            return (first, second, normal)
        }
        let origin = positions[Int(element.nodes[0])]
        let first = simd_normalize(positions[Int(element.nodes[1])] - origin)
        let second = simd_normalize(positions[Int(element.nodes[3])] - origin)
        return (first, second, simd_cross(first, second))
    }

    package func jointPoints(
        across: Int, normals: [SIMD3<Float>],
        joint: (_ point: SIMD3<Float>, _ node: SIMD3<Float>) -> (slot: Int, normal: SIMD3<Float>)?
    ) -> [[JointPoint]] {
        var points = [[JointPoint]](repeating: [], count: positions.count)
        let intervals = Float(across - 1)
        // Position from -1/2 to 1/2 and weight, summing to one, of point k.
        func point(_ k: Int) -> (offset: Float, weight: Float) {
            (Float(k) / intervals - 0.5, (k == 0 || k == across - 1 ? 0.5 : 1) / intervals)
        }
        func unit(_ axis: Int, _ sign: Float = 1) -> SIMD3<Float> {
            var value = SIMD3<Float>.zero
            value[axis] = sign
            return value
        }
        // Adds the points `arms` (with areas) at `node` of a face whose outward normal is `outward`,
        // where a joint faces it.
        func add(_ node: UInt32, outward: SIMD3<Float>, _ arms: @autoclosure () -> [(SIMD3<Float>, Float)]) {
            guard normals.contains(where: { simd_dot(outward, $0) < -1e-4 }) else { return }
            let at = positions[Int(node)]
            for (arm, area) in arms() {
                guard let held = joint(at + arm, at) else { continue }
                let weight = -simd_dot(outward, held.normal)
                guard weight > 1e-4 else { continue }
                points[Int(node)].append(JointPoint(arm: arm, area: weight * area, slot: held.slot))
            }
        }
        for element in elements {
            let (first, second, normal) = frame(of: element)
            let through = (0..<across).map { point($0) }
            // Free edges: -first (corners 0, 3), +first (1, 2), -second (0, 1), +second (2, 3).
            let edges: [(corners: [Int], outward: SIMD3<Float>, length: Float)] = [
                ([0, 3], -first, element.size.y), ([1, 2], first, element.size.y),
                ([0, 1], -second, element.size.x), ([2, 3], second, element.size.x),
            ]
            for (e, edge) in edges.enumerated() where element.neighbours[e] < 0 {
                let arms = through.map {
                    ($0.offset * element.thickness * normal, $0.weight * element.thickness * edge.length / 2)
                }
                for corner in edge.corners { add(element.nodes[corner], outward: edge.outward, arms) }
            }
            // Its two faces.
            for sign in [Float(-1), 1] {
                for corner in 0..<4 {
                    add(
                        element.nodes[corner], outward: sign * normal,
                        [(sign * element.thickness / 2 * normal, element.size.x * element.size.y / 4)])
                }
            }
        }
        // A beam's end is free where no other beam along its axis carries on from it.
        var ends: [SIMD2<UInt32>: Int] = [:]
        for beam in beams {
            for end in 0..<2 { ends[SIMD2(beam.nodes[end], UInt32(beam.axis)), default: 0] += 1 }
        }
        for beam in beams {
            let a = beam.axis
            let (first, second) = ((a + 1) % 3, (a + 2) % 3)
            for end in 0..<2 {
                let node = beam.nodes[end]
                let along = positions[Int(node)][a] - positions[Int(beam.nodes[1 - end])][a]
                if ends[SIMD2(node, UInt32(a))] == 1 {
                    var arms: [(SIMD3<Float>, Float)] = []
                    for i in 0..<across {
                        for j in 0..<across {
                            let (u, wu) = point(i)
                            let (v, wv) = point(j)
                            arms.append(
                                (
                                    u * beam.section.x * unit(first) + v * beam.section.y * unit(second),
                                    wu * wv * beam.section.x * beam.section.y
                                ))
                        }
                    }
                    add(node, outward: unit(a, along < 0 ? -1 : 1), arms)
                }
                // Its sides, across each at either end over half its length.
                for (side, other, width, depth) in [
                    (first, second, beam.section.y, beam.section.x),
                    (second, first, beam.section.x, beam.section.y),
                ] {
                    for sign in [Float(-1), 1] {
                        let arms = (0..<across).map { k in
                            let (offset, weight) = point(k)
                            return (
                                sign * depth / 2 * unit(side) + offset * width * unit(other),
                                weight * width * beam.length / 2
                            )
                        }
                        add(node, outward: unit(side, sign), arms)
                    }
                }
            }
        }
        // Points of one connection that faces meeting at a node both give are one point, with
        // both shares.
        return points.map { list in
            var merged: [JointPoint] = []
            for point in list {
                if let k = merged.firstIndex(where: {
                    simd_distance($0.arm, point.arm) < 1e-6 && $0.slot == point.slot
                }) {
                    merged[k].area += point.area
                } else {
                    merged.append(point)
                }
            }
            return merged
        }
    }
}
