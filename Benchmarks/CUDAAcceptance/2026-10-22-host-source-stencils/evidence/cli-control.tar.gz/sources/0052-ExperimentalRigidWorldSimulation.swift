import BlastModel
import Foundation
import Metal
import simd

/// Explicit opt-in, synchronous reference for several freestanding objects around a charge: the
/// scenario's rigid objects and cars move and collide together in `RigidBodyWorld`, among its
/// rigid blocks, and those chosen, by default all of them, are also in the air and driven by it
/// as in `ExperimentalRigidBoxSimulation` and `ExperimentalRigidCarSimulation`: each is a moving
/// boundary of the air with its own patches, shields and reflects onto the others, and takes the
/// load of the faces it owns.
///
/// Any left out of the air take no load from it and do not obstruct it: the blast passes through
/// them and their own motion comes only from contact. So does one about to leave the air's
/// domain: it leaves the air for good (`leftAir`) and carries on under gravity and contact.
public final class ExperimentalRigidWorldSimulation {
    public typealias Failure = ExperimentalRigidBoxSimulation.Failure
    public typealias Motion = ExperimentalRigidBoxSimulation.Motion
    public typealias Timings = ExperimentalRigidCarSimulation.Timings

    public struct Member: Sendable, Codable {
        public let name: String
        public let isCar: Bool
        public let corners: [SIMD3<Double>]
        /// Tyre contact points, for cars: FL, FR, RL, RR.
        public let tyres: [SIMD3<Double>]
        public let centreOfMass: SIMD3<Double>
        public let velocity: SIMD3<Double>
        public let orientation: SIMD4<Double>
        /// Angle between the body's up axis and the vertical (degrees).
        public var tilt: Double {
            acos(min(1, max(-1, simd_quatd(vector: orientation).act(SIMD3<Double>(0, 0, 1)).z))) * 180 / .pi
        }

        /// Angle between the body's up axis and `up`, a unit vector (degrees).
        public func tilt(from up: SIMD3<Double>) -> Double {
            acos(min(1, max(-1, simd_dot(simd_quatd(vector: orientation).act(SIMD3<Double>(0, 0, 1)), up))))
                * 180 / .pi
        }
    }

    public let air: BlastSolver
    public let motion: Motion
    /// The members put in the air, in order.
    public let coupled: [Int]
    /// When each member that left the air did so (s).
    public private(set) var leftAir: [Int: Double] = [:]
    public let names: [String]
    public var gravity = SIMD3<Double>(0, 0, -9.81)
    private var world: RigidBodyWorld
    private let carCount: Int
    /// The air's impulse over the last step on all the members together, and on each.
    public private(set) var lastImpulse = SIMD3<Double>.zero
    public private(set) var lastAngularImpulse = SIMD3<Double>.zero
    public private(set) var lastAirImpulses: [SIMD3<Double>] = []
    public private(set) var lastAirAngularImpulses: [SIMD3<Double>] = []
    /// Contact impulse on each member over the last step: ground, blocks and other members.
    public private(set) var lastContactImpulses: [SIMD3<Double>] = []
    public private(set) var timings = Timings()
    /// The structures' nodes the members strike, when the air holds structures.
    private var contact = StructureNodeContact([])
    /// Impulse the members gave the structures over the last step and since the start (N s).
    public private(set) var lastReaction = SIMD3<Double>.zero
    public private(set) var reaction = SIMD3<Double>.zero

    public init(
        device: MTLDevice, scenario: Scenario, cellSize: Float,
        configuration: SolverConfiguration = SolverConfiguration(), motion: Motion = .free,
        coupled: [Int]? = nil
    ) throws {
        let objects = scenario.rigidObjects ?? []
        let cars = scenario.rigidCars ?? []
        // Beside a structure, stage 1 of the two sharing the air holds them to the coarse grid.
        let hasStructure = !scenario.structuralObjects.compactMap(\.structure).isEmpty
        guard objects.count + cars.count >= 1,
            (hasStructure ? [0, 1] : [0, 1, 2, 4]).contains(configuration.refinement),
            !configuration.afterburning,
            configuration.airModel == .idealGas, configuration.twoWayCoupling, configuration.movingWalls
        else { throw Failure.unsupportedConfiguration }
        let built = try RigidBodyWorld(scenario: scenario)
        world = built
        names = objects.map(\.name) + cars.map(\.name)
        carCount = cars.count
        self.coupled = Array(Set(coupled ?? Array(built.members.indices))).sorted()
        guard !self.coupled.isEmpty, self.coupled.allSatisfy(built.members.indices.contains) else {
            throw Failure.unsupportedConfiguration
        }
        self.motion = motion
        var config = configuration
        config.skipStillAir = false
        config.mappedCharge = false
        var initial = scenario
        initial.charge.mass = 0
        initial.additionalCharges = nil
        initial.rigidObjects = nil
        initial.rigidCars = nil
        // The structures stay in the air; the members are installed after them.
        air = try BlastSolver(device: device, scenario: initial, cellSize: cellSize, configuration: config)
        try air.installExperimentalBoxes(self.coupled.map { built.members[$0].body })
        contact = StructureNodeContact(air.bodies)
        world.nodeFriction = RigidBoxBody.Ground(staticFriction: 0.6, slidingFriction: 0.5)
        air.deposit(scenario.charge)
        for charge in scenario.additionalCharges ?? [] { air.deposit(charge) }
        air.restart()
        try air.checkExperimentalBoxRefinement()
        air.removeExperimentalBoxPackedGas()
        lastContactImpulses = Array(repeating: .zero, count: built.members.count)
        lastAirImpulses = lastContactImpulses
        lastAirAngularImpulses = lastContactImpulses
    }

    /// The member nearest the charge, for coupling one object alone.
    public static func nearest(in scenario: Scenario) throws -> Int {
        let world = try RigidBodyWorld(scenario: scenario)
        let charge = SIMD3<Double>(scenario.charge.position)
        guard
            let nearest = world.members.indices.min(by: {
                simd_distance(world.members[$0].body.worldPoint(.zero), charge)
                    < simd_distance(world.members[$1].body.worldPoint(.zero), charge)
            })
        else { throw Failure.unsupportedConfiguration }
        return nearest
    }

    public var count: Int { world.members.count }

    public var members: [Member] {
        world.members.enumerated().map { n, member in
            Member(
                name: names[n], isCar: n >= world.members.count - carCount, corners: member.body.corners,
                tyres: member.supports.map(member.body.worldPoint), centreOfMass: member.body.position,
                velocity: member.body.linearVelocity, orientation: member.body.orientation.vector)
        }
    }

    public var linearMomentum: SIMD3<Double> { world.linearMomentum }

    public func applyImpulse(_ impulse: SIMD3<Double>, to member: Int, at point: SIMD3<Double>? = nil) throws
    {
        guard motion == .free else { throw Failure.unsupportedConfiguration }
        world.applyImpulse(impulse, to: member, at: point)
        if coupled.contains(member) {
            try air.updateExperimentalBoxes(coupled.map { world.members[$0].body })
        }
    }
    public var kineticEnergy: Double { world.kineticEnergy }

    /// The coupled members' bodies for the air, nil for those out of it: a member whose corners
    /// come within two cells of the domain's sides or top leaves the air.
    private func inAir(_ world: RigidBodyWorld) -> [RigidBoxBody?] {
        let domain = SIMD3<Double>(air.grid.size)
        let margin = 2 * Double(air.grid.cellSize)
        return coupled.map { n in
            let body = world.members[n].body
            if leftAir[n] == nil,
                body.corners.contains(where: {
                    $0.x < margin || $0.y < margin || $0.x > domain.x - margin || $0.y > domain.y - margin
                        || $0.z > domain.z - margin
                })
            {
                leftAir[n] = air.time
            }
            return leftAir[n] == nil ? body : nil
        }
    }

    /// Always step through this driver: each air step is followed by a world step.
    public func advance(steps: Int, timeLimit: Double? = nil) throws {
        precondition(steps >= 0)
        var clock = Date.timeIntervalSinceReferenceDate
        func lap(_ phase: WritableKeyPath<Timings, Double>) {
            let now = Date.timeIntervalSinceReferenceDate
            timings[keyPath: phase] += now - clock
            clock = now
        }
        for _ in 0..<steps {
            // While a member is near a structure, each air step is one of the structure's steps,
            // so that their contact keeps the structure's time.
            air.experimentalStepCeiling =
                contact.isNear(world.members.map(\.body), margin: 0.5) ? contact.step : nil
            try air.checkExperimentalBoxRefinement()
            try air.clearExperimentalBoxImpulse()
            lap(\.coupling)
            let result = air.advance(steps: 1, timeLimit: timeLimit)
            lap(\.air)
            if let timeLimit, result.elapsed == 0, air.time >= timeLimit - 1e-8 { return }
            guard result.isStable, result.elapsed > 0 else { throw Failure.unstable }
            let loads = air.experimentalBoxLoads()
            lastAirImpulses = Array(repeating: .zero, count: world.members.count)
            lastAirAngularImpulses = lastAirImpulses
            for (load, member) in zip(loads, coupled) {
                lastAirImpulses[member] = load.linear
                lastAirAngularImpulses[member] = load.angular
            }
            lastImpulse = loads.reduce(.zero) { $0 + $1.linear }
            lastAngularImpulse = loads.reduce(.zero) { $0 + $1.angular }
            lap(\.coupling)
            guard motion == .free else { continue }
            var next = world
            for (load, member) in zip(loads, coupled) {
                next.applyImpulse(load.linear, to: member)
                next.applyAngularImpulse(load.angular, to: member)
            }
            let struck = contact.gather(next.members.map(\.body), step: result.elapsed)
            next.nodes = struck
            let contacts = next.advance(by: result.elapsed, gravity: gravity)
            lastReaction = .zero
            for hit in contacts {
                guard case .node = hit.other else { continue }
                lastReaction -= hit.normalImpulse * hit.normal + hit.tangentImpulse
            }
            reaction += lastReaction
            contact.write(next.nodes, over: struck)
            next.nodes = []
            lap(\.mechanics)
            try air.updateExperimentalBoxes(inAir(next))
            lap(\.coupling)
            var contactImpulses = [SIMD3<Double>](repeating: .zero, count: next.members.count)
            for contact in contacts {
                let impulse = contact.normalImpulse * contact.normal + contact.tangentImpulse
                contactImpulses[contact.member] += impulse
                if case .member(let j) = contact.other { contactImpulses[j] -= impulse }
            }
            lastContactImpulses = contactImpulses
            world = next
        }
    }
}
