import simd

/// CPU-only prescribed-motion geometry. Temporal midpoint quadrature is compared with
/// exact endpoint volume; it is not assumed conservative when walls cross cell boundaries.
public enum ExperimentalRigidBoxMotionStudy {
    public enum Integration: String, Codable, Sendable { case midpoint, eventSplitGauss, adaptiveGauss }
    public struct Result: Codable, Sendable {
        public let integration: Integration
        public let integrationIntervals: Int
        public let volumeTolerance: Double?
        public let quadratureVolumeError: Double?
        public let kind: String
        public let cellSize: Double
        public let temporalSamples: Int
        public let duration: Double
        public let solidVolumeChange: Double
        public let sweptVolume: Double
        public let volumeResidual: Double
        public let gasPressureWork: Double
        public let bodyPressureWork: Double
        public let workBalanceResidual: Double
        public let endpointPressureWork: Double
        /// Open face area integrated over time, in m² s (-x,+x,-y,+y,-z,+z).
        public let integratedOpenFaceAreas: [Double]?
        public let faceAreaTimeErrorEstimate: Double?
        public let faceAreaTimeTolerance: Double?

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            integration: Integration,
            integrationIntervals: Int,
            volumeTolerance: Double?,
            quadratureVolumeError: Double?,
            kind: String,
            cellSize: Double,
            temporalSamples: Int,
            duration: Double,
            solidVolumeChange: Double,
            sweptVolume: Double,
            volumeResidual: Double,
            gasPressureWork: Double,
            bodyPressureWork: Double,
            workBalanceResidual: Double,
            endpointPressureWork: Double,
            integratedOpenFaceAreas: [Double]?,
            faceAreaTimeErrorEstimate: Double?,
            faceAreaTimeTolerance: Double?
        ) {
            self.integration = integration
            self.integrationIntervals = integrationIntervals
            self.volumeTolerance = volumeTolerance
            self.quadratureVolumeError = quadratureVolumeError
            self.kind = kind
            self.cellSize = cellSize
            self.temporalSamples = temporalSamples
            self.duration = duration
            self.solidVolumeChange = solidVolumeChange
            self.sweptVolume = sweptVolume
            self.volumeResidual = volumeResidual
            self.gasPressureWork = gasPressureWork
            self.bodyPressureWork = bodyPressureWork
            self.workBalanceResidual = workBalanceResidual
            self.endpointPressureWork = endpointPressureWork
            self.integratedOpenFaceAreas = integratedOpenFaceAreas
            self.faceAreaTimeErrorEstimate = faceAreaTimeErrorEstimate
            self.faceAreaTimeTolerance = faceAreaTimeTolerance
        }
    }

    public static func run() throws -> [Result] {
        var results: [Result] = []
        for h in [0.2, 0.1, 0.05] {
            for kind in ["translation-crossing", "rotation", "rotated-translation", "ground-gap-opening"] {
                for samples in [8, 32, 128] {
                    results.append(try measure(kind: kind, cellSize: h, samples: samples))
                }
                if kind == "translation-crossing" || kind == "ground-gap-opening" {
                    results.append(try measure(kind: kind, cellSize: h, samples: 0, eventSplit: true))
                } else {
                    results.append(try measure(kind: kind, cellSize: h, samples: 0, adaptive: true))
                }
            }
        }
        return results
    }

    private static func measure(
        kind: String, cellSize h: Double, samples: Int, eventSplit: Bool = false, adaptive: Bool = false
    )
        throws -> Result
    {
        let duration = 0.02
        let pressure = 101325.0
        let axis = simd_normalize(SIMD3<Double>(1, 2, 3))
        let rotating = kind == "rotation"
        let tilted = rotating || kind == "rotated-translation"
        let gap = kind == "ground-gap-opening"
        let start = gap ? SIMD3<Double>(2, 2, 0.40001) : SIMD3<Double>(2.095, 2, 2)
        let velocity = rotating ? SIMD3<Double>.zero : gap ? SIMD3(0, 0, 0.6) : SIMD3(6, 0, 0)
        let spin = rotating ? 4 * axis : .zero
        let lower =
            gap
            ? SIMD3<Double>(2 - h, 2 - h, 0)
            : rotating
                ? SIMD3(2.475, 2 - h / 2, 2 - h / 2)
                : SIMD3(floor(2.495 / h) * h, 2 - h / 2, 2 - h / 2)
        func body(at time: Double) throws -> RigidBoxBody {
            try RigidBoxBody(
                mass: 2, size: SIMD3(repeating: 0.8), position: start + time * velocity,
                orientation: simd_quatd(angle: tilted ? 0.11 + (rotating ? 4 * time : 0) : 0, axis: axis))
        }
        if eventSplit {
            let sweep = try TranslatingBoxCellSweep.integrate(
                body: body(at: 0), velocity: velocity,
                lower: lower, cellSize: h, duration: duration, pressure: pressure)
            return Result(
                integration: .eventSplitGauss, integrationIntervals: sweep.intervals,
                volumeTolerance: nil, quadratureVolumeError: nil,
                kind: kind, cellSize: h, temporalSamples: sweep.evaluations, duration: duration,
                solidVolumeChange: sweep.volumeChange, sweptVolume: sweep.sweptVolume,
                volumeResidual: sweep.sweptVolume - sweep.volumeChange,
                gasPressureWork: sweep.gasWork, bodyPressureWork: sweep.bodyWork,
                workBalanceResidual: sweep.gasWork + sweep.bodyWork,
                endpointPressureWork: pressure * sweep.volumeChange,
                integratedOpenFaceAreas: sweep.integratedOpenFaceAreas,
                faceAreaTimeErrorEstimate: nil, faceAreaTimeTolerance: nil)
        }
        if adaptive {
            let tolerance = h * h * h * 1e-9
            let sweep = try AdaptiveBoxCellSweep.integrate(
                body: body(at: 0), velocity: velocity, spin: spin,
                lower: lower, cellSize: h, duration: duration, pressure: pressure, volumeTolerance: tolerance)
            return Result(
                integration: .adaptiveGauss, integrationIntervals: sweep.intervals,
                volumeTolerance: tolerance, quadratureVolumeError: sweep.errorEstimate,
                kind: kind, cellSize: h, temporalSamples: sweep.evaluations, duration: duration,
                solidVolumeChange: sweep.volumeChange, sweptVolume: sweep.sweptVolume,
                volumeResidual: sweep.sweptVolume - sweep.volumeChange,
                gasPressureWork: sweep.gasWork, bodyPressureWork: sweep.bodyWork,
                workBalanceResidual: sweep.gasWork + sweep.bodyWork,
                endpointPressureWork: pressure * sweep.volumeChange,
                integratedOpenFaceAreas: sweep.integratedOpenFaceAreas,
                faceAreaTimeErrorEstimate: sweep.faceAreaTimeErrorEstimate,
                faceAreaTimeTolerance: sweep.faceAreaTimeTolerance)
        }
        let initial = FractionalBoxGeometry(try body(at: 0)).solidVolumeFraction(lower: lower, cellSize: h)
        let final = FractionalBoxGeometry(try body(at: duration)).solidVolumeFraction(
            lower: lower, cellSize: h)
        let change = (final - initial) * h * h * h
        var swept = 0.0
        var gasWork = 0.0
        var bodyWork = 0.0
        var integratedOpenFaceAreas = [Double](repeating: 0, count: 6)
        let dt = duration / Double(samples)
        for n in 0..<samples {
            let current = try body(at: (Double(n) + 0.5) * dt)
            let geometry = FractionalBoxGeometry(current)
            let faces = geometry.openFacePatches(lower: lower, cellSize: h)
            for side in 0..<6 { integratedOpenFaceAreas[side] += dt * faces[side].area }
            func wallVelocity(_ point: SIMD3<Double>) -> SIMD3<Double> {
                velocity + simd_cross(spin, point - current.position)
            }
            for wall in geometry.wallPatches(lower: lower, cellSize: h) {
                swept += dt * wall.sweptVolumeRate(velocity: wallVelocity)
                gasWork += dt * wall.gasPressurePower(velocity: wallVelocity) { _ in pressure }
                let load = wall.pressureLoad(about: current.position) { _ in pressure }
                bodyWork += dt * (simd_dot(load.force, velocity) + simd_dot(load.torque, spin))
            }
        }
        return Result(
            integration: .midpoint, integrationIntervals: samples,
            volumeTolerance: nil, quadratureVolumeError: nil,
            kind: kind, cellSize: h, temporalSamples: samples, duration: duration,
            solidVolumeChange: change, sweptVolume: swept, volumeResidual: swept - change,
            gasPressureWork: gasWork, bodyPressureWork: bodyWork, workBalanceResidual: gasWork + bodyWork,
            endpointPressureWork: pressure * change, integratedOpenFaceAreas: integratedOpenFaceAreas,
            faceAreaTimeErrorEstimate: nil, faceAreaTimeTolerance: nil)
    }
}
