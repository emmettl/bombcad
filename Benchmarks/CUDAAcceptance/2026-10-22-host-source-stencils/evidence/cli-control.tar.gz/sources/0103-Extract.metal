// What the models alongside the blast need from the air at a frame, cut out on the GPU at the end
// of the batch that lands on the frame, rather than read from the state on the CPU while the GPU
// waits (see FrameExtraction.swift). Each kernel does nothing unless the batch's last step reached
// its time limit, which is how a batch lands on a frame; the host keeps what they wrote only then.

// Whether `x` is a finite number, by its bits: fast maths may take any comparison or isfinite to
// hold for infinities and NaNs.
static inline bool finiteBits(float x) {
    return (as_type<uint>(x) & 0x7f800000u) != 0x7f800000u;
}

// The air at every `stride`-th cell from `first`, `counts` of them along each axis, as half floats,
// five a sample, x fastest: density, velocity, and pressure in MPa, as `AirSlice` holds them. The
// velocity and pressure are worked out as the CPU's `BlastSolver.primitive` does them, without a
// density floor, so a solid cell's stale state reads as it would there.
kernel void extractAirSlice(
    device const StepControl &control [[buffer(0)]],
    device const Cell *state [[buffer(1)]],
    device half *values [[buffer(2)]],
    constant int4 *layout [[buffer(3)]],
    constant SolverUniforms &u [[buffer(4)]],
    uint3 id [[thread_position_in_grid]])
{
    if (control.stopped != 2) {
        return;
    }
    int4 first = layout[0];
    int4 counts = layout[1];
    if (int(id.x) >= counts.x || int(id.y) >= counts.y || int(id.z) >= counts.z) {
        return;
    }
    int3 cell = first.xyz + int3(id) * first.w;
    Cell c = state[uint(cell.x) + u.nx * (uint(cell.y) + u.ny * uint(cell.z))];
    float3 velocity = float3(c.mx, c.my, c.mz) / c.rho;
    float kinetic = 0.5f * c.rho * dot(velocity, velocity);
    float pressure = gasPressure(c.rho, c.energy - kinetic, u.airModel, u.gamma);
    uint n = 5u * (id.x + uint(counts.x) * (id.y + uint(counts.y) * id.z));
    values[n] = half(c.rho);
    values[n + 1] = half(velocity.x);
    values[n + 2] = half(velocity.y);
    values[n + 3] = half(velocity.z);
    values[n + 4] = half(pressure / 1.0e6f);
}

// A cell's temperature if it is air at least `luminous` kelvin hot, and otherwise zero, as the
// CPU's `BlastSolver.fireball` works it out.
static inline float luminousTemperatureOf(Cell c, float luminous, constant SolverUniforms &u) {
    float3 velocity = float3(c.mx, c.my, c.mz) / c.rho;
    float kinetic = 0.5f * c.rho * dot(velocity, velocity);
    float pressure = gasPressure(c.rho, c.energy - kinetic, u.airModel, u.gamma);
    // Dissociating air is never hotter than this, so it bounds the search.
    float bound = pressure / (c.rho * airGasConstant);
    if (!finiteBits(bound) || !(bound >= luminous)) {
        return 0.0f;
    }
    float t = airModelOf(u.airModel) == airDissociating ? dissociatingTemperatureAt(c.rho, pressure) : bound;
    if (!finiteBits(t) || !(t >= luminous)) {
        return 0.0f;
    }
    return t;
}

// The luminous gas in one block of two cells a side, block `id`: for a block with any cell at
// least `luminous` kelvin, its index, how many of its cells are luminous, the sum of their
// temperatures to the fourth power and the hottest; the sums of their i, j and k + 1/2; and how
// many of its cells are air. Appended in whatever order the threads reach them, after `count`
// others; the host sorts them by index, so the fireball is the same from one run to the next.
kernel void extractFireballBlocks(
    device const StepControl &control [[buffer(0)]],
    device const Cell *state [[buffer(1)]],
    device const uchar *mask [[buffer(2)]],
    device uint4 *blocks [[buffer(3)]],
    device atomic_uint *count [[buffer(4)]],
    constant float &luminous [[buffer(5)]],
    constant SolverUniforms &u [[buffer(6)]],
    uint3 id [[thread_position_in_grid]])
{
    uint3 dims = (uint3(u.nx, u.ny, u.nz) + 1u) / 2u;
    if (control.stopped != 2 || id.x >= dims.x || id.y >= dims.y || id.z >= dims.z) {
        return;
    }
    uint3 low = 2u * id;
    uint3 high = min(low + 2u, uint3(u.nx, u.ny, u.nz));
    float cells = 0.0f;
    float air = 0.0f;
    float3 position = float3(0.0f);
    float fourth = 0.0f;
    float hottest = 0.0f;
    for (uint k = low.z; k < high.z; ++k) {
        for (uint j = low.y; j < high.y; ++j) {
            for (uint i = low.x; i < high.x; ++i) {
                uint index = i + u.nx * (j + u.ny * k);
                if (mask[index] != 0) {
                    continue;
                }
                air += 1.0f;
                float t = luminousTemperatureOf(state[index], luminous, u);
                if (t == 0.0f) {
                    continue;
                }
                cells += 1.0f;
                position += float3(i, j, k) + 0.5f;
                float square = t * t;
                fourth += square * square;
                hottest = max(hottest, t);
            }
        }
    }
    if (cells == 0.0f) {
        return;
    }
    uint slot = atomic_fetch_add_explicit(count, 1u, memory_order_relaxed);
    uint index = id.x + dims.x * (id.y + dims.y * id.z);
    blocks[2 * slot] = uint4(index, as_type<uint>(cells), as_type<uint>(fourth), as_type<uint>(hottest));
    blocks[2 * slot + 1] = as_type<uint4>(float4(position, air));
}

// Every cell's luminous gas, for the fireball as a volume: in the low 16 bits its temperature if
// it is air at least `luminous` kelvin hot, rounded to the kelvin, and otherwise zero; in the high
// 16, the density of its unburnt detonation products in kg/m³ as a half float, zero without
// afterburning or where it is not luminous. The host reads back only the luminous blocks' box.
// Hot equilibrium air's Planck mean absorption coefficient at `t` K and `rho` kg/m^3, in 1/m: the
// CPU's `HotAir.planckAbsorption` (Kivel and Bailey, as NASA TN D-1031 correlates them), its
// logarithm at the normal density 1.293 kg/m^3 and the density's exponent at each temperature.
static inline float hotAirAbsorption(float t, float rho) {
    const float temperatures[6] = {1000.0f, 3000.0f, 6000.0f, 8000.0f, 12000.0f, 18000.0f};
    const float logKappa[6] = {-8.36160f, -3.57248f, -0.17727f, 1.16553f, 3.83899f, 6.42003f};
    const float exponents[6] = {1.000f, 1.228f, 1.337f, 1.288f, 1.356f, 1.579f};
    if (!(t > 0.0f) || !(rho > 0.0f)) {
        return 0.0f;
    }
    float c = clamp(t, 1000.0f, 18000.0f);
    int n = 0;
    while (n < 4 && c > temperatures[n + 1]) {
        n += 1;
    }
    float share = log(c / temperatures[n]) / log(temperatures[n + 1] / temperatures[n]);
    float lk = logKappa[n] + share * (logKappa[n + 1] - logKappa[n]);
    float tau = exponents[n] + share * (exponents[n + 1] - exponents[n]);
    return exp(lk + tau * log(rho / 1.293f));
}

// Each cell's luminous temperature in kelvin (the low 16 bits of x) and its unburnt products'
// density as a half (the high), and in y its absorption as hot air (`hotAirAbsorption`) as a half;
// all zero where it is not luminous.
kernel void extractLuminousCells(
    device const StepControl &control [[buffer(0)]],
    device const Cell *state [[buffer(1)]],
    device const uchar *mask [[buffer(2)]],
    device const float2 *species [[buffer(3)]],
    device uint2 *cells [[buffer(4)]],
    constant float &luminous [[buffer(5)]],
    constant uint &hasSpecies [[buffer(6)]],
    constant SolverUniforms &u [[buffer(7)]],
    uint3 id [[thread_position_in_grid]])
{
    if (control.stopped != 2 || id.x >= u.nx || id.y >= u.ny || id.z >= u.nz) {
        return;
    }
    uint index = id.x + u.nx * (id.y + u.ny * id.z);
    float t = mask[index] != 0 ? 0.0f : luminousTemperatureOf(state[index], luminous, u);
    uint kelvin = t == 0.0f ? 0u : clamp(uint(rint(t)), 1u, 65535u);
    float products = kelvin != 0u && hasSpecies != 0u ? max(species[index].x, 0.0f) : 0.0f;
    float air = kelvin != 0u ? min(hotAirAbsorption(t, state[index].rho), 65504.0f) : 0.0f;
    cells[index] = uint2(
        kelvin | (uint(as_type<ushort>(half(min(products, 65504.0f)))) << 16), uint(as_type<ushort>(half(air))));
}

// The visualisation field (updateVisualization in SolverVisualization.metal: r overpressure, g peak and a
// shock indicator, all over ambient, b impulse) every `layout.x`-th cell along each axis, as half4
// texels, x fastest, for a view of the run drawn elsewhere. Each texel keeps its block's extremes
// rather than their mean, so a front one cell thick still shows: the largest peak, impulse and
// shock indicator, and the overpressure of the largest magnitude, its sign kept. With `layout.y`
// 1 it writes whatever the batch reached, for a field read between batches.
kernel void extractViewField(
    device const StepControl &control [[buffer(0)]],
    device half4 *values [[buffer(1)]],
    constant uint4 &layout [[buffer(2)]],
    texture3d<float, access::read> field [[texture(0)]],
    uint3 id [[thread_position_in_grid]])
{
    // layout.y: 0 writes only at the end of a batch that reached its time limit, 1 always, 2 once
    // the run's clock has reached the tick in layout.z (low word) and layout.w (high word), a
    // recorder's next frame (`ViewFieldCapture`).
    if (layout.y == 0 && control.stopped != 2) {
        return;
    }
    if (layout.y == 2
        && (ulong(control.clockLow) | (ulong(control.clockHigh) << 32)) < (ulong(layout.z) | (ulong(layout.w) << 32))) {
        return;
    }
    uint stride = layout.x;
    uint3 fineSize = uint3(field.get_width(), field.get_height(), field.get_depth());
    uint3 size = (fineSize + stride - 1) / stride;
    if (any(id >= size)) {
        return;
    }
    float4 best = float4(0.0f);
    float strongest = -1.0f;
    for (uint z = 0; z < stride; ++z) {
        for (uint y = 0; y < stride; ++y) {
            for (uint x = 0; x < stride; ++x) {
                uint3 p = id * stride + uint3(x, y, z);
                if (any(p >= fineSize)) {
                    continue;
                }
                float4 value = field.read(p);
                if (abs(value.r) > strongest) {
                    strongest = abs(value.r);
                    best.r = value.r;
                }
                best.gba = max(best.gba, value.gba);
            }
        }
    }
    values[id.x + size.x * (id.y + size.y * id.z)] = half4(best);
}

// Same write predicate as extractViewField. These are display copies only, never solver inputs.
static inline bool writeBodyView(device const StepControl &control, constant uint4 &layout) {
    if (layout.y == 1u) { return true; }
    if (layout.y == 2u) {
        return (ulong(control.clockLow) | (ulong(control.clockHigh) << 32))
            >= (ulong(layout.z) | (ulong(layout.w) << 32));
    }
    return control.stopped == 2;
}

kernel void extractSolidViewNodes(
    device const StepControl &control [[buffer(0)]],
    device const StructureNode *nodes [[buffer(1)]],
    device float3 *displacements [[buffer(2)]],
    constant uint4 &layout [[buffer(4)]], uint id [[thread_position_in_grid]])
{
    if (writeBodyView(control, layout)) { displacements[id] = float3(nodes[id].displacement); }
}

kernel void extractSolidViewDamage(
    device const StepControl &control [[buffer(0)]],
    device const ElementState *states [[buffer(1)]],
    device float *damage [[buffer(2)]],
    constant uint4 &layout [[buffer(4)]], uint id [[thread_position_in_grid]])
{
    if (writeBodyView(control, layout)) { damage[id] = states[id].display; }
}

kernel void extractShellViewNodes(
    device const StepControl &control [[buffer(0)]],
    device const ShellNode *nodes [[buffer(1)]],
    device float3 *displacements [[buffer(2)]],
    device float4 *rotations [[buffer(3)]],
    constant uint4 &layout [[buffer(4)]], uint id [[thread_position_in_grid]])
{
    if (writeBodyView(control, layout)) {
        displacements[id] = float3(nodes[id].displacement);
        rotations[id] = nodes[id].rotation;
    }
}
