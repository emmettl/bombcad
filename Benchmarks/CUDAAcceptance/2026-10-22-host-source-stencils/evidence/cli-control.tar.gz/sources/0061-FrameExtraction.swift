import BlastModel
import Metal
import simd

/// Cuts the air out on the GPU for `BlastSolver`: kernels encoded at the end of each batch while a
/// request stands, which write only in a batch that reaches its time limit, and what they wrote,
/// kept for the moment that batch ended. Reading the state on the CPU between batches instead
/// leaves the GPU waiting: a few milliseconds a frame each for the fragments and the fireball on
/// the medium street grid (see docs/distributed-computing.md).
final class FrameExtractor {
    private let device: MTLDevice
    private let airPipeline: MTLComputePipelineState
    private let fireballPipeline: MTLComputePipelineState
    private let cellsPipeline: MTLComputePipelineState
    private let bodyExtractor: BodyViewExtractor
    private var readyBodies: (time: Double, steps: Int)?
    private let viewPipeline: MTLComputePipelineState
    private var viewBuffer: MTLBuffer?
    /// The view field's stride the batch in flight was asked for, and what the last completed
    /// batch cut out, as `encoded` and `ready` are for the rest.
    private var encodedView: Int?
    private var readyView: (time: Double, steps: Int, stride: Int)?
    /// A recorder's view field (`ViewFieldCapture`), in a buffer of its own, so that it and a
    /// request's at another stride can stand together: the stride and the clock from which the
    /// batch in flight cuts it out, and what the last completed batch cut out.
    private var captureBuffer: MTLBuffer?
    private var encodedCapture: (stride: Int, fromTicks: UInt64)?
    private var readyCapture: (time: Double, steps: Int, stride: Int)?
    private var airBuffer: MTLBuffer?
    private var cellsBuffer: MTLBuffer?
    private var blocksBuffer: MTLBuffer?
    private var blockCountBuffer: MTLBuffer?
    /// What the batch in flight was asked for.
    private var encoded: (air: AirSlice.Layout?, luminous: Float?, cells: Bool)?
    /// What the last completed batch cut out, and the moment and step it ended at; nil when
    /// nothing is ready or the state has changed since.
    private(set) var ready: (time: Double, steps: Int, air: AirSlice.Layout?, luminous: Float?, cells: Bool)?

    init(library: MTLLibrary) throws {
        device = library.device
        bodyExtractor = try BodyViewExtractor(library: library)
        airPipeline = try ShaderLibrary.pipeline("extractAirSlice", in: library)
        fireballPipeline = try ShaderLibrary.pipeline("extractFireballBlocks", in: library)
        cellsPipeline = try ShaderLibrary.pipeline("extractLuminousCells", in: library)
        viewPipeline = try ShaderLibrary.pipeline("extractViewField", in: library)
    }

    /// The view field's texels along each axis, `stride` times coarser than `grid`, rounded up.
    static func viewFieldSize(_ grid: Grid, stride: Int) -> SIMD3<Int> {
        (SIMD3(grid.nx, grid.ny, grid.nz) &+ (stride - 1)) / stride
    }

    /// When the view field's kernel writes: at the end of a batch that reached its time limit,
    /// whatever the batch, or once the run's clock has reached a tick (`ViewFieldCapture`).
    enum ViewFieldWrite {
        case atLimit
        case always
        case from(ticks: UInt64)
    }

    /// Encodes the view field's kernel after the visualisation has been brought up to date in the
    /// same encoder, writing as `write` says: into the request's buffer, or with `capture` the
    /// recorder's.
    func encodeViewField(
        _ encoder: MTLComputeCommandEncoder, stride: Int, grid: Grid, field: MTLTexture, control: MTLBuffer,
        write: ViewFieldWrite, capture: Bool = false, bodies: [StructuralBody]? = nil
    ) {
        let size = Self.viewFieldSize(grid, stride: stride)
        let bytes = 8 * size.x * size.y * size.z
        func sized(_ buffer: inout MTLBuffer?) -> MTLBuffer? {
            if (buffer?.length ?? 0) < bytes {
                buffer = device.makeBuffer(length: bytes, options: .storageModeShared)
            }
            return buffer
        }
        guard let target = capture ? sized(&captureBuffer) : sized(&viewBuffer) else { return }
        var layout: SIMD4<UInt32> =
            switch write {
            case .atLimit: SIMD4(UInt32(stride), 0, 0, 0)
            case .always: SIMD4(UInt32(stride), 1, 0, 0)
            case .from(let ticks):
                SIMD4(
                    UInt32(stride), 2, UInt32(truncatingIfNeeded: ticks),
                    UInt32(truncatingIfNeeded: ticks >> 32))
            }
        encoder.setComputePipelineState(viewPipeline)
        encoder.setBuffer(control, offset: 0, index: 0)
        encoder.setBuffer(target, offset: 0, index: 1)
        encoder.setBytes(&layout, length: MemoryLayout<SIMD4<UInt32>>.stride, index: 2)
        encoder.setTexture(field, index: 0)
        encoder.dispatchThreads(
            MTLSize(width: size.x, height: size.y, depth: size.z),
            threadsPerThreadgroup: Self.threadgroup(viewPipeline, depth: true))
        if let bodies { bodyExtractor.encode(encoder, bodies: bodies, control: control, layout: layout) }
        switch (write, capture) {
        case (.atLimit, false): encodedView = stride
        case (.from(let ticks), true): encodedCapture = (stride, ticks)
        default: break
        }
    }

    /// The view field as written last into the request's buffer, `size` texels, eight bytes each.
    func viewFieldData(_ size: SIMD3<Int>) -> Data? {
        guard let viewBuffer else { return nil }
        return Data(bytes: viewBuffer.contents(), count: 8 * size.x * size.y * size.z)
    }

    /// The view field cut out at `stride` at `time` and `steps`, if it is ready: a request's, or a
    /// recorder's.
    func viewField(stride: Int, grid: Grid, time: Double, steps: Int) -> Data? {
        let size = Self.viewFieldSize(grid, stride: stride)
        if let readyView, readyView.time == time, readyView.steps == steps, readyView.stride == stride {
            return viewFieldData(size)
        }
        if let readyCapture, readyCapture.time == time, readyCapture.steps == steps,
            readyCapture.stride == stride, let captureBuffer
        {
            return Data(bytes: captureBuffer.contents(), count: 8 * size.x * size.y * size.z)
        }
        return nil
    }

    /// Encodes the request's kernels at the end of a batch, after its last step.
    func encode(
        _ encoder: MTLComputeCommandEncoder, request: FrameRequest, grid: Grid, state: MTLBuffer,
        mask: MTLBuffer, species: MTLBuffer, hasSpecies: Bool, control: MTLBuffer, uniforms: SolverUniforms
    ) {
        readyBodies = nil
        ready = nil
        readyView = nil
        encodedView = nil
        readyCapture = nil
        encodedCapture = nil
        var uniforms = uniforms
        var air: AirSlice.Layout?
        if let slice = request.airSlice {
            let layout = AirSlice.layout(region: slice.region, stride: slice.stride, grid: grid)
            let bytes = 2 * 5 * layout.sampleCount
            if (airBuffer?.length ?? 0) < bytes {
                airBuffer = device.makeBuffer(length: bytes, options: .storageModeShared)
            }
            if let airBuffer {
                var corners = [
                    SIMD4<Int32>(layout.first, layout.stride), SIMD4<Int32>(layout.counts, 0),
                ]
                encoder.setComputePipelineState(airPipeline)
                encoder.setBuffer(control, offset: 0, index: 0)
                encoder.setBuffer(state, offset: 0, index: 1)
                encoder.setBuffer(airBuffer, offset: 0, index: 2)
                encoder.setBytes(&corners, length: MemoryLayout<SIMD4<Int32>>.stride * 2, index: 3)
                encoder.setBytes(&uniforms, length: MemoryLayout<SolverUniforms>.stride, index: 4)
                encoder.dispatchThreads(
                    MTLSize(
                        width: Int(layout.counts.x), height: Int(layout.counts.y), depth: Int(layout.counts.z)
                    ),
                    threadsPerThreadgroup: Self.threadgroup(airPipeline, depth: true))
                air = layout
            }
        }
        var luminous: Float?
        if var temperature = request.fireball {
            let dims = LuminousBlock.dimensions(grid)
            let bytes = 2 * MemoryLayout<SIMD4<UInt32>>.stride * dims.x * dims.y * dims.z
            if (blocksBuffer?.length ?? 0) < bytes {
                blocksBuffer = device.makeBuffer(length: bytes, options: .storageModeShared)
            }
            if blockCountBuffer == nil {
                blockCountBuffer = device.makeBuffer(
                    length: MemoryLayout<UInt32>.stride, options: .storageModeShared)
            }
            if let blocksBuffer, let blockCountBuffer {
                // No batch is in flight while this one is encoded, so nothing else reads or
                // writes the count.
                blockCountBuffer.contents().storeBytes(of: 0, as: UInt32.self)
                encoder.setComputePipelineState(fireballPipeline)
                encoder.setBuffer(control, offset: 0, index: 0)
                encoder.setBuffer(state, offset: 0, index: 1)
                encoder.setBuffer(mask, offset: 0, index: 2)
                encoder.setBuffer(blocksBuffer, offset: 0, index: 3)
                encoder.setBuffer(blockCountBuffer, offset: 0, index: 4)
                encoder.setBytes(&temperature, length: MemoryLayout<Float>.stride, index: 5)
                encoder.setBytes(&uniforms, length: MemoryLayout<SolverUniforms>.stride, index: 6)
                encoder.dispatchThreads(
                    MTLSize(width: dims.x, height: dims.y, depth: dims.z),
                    threadsPerThreadgroup: Self.threadgroup(fireballPipeline, depth: true))
                luminous = temperature
            }
        }
        var cells = false
        if var temperature = luminous, request.fireballCells {
            let bytes = MemoryLayout<SIMD2<UInt32>>.stride * grid.cellCount
            if (cellsBuffer?.length ?? 0) < bytes {
                cellsBuffer = device.makeBuffer(length: bytes, options: .storageModeShared)
            }
            if let cellsBuffer {
                var flag = UInt32(hasSpecies ? 1 : 0)
                encoder.setComputePipelineState(cellsPipeline)
                encoder.setBuffer(control, offset: 0, index: 0)
                encoder.setBuffer(state, offset: 0, index: 1)
                encoder.setBuffer(mask, offset: 0, index: 2)
                encoder.setBuffer(species, offset: 0, index: 3)
                encoder.setBuffer(cellsBuffer, offset: 0, index: 4)
                encoder.setBytes(&temperature, length: MemoryLayout<Float>.stride, index: 5)
                encoder.setBytes(&flag, length: MemoryLayout<UInt32>.stride, index: 6)
                encoder.setBytes(&uniforms, length: MemoryLayout<SolverUniforms>.stride, index: 7)
                encoder.dispatchThreads(
                    MTLSize(width: grid.nx, height: grid.ny, depth: grid.nz),
                    threadsPerThreadgroup: Self.threadgroup(cellsPipeline, depth: true))
                cells = true
            }
        }
        encoded = air == nil && luminous == nil ? nil : (air, luminous, cells)
    }

    /// The batch in flight has finished, at `time` after `steps` steps, its clock at `clock`
    /// ticks; what it cut out is kept if it reached its time limit, and a recorder's field if the
    /// clock reached its tick, as the kernel judged it.
    func complete(reachedLimit: Bool, time: Double, steps: Int, clock: UInt64) {
        if reachedLimit, let encoded {
            ready = (time, steps, encoded.air, encoded.luminous, encoded.cells)
        } else {
            ready = nil
        }
        readyView = reachedLimit ? encodedView.map { (time, steps, $0) } : nil
        readyCapture = encodedCapture.flatMap { clock >= $0.fromTicks ? (time, steps, $0.stride) : nil }
        readyBodies = readyView != nil || readyCapture != nil ? (time, steps) : nil
        encoded = nil
        encodedView = nil
        encodedCapture = nil
    }

    /// The state has been changed by other means: nothing cut out is current.
    func invalidate() {
        readyBodies = nil
        ready = nil
        readyView = nil
        readyCapture = nil
    }

    func bodyFields(time: Double, steps: Int) -> [(solids: BodyViewFields?, shells: BodyViewFields?)]? {
        guard let readyBodies, readyBodies.time == time, readyBodies.steps == steps else { return nil }
        return bodyExtractor.fields()
    }

    /// The samples cut out for `layout` at `time` and `steps`, if they are ready.
    func airValues(_ layout: AirSlice.Layout, time: Double, steps: Int) -> [Float16]? {
        guard let ready, ready.time == time, ready.steps == steps, ready.air == layout, let airBuffer
        else { return nil }
        let count = 5 * layout.sampleCount
        let pointer = airBuffer.contents().bindMemory(to: Float16.self, capacity: count)
        return Array(UnsafeBufferPointer(start: pointer, count: count))
    }

    /// The blocks of luminous gas cut out at `luminous` kelvin, at `time` and `steps`, if they are
    /// ready, in order of their index (see `LuminousBlock`).
    func fireballBlocks(luminous: Float, time: Double, steps: Int) -> [LuminousBlock]? {
        guard let ready, ready.time == time, ready.steps == steps, ready.luminous == luminous,
            let blocksBuffer, let blockCountBuffer
        else { return nil }
        let count = Int(blockCountBuffer.contents().load(as: UInt32.self))
        let words = blocksBuffer.contents().bindMemory(to: SIMD4<UInt32>.self, capacity: 2 * count)
        var blocks = (0..<count).map { n in
            let (a, b) = (words[2 * n], words[2 * n + 1])
            return LuminousBlock(
                index: Int(a.x), cells: Float(bitPattern: a.y), fourth: Float(bitPattern: a.z),
                hottest: Float(bitPattern: a.w),
                position: SIMD3(Float(bitPattern: b.x), Float(bitPattern: b.y), Float(bitPattern: b.z)),
                air: Float(bitPattern: b.w))
        }
        blocks.sort { $0.index < $1.index }
        return blocks
    }

    /// Each cell's luminous temperature and unburnt products cut out at `luminous` kelvin, at
    /// `time` and `steps`, if they are ready, packed as `extractLuminousCells` writes them, one a
    /// cell of the grid.
    func luminousCells(luminous: Float, time: Double, steps: Int, count: Int)
        -> UnsafeBufferPointer<SIMD2<UInt32>>?
    {
        guard let ready, ready.time == time, ready.steps == steps, ready.luminous == luminous, ready.cells,
            let cellsBuffer
        else { return nil }
        return UnsafeBufferPointer(
            start: cellsBuffer.contents().bindMemory(to: SIMD2<UInt32>.self, capacity: count), count: count)
    }

    private static func threadgroup(_ pipeline: MTLComputePipelineState, depth: Bool) -> MTLSize {
        let width = pipeline.threadExecutionWidth
        let height = max(pipeline.maxTotalThreadsPerThreadgroup / width / (depth ? 4 : 1), 1)
        return MTLSize(width: width, height: height, depth: depth ? 4 : 1)
    }
}
