import Foundation
import simd

// The figures of the estimates beside a run.
// Split from ErrorBands.swift (emmettl/bombcad-work#50); see that file for the types.

extension ValidationTables {
    /// Estimates beside a run, against BombCAD's own runs. Part of `figures`, in its order.
    static let districtFigures: [Figure] = [
        // Estimates beside a run, against BombCAD's own runs: the standing lines of
        // `FacadeLoadSurrogate`, `HybridFarField` and `ChargeInference` are worded from these.
        Figure(
            id: "structureChancesSkill", low: 0.59, high: 0.74,
            document: "validation.md#the-walls-and-roofs-chances-against-beiruts-runs",
            quote: "Brier skill 0.59 for concrete walls moderate or worse, 0.74 for roofs"),
        Figure(
            id: "structureChancesUnderCall", low: 0.1, high: 0.1,
            document: "validation.md#the-walls-and-roofs-chances-against-beiruts-runs",
            quote: "each tenth of chance within 0.1"),
        Figure(
            id: "structureChancesRoofLow", low: 0.10, high: 0.18,
            document: "validation.md#the-walls-and-roofs-chances-against-beiruts-runs",
            quote: "low by 0.10–0.18"),
        // The walls' chances with the learned field model's peaks, at its own calibration, against
        // the surrogate's at its own, on the 2 m references (emmettl/bombcad-work#19).
        Figure(
            id: "learnedWallsRefined", low: 0.59, high: 0.66,
            document: "validation.md#the-walls-and-roofs-chances-against-beiruts-runs",
            quote: "0.66 with the learned field model's peaks, against 0.59"),
        Figure(
            id: "surrogateCloseInShielded", low: 1.4, high: 1.7,
            document: "surrogate-first-look.md#close-in-among-buildings-21-october-2026",
            quote: "the branch reads 1.4–1.7 times the runs' among buildings"),
        // The learned field model's peak at ground-floor façades, in the quick estimate
        // (`LearnedField.standing`): the surrogate's figure low, the model's high.
        Figure(
            id: "learnedPeakGlass", low: 0.916, high: 0.942,
            document: "learned-models.md#in-the-apps-quick-estimate-21-october-2026",
            quote:
                "glass by side exactly right on 0.916 of sides with the surrogate's peak and 0.942 with the model's"
        ),
        Figure(
            id: "learnedPeakGlassSkill", low: 0.62, high: 0.72,
            document: "learned-models.md#in-the-apps-quick-estimate-21-october-2026",
            quote: "Heidke skill 0.62 and 0.72"),
        Figure(
            id: "learnedPeakWalls", low: 0.69, high: 0.78,
            document: "learned-models.md#in-the-apps-quick-estimate-21-october-2026",
            quote: "concrete walls moderate or worse, Brier skill 0.69 and 0.78"),
        Figure(
            id: "learnedPeakWallsApp", low: 0.60, high: 0.68,
            document: "learned-models.md#in-the-apps-quick-estimate-21-october-2026",
            quote: "at the app's own load factor of 1.0, 0.60 and 0.68"),
        Figure(
            id: "dragPreviewGlass", low: 0.88, high: 0.93,
            document: "surrogate-first-look.md#dragging-the-charge-20-october-2026",
            quote: "within 0.1 of the full estimate's on 88–93% of sides"),
        Figure(
            id: "dragPreviewWalls", low: 0.989, high: 1.0,
            document: "surrogate-first-look.md#dragging-the-charge-20-october-2026",
            quote: "within 0.1 on 98.9–100% of buildings"),
        Figure(
            id: "dragPreviewDamage", low: 0.997, high: 0.997,
            document: "surrogate-first-look.md#dragging-the-charge-20-october-2026",
            quote: "the same for 99.7% of buildings"),
        Figure(
            id: "glassChancesBrier", low: 0.020, high: 0.108,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "Brier score 0.020, against 0.108"),
        Figure(
            id: "glassChancesBins", low: 0.05, high: 0.05,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "within 0.05 of the share of runs"),
        Figure(
            id: "glassChancesThrown", low: 0.72, high: 0.72,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "condition 3b: skill 0.72"),
        Figure(
            id: "glassChancesTest", low: 0.1, high: 0.1,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "within 0.1 of the share seen"),
        Figure(
            id: "glassChancesSurvey", low: 0.27, high: 0.91,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "blown out 0.91 at 0.75–1 km where GEER saw 0.27"),
        Figure(
            id: "openingsSurvey", low: 0.27, high: 0.31,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "openings blown out 0.31 at 0.75–1 km where GEER saw 0.27"),
        Figure(
            id: "openingsSkill", low: 0.15, high: 0.15,
            document: "validation.md#the-glass-chances-against-beiruts-runs-and-survey",
            quote: "skill 0.15 (Brier 0.144"),
        Figure(
            id: "surrogateGlassSides", low: 0.75, high: 0.84,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "agrees with the run's for 75–84%"),
        Figure(
            id: "surrogateConcrete", low: 0.28, high: 0.49,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "28–49% of the concrete"),
        Figure(
            id: "surrogateStone", low: 0.36, high: 0.45,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "36–45% of the stone"),
        Figure(
            id: "surrogateRoof", low: 0.29, high: 0.64,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "29–64% of the roofs"),
        Figure(
            id: "surrogateNearPeak", low: 0.85, high: 1.00,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "peaks 0.85–1.00"),
        Figure(
            id: "surrogateFarLoads", low: 1.09, high: 1.63,
            document: "validation.md#the-quick-estimate-against-beiruts-runs",
            quote: "1.09–1.63 times the run's on the median"),
        Figure(
            id: "hybridFarPeak", low: 0.76, high: 1.04,
            document: "validation.md#the-hybrid-far-field-against-beiruts-runs",
            quote: "façade peaks 0.76–1.04 of the full run's to 2.5 km"),
        Figure(
            id: "hybridFarImpulse", low: 1.04, high: 1.5,
            document: "validation.md#the-hybrid-far-field-against-beiruts-runs",
            quote: "impulses 1.04–1.5 times"),
        Figure(
            id: "inferredBeirut", low: 0.50, high: 0.54,
            document: "validation.md#the-charge-from-its-arrivals",
            quote: "0.50–0.54 kt"),
        Figure(
            id: "inferredWithRatios", low: 0.97, high: 1.01,
            document: "validation.md#the-charge-from-its-arrivals",
            quote: "0.97–1.01 of it on 2 m cells"),
        Figure(
            id: "inferredByCurvesAlone", low: 1.27, high: 1.95,
            document: "validation.md#the-charge-from-its-arrivals",
            quote: "1.27–1.95 times the yield"),
    ]
}
