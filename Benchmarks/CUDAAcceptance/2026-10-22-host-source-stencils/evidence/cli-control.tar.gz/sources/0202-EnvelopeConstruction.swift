import Foundation

/// What an envelope building is built of, for the one-way damage of its components
/// (`EnvelopePanel`). The air never sees it: an envelope's geometry stays rigid and whole.
///
/// Read from an IFC import's materials or a map building's `building:material` tag where they say;
/// otherwise assumed (and said so), or chosen by the user in the editor.
public struct EnvelopeConstruction: Codable, Hashable, Sendable {
    /// The walls' and roof's construction, as the damage model knows them.
    public enum Kind: String, Codable, Sendable, CaseIterable {
        /// Reinforced concrete with one central mat, as a two-way panel (`EnvelopePanel.reinforcedConcrete`).
        case reinforcedConcrete
        /// Brick, block or stone without reinforcement and without arching
        /// (`EnvelopePanel.unreinforcedMasonry`).
        case unreinforcedMasonry
        /// Concrete blockwork with bars in its cells, grouted or not: judged as reinforced
        /// concrete of the masonry's strength (walls only).
        case reinforcedBlockwork
        /// Profiled steel sheeting on rails or purlins, spanning one way between them
        /// (`EnvelopePanel.profiledSheetOneWay`): a portal-frame shed's cladding and roof.
        case profiledSteelSheeting
        /// Cross-laminated timber spanning one way on its outer lamellae's grain
        /// (`EnvelopePanel.crossLaminatedOneWay`): CLT buildings' walls and roofs.
        case crossLaminatedTimber

        public var label: String {
            switch self {
            case .reinforcedConcrete: "Reinforced concrete"
            case .unreinforcedMasonry: "Unreinforced masonry"
            case .reinforcedBlockwork: "Reinforced blockwork"
            case .profiledSteelSheeting: "Profiled steel sheeting"
            case .crossLaminatedTimber: "Cross-laminated timber"
            }
        }
    }

    /// Where it came from.
    public enum Source: String, Codable, Sendable {
        /// The IFC import's material layers.
        case ifc
        /// The map building's `building:material` tag.
        case map
        /// Chosen in the editor.
        case user
        /// Nothing said: the default, flagged as assumed.
        case assumed
    }

    public var objectID: UUID
    public var walls: Kind
    public var wallThicknessM: Float
    /// The roof (and floor slabs), reinforced concrete unless said otherwise.
    public var roof: Kind
    public var roofThicknessM: Float
    /// Reinforcement of each concrete member, a central mat, as a share of the gross section
    /// each way.
    public var reinforcementRatio: Float
    /// Every pane's glass, this thick: annealed, or the laminate's whole thickness.
    public var glassThicknessM: Float
    /// Laminated glass in every pane, which holds together once cracked (`LaminatedGlass`); nil for
    /// monolithic annealed glass (left out of the JSON, which older records lack).
    public var laminate: LaminatedGlass?
    /// Security film on every pane's (monolithic) glass, which holds its fragments once cracked
    /// (`SecurityFilm`); nil for none, and ignored on laminated glass (left out of the JSON).
    public var film: SecurityFilm?
    /// A spray-on polyurea liner on the inside face of unreinforced masonry walls, lapped onto their
    /// supports (`WallLiner`); nil for none (left out of the JSON). Freestanding walls are judged
    /// without it.
    public var wallLiner: WallLiner?
    /// Unreinforced masonry walls arch between their returns (`EnvelopePanel.arching`): a wall held
    /// at both its upright edges resists by arching across its width once cracked, where that is
    /// the stronger (not a map building's façade strips, `EnvelopeComponentLoad.archingSpan`). Nil
    /// or false for no arching, the default (left out of the JSON).
    public var masonryArching: Bool?
    /// The monolithic glass is thermally toughened, breaking at four times annealed glass's
    /// strength (`EnvelopePanel.filmedGlass`); nil or false for annealed (left out of the JSON).
    public var glassToughened: Bool?
    /// How every pane's glass stands against E1300's strength (`GlassCondition`): nil as designed,
    /// weathered (left out of the JSON); set with `setGlassCondition`, which gives its windows'
    /// mixes the same.
    public var glassCondition: GlassCondition?
    /// The pane a façade strip is taken to hold (a block's storey strip, as map buildings have),
    /// width and height, m: nil for `assumedFacadePane`, zero for none.
    public var facadePaneM: SIMD2<Float>?
    /// The windows of its façade strips as a mix of panes, each breaking with E1300's
    /// probability (`GlazingMix`): what the building's glass fractions come from. Nil for none
    /// (map buildings are given one by their tag and height).
    public var glazing: GlazingMix?
    /// What the building is used for, for the people in it (`BuildingUse`, `OccupantInjury`): from
    /// a map building's tags, or chosen; nil where nothing says (left out of the JSON).
    public var use: BuildingUse?
    /// A side's own windows where they differ from the building's (`glazing`), by the side
    /// (`sideKey`): what a protective plan changes side by side. Nil for none (left out of the JSON).
    public var sideGlazing: [String: GlazingMix]?

    /// "x-", "x+", "y-", "y+": the side facing `outward` along `axis`.
    public static func sideKey(axis: Int, outward: Int) -> String {
        (axis == 0 ? "x" : axis == 1 ? "y" : "z") + (outward > 0 ? "+" : "-")
    }

    /// The windows of the side facing `outward` along `axis`: its own, or the building's.
    public func glazing(axis: Int, outward: Int) -> GlazingMix? {
        sideGlazing?[Self.sideKey(axis: axis, outward: outward)] ?? glazing
    }

    /// The construction a side's façade pane is judged in (`EnvelopeDamageAssessment.facadePane`):
    /// the building's, with its glass as the side's own windows' where they say (none, filled in).
    public func facade(axis: Int, outward: Int) -> EnvelopeConstruction {
        guard let mix = sideGlazing?[Self.sideKey(axis: axis, outward: outward)] else { return self }
        var side = self
        if mix.glazedFraction <= 0 { side.facadePaneM = .zero }
        side.glassCondition = mix.condition ?? glassCondition
        if let glass = mix.glass {
            side.laminate = glass.laminate
            side.film = glass.laminate == nil ? glass.film : nil
            side.glassToughened = glass.toughened
            if let laminate = glass.laminate { side.glassThicknessM = Float(laminate.thickness) }
        }
        return side
    }

    /// A window in each storey of a façade, where nothing says otherwise.
    public static let assumedFacadePane = SIMD2<Float>(1.2, 1.5)
    public var source: Source
    /// The tag, the materials read, or what was assumed, in words.
    public var detail: String
    /// The walls' bars (concrete or blockwork): a mat in each face, `barCoverM` from it to the
    /// bars' centres, the ratio shared between the two; nil or false for one central mat.
    public var barsInBothFaces: Bool?
    public var barCoverM: Float?
    /// The walls' concrete strength, MPa; nil for the default 30.
    public var concreteStrengthMPa: Float?
    /// The walls' bars' yield strength, MPa; nil for the default 500.
    public var barYieldMPa: Float?
    /// Reinforced blockwork: fully grouted (nil or true) or hollow, its cells holding only the
    /// bars; and its compressive strength on the gross area, MPa, nil for 10 grouted or 3 hollow
    /// (the model's concrete block).
    public var blockworkGrouted: Bool?
    public var masonryStrengthMPa: Float?
    /// A cap or canopy carried on a freestanding wall's top, kg per metre of wall: mass that moves
    /// with the top without holding it, as a slab on other walls would; nil for none.
    public var capMassKgPerM: Float?
    /// Profiled steel sheeting: the walls' and the roof's profiles, by name from
    /// `SheetProfile.library` (nil for the 32 mm wall and 45 mm roof profiles); the rails' and
    /// purlins' spacing it spans, m (nil for 1.8); whether it is continuous over them (nil or
    /// true) or a single span; and its screws per metre at each rail or purlin (nil for 3) into
    /// steel this thick, m (nil for 2 mm).
    public var wallSheet: String?
    public var roofSheet: String?
    public var sheetSpanM: Float?
    public var sheetContinuous: Bool?
    public var screwsPerM: Float?
    public var railThicknessM: Float?

    public init(
        objectID: UUID, walls: Kind = .reinforcedConcrete, wallThicknessM: Float? = nil,
        roof: Kind = .reinforcedConcrete, roofThicknessM: Float = 0.2, reinforcementRatio: Float = 0.003,
        glassThicknessM: Float = 0.006, source: Source, detail: String, barsInBothFaces: Bool? = nil,
        barCoverM: Float? = nil, concreteStrengthMPa: Float? = nil, barYieldMPa: Float? = nil,
        blockworkGrouted: Bool? = nil, masonryStrengthMPa: Float? = nil, capMassKgPerM: Float? = nil,
        laminate: LaminatedGlass? = nil
    ) {
        self.laminate = laminate
        self.barsInBothFaces = barsInBothFaces
        self.barCoverM = barCoverM
        self.concreteStrengthMPa = concreteStrengthMPa
        self.barYieldMPa = barYieldMPa
        self.blockworkGrouted = blockworkGrouted
        self.masonryStrengthMPa = masonryStrengthMPa
        self.capMassKgPerM = capMassKgPerM
        self.objectID = objectID
        self.walls = walls
        self.wallThicknessM = wallThicknessM ?? Self.defaultThickness(walls)
        self.roof = roof
        self.roofThicknessM = roofThicknessM
        self.reinforcementRatio = reinforcementRatio
        self.glassThicknessM = laminate.map { Float($0.thickness) } ?? glassThicknessM
        self.source = source
        self.detail = detail
    }

    /// A pane a × b (m, either way round) of this construction's glass, as the one-way model
    /// judges it: annealed or toughened on Moore's large-deflection plate, filmed
    /// (`EnvelopePanel.filmedGlass`), or laminated (`EnvelopePanel.laminatedGlass`).
    public func pane(a: Double, b: Double) -> SDOFSystem {
        // New or tested glass: E1300's strength times its condition's factor (as designed, nil: E1300's).
        let condition = glassCondition?.strengthFactor ?? 1
        let annealed = condition == 1 ? nil : condition * GlassStrength.sixtySecond(area: a * b)
        if let laminate {
            return EnvelopePanel.laminatedGlass(laminate, a: a, b: b, sixtySecondStrength: annealed)
        }
        let toughened = glassToughened == true
        if let film {
            return EnvelopePanel.filmedGlass(
                film, thickness: Double(glassThicknessM), toughened: toughened, a: a, b: b,
                sixtySecondStrength: annealed)
        }
        return EnvelopePanel.largeDeflectionGlass(
            thickness: Double(glassThicknessM), material: toughened ? .toughenedGlass : .annealedGlass, a: a,
            b: b,
            sixtySecondStrength: toughened
                ? 4 * condition * GlassStrength.sixtySecond(area: a * b) : annealed)
    }

    /// Every pane's glass, and its windows' mixes (the building's and each side's), in `condition`.
    public mutating func setGlassCondition(_ condition: GlassCondition) {
        glassCondition = condition == .asDesigned ? nil : condition
        glazing = glazing?.with(condition: condition)
        sideGlazing = sideGlazing?.mapValues { $0.with(condition: condition) }
    }

    /// Plain annealed panes as designed, which the damage path builds once for each size.
    public var hasPlainGlass: Bool {
        laminate == nil && film == nil && glassToughened != true
            && (glassCondition ?? .asDesigned) == .asDesigned
    }

    /// The panes' glass holds together once cracked, laminated or filmed: held in the frame, or
    /// gone from it whole.
    public var holdsFragments: Bool { laminate != nil || film != nil }

    /// The glass alone, m: the laminate's plies, or the monolithic pane.
    public var glassAloneM: Double { laminate.map { $0.plies.reduce(0, +) } ?? Double(glassThicknessM) }

    /// What a pane is in the damage record.
    public var paneMaterial: EnvelopeComponentDamage.Material {
        if laminate != nil { return .laminatedGlass }
        if film != nil { return .filmedGlass }
        return glassToughened == true ? .toughenedGlass : .annealedGlass
    }

    /// The thickness a wall of `kind` takes unless said: 215 mm of masonry, a sheet's profile
    /// depth, otherwise 200 mm.
    public static func defaultThickness(_ kind: Kind) -> Float {
        switch kind {
        case .unreinforcedMasonry: 0.215
        case .profiledSteelSheeting: SheetProfile.swedsteelSTW35.depth
        case .crossLaminatedTimber: 0.105
        case .reinforcedConcrete, .reinforcedBlockwork: 0.2
        }
    }

    /// The sheeting's profile on the roof or the walls.
    public func sheet(roof: Bool) -> SheetProfile {
        let name = roof ? roofSheet : wallSheet
        return SheetProfile.library.first { $0.name == name }
            ?? (roof ? SheetProfile.swedsteelSTR45 : SheetProfile.swedsteelSTW35)
    }

    /// The walls' material for the concrete-like systems (reinforced concrete or blockwork): the
    /// app's reinforced concrete at the strengths given, or blockwork as a concrete of the
    /// masonry's strength, its modulus 1,000 times it (Eurocode 6, as the concrete block preset),
    /// 2,100 kg/m³ grouted or 1,400 hollow.
    public var wallMaterial: StructureMaterial {
        var steel = SteelProperties.grade500
        if let yield = barYieldMPa {
            steel.ultimateStress *= yield * 1e6 / steel.yieldStress
            steel.yieldStress = yield * 1e6
        }
        if walls == .reinforcedBlockwork {
            let grouted = blockworkGrouted ?? true
            let strength = (masonryStrengthMPa ?? (grouted ? 10 : 3)) * 1e6
            var material = StructureMaterial.concrete(
                name: "Reinforced blockwork", compressiveStrength: strength, density: grouted ? 2100 : 1400,
                steel: steel)
            material.youngsModulus = 1000 * strength
            return material
        }
        var material = StructureMaterial.reinforcedConcrete
        if let strength = concreteStrengthMPa {
            material = .concrete(name: material.name, compressiveStrength: strength * 1e6, steel: steel)
            material.rateDependent = true
        } else {
            material.steel = steel
        }
        return material
    }

    /// The walls' tension bars for a section `thickness` thick: their depth from the compression
    /// face and area per metre (one face's share when in both faces).
    public func wallBars(thickness: Double) -> (depth: Double, steelArea: Double) {
        let steel = Double(reinforcementRatio) * thickness
        if barsInBothFaces == true {
            return (thickness - Double(barCoverM ?? 0.03), steel / 2)
        }
        return (thickness / 2, steel)
    }

    /// The default when nothing says otherwise: 0.2 m reinforced concrete at 0.3% each way under a
    /// 0.2 m concrete roof, 6 mm annealed glass (stage 3a's references).
    public static func assumed(objectID: UUID) -> Self {
        Self(
            objectID: objectID, source: .assumed,
            detail: "assumed: 0.2 m reinforced concrete, 0.3% each way, 6 mm annealed glass")
    }

    /// From a map building's `building:material` value, when it names something the model knows.
    public static func fromMap(objectID: UUID, material: String?) -> Self? {
        guard let material else { return nil }
        let value = material.lowercased()
        let masonry = [
            "brick", "stone", "masonry", "sandstone", "limestone", "granite", "cement_block", "block",
        ]
        if value == "concrete" || value == "reinforced_concrete" {
            return Self(
                objectID: objectID, walls: .reinforcedConcrete, source: .map,
                detail: "building:material=\(material); 0.2 m, 0.3% each way assumed")
        }
        if masonry.contains(value) {
            return Self(
                objectID: objectID, walls: .unreinforcedMasonry, source: .map,
                detail: "building:material=\(material); 0.215 m assumed")
        }
        return nil
    }

    /// From the material layers of an IFC import's elements: concrete or masonry by the larger
    /// count of elements, with their median structural thickness. Nil when neither is read.
    public static func fromIFC(objectID: UUID, elementLayers: [[IFCStructure.Layer]]) -> Self? {
        var concrete: [Float] = []
        var masonry: [Float] = []
        for layers in elementLayers where !layers.isEmpty {
            let reading = IFCStructure.material(of: layers, default: .reinforcedConcrete)
            guard !reading.assumed else { continue }
            let kinds = layers.map { IFCStructure.classify($0.name) }
            if kinds.contains(.concrete) {
                concrete.append(reading.thickness ?? 0)
            } else if kinds.contains(where: { $0 == .masonry || $0 == .block }) {
                masonry.append(reading.thickness ?? 0)
            }
        }
        guard !concrete.isEmpty || !masonry.isEmpty else { return nil }
        let isConcrete = concrete.count >= masonry.count
        let thicknesses = (isConcrete ? concrete : masonry).filter { $0 > 0.05 && $0 < 1 }.sorted()
        let median = thicknesses.isEmpty ? nil : thicknesses[thicknesses.count / 2]
        return Self(
            objectID: objectID, walls: isConcrete ? .reinforcedConcrete : .unreinforcedMasonry,
            wallThicknessM: median, source: .ifc,
            detail: "IFC: \(concrete.count) concrete and \(masonry.count) masonry elements"
                + (median.map { String(format: ", %.3f m thick", $0) } ?? "")
                + (isConcrete ? ", 0.3% each way assumed" : ""))
    }
}

extension Scenario {
    /// Each envelope's construction: the one recorded for it, or the assumed default.
    public func envelopeConstruction(for objectID: UUID) -> EnvelopeConstruction {
        envelopeConstructions?.last { $0.objectID == objectID } ?? .assumed(objectID: objectID)
    }

    /// Records `construction` for its envelope, replacing any before it.
    public mutating func setEnvelopeConstruction(_ construction: EnvelopeConstruction) {
        var list = (envelopeConstructions ?? []).filter { $0.objectID != construction.objectID }
        list.append(construction)
        let present = Set(envelopeObjects.map(\.id))
        list.removeAll { !present.contains($0.objectID) }
        envelopeConstructions = list.isEmpty ? nil : list
    }
}
