import Foundation
import simd

/// Recorded reference trajectories for visual review without running the app or blast solver.
public enum RigidObjectDemo {
    public struct Frame: Codable, Sendable {
        public let time: Double
        public let corners: [SIMD3<Double>]
        public let centreOfMass: SIMD3<Double>
        public let speed: Double
        public let energy: Double
        /// Car tyre contact points and their loads (N), FL, FR, RL, RR; absent for boxes.
        public var tyres: [SIMD3<Double>]? = nil
        public var tyreLoads: [Double]? = nil
        /// Corners of further bodies in the scene, drawn without readouts; absent for one body.
        public var others: [[SIMD3<Double>]]? = nil

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            time: Double,
            corners: [SIMD3<Double>],
            centreOfMass: SIMD3<Double>,
            speed: Double,
            energy: Double,
            tyres: [SIMD3<Double>]? = nil,
            tyreLoads: [Double]? = nil,
            others: [[SIMD3<Double>]]? = nil
        ) {
            self.time = time
            self.corners = corners
            self.centreOfMass = centreOfMass
            self.speed = speed
            self.energy = energy
            self.tyres = tyres
            self.tyreLoads = tyreLoads
            self.others = others
        }
    }

    public struct Recording: Codable, Sendable {
        public let name: String
        public let description: String
        public let frames: [Frame]
        /// "front" looks along the x axis; absent means the side view along y.
        public var view: String? = nil

        public init(name: String, description: String, frames: [Frame], view: String? = nil) {
            self.name = name
            self.description = description
            self.frames = frames
            self.view = view
        }
    }

    /// Two seconds at 1 ms mechanics steps, sampled every 20 ms. Each case is independent.
    public static func recordings() throws -> [Recording] {
        let cases: [(String, String, Double)] = [
            ("Resting", "A 2 kg box supported by its weight.", 0),
            ("Friction holding", "Horizontal force 11.58 N, below the 11.77 N static-friction limit.", 0),
            ("Sliding", "Initial speed 5 m/s; sliding friction 0.5 slows the box to rest.", 0),
            ("Lift-off", "Upward force 40 N for 0.15 s, then gravity alone.", 0),
            ("Rocking", "Tall box tilted 0.2 rad, below the 0.464 rad balance angle.", 0.2),
            ("Tipping", "Tall box tilted 0.6 rad, beyond the 0.464 rad balance angle.", 0.6),
        ]
        return try cases.enumerated().map { index, specification in
            let (name, description, angle) = specification
            let tall = index >= 4
            let size = tall ? SIMD3<Double>(1, 1, 2) : SIMD3<Double>(2, 2, 0.5)
            let height = tall ? cos(angle) + 0.5 * sin(angle) : 0.25
            let definition = try RigidObjectDefinition(
                name: name, shape: .box(size: size), position: SIMD3(0, 0, height), mass: 2,
                orientation: simd_quatd(angle: angle, axis: SIMD3(0, 1, 0)).vector)
            var body = try definition.makeBody()
            if index == 2 { body.applyImpulse(SIMD3(10, 0, 0)) }
            var frames: [Frame] = []
            for step in 0...2000 {
                if step % 20 == 0 {
                    frames.append(
                        Frame(
                            time: Double(step) * 0.001, corners: body.corners,
                            centreOfMass: body.position, speed: simd_length(body.linearVelocity),
                            energy: body.kineticEnergy + body.mass * 9.81 * body.position.z))
                }
                guard step < 2000 else { break }
                let force: SIMD3<Double> =
                    index == 1
                    ? SIMD3(0.59 * 2 * 9.81, 0, 0)
                    : index == 3 && step < 150 ? SIMD3(0, 0, 40) : .zero
                body.advanceWithGround(by: 0.001, ground: definition.ground, force: force)
            }
            return Recording(name: name, description: description, frames: frames)
        }
    }
}
