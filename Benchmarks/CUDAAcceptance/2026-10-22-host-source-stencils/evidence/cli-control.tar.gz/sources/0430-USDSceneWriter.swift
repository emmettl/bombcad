import Foundation
import simd

/// Writes a run as a USD scene in its text form (`.usda`), for rendering elsewhere (Blender's
/// Cycles, for one): the ground, the rigid blocks, the charges and gauges as they stand, and the
/// body's surface (`StructureSurface`) frame by frame. Units are metres, Z is up, and time codes
/// count frames. Each face of the body carries its element's damage and material as the
/// `damage` and `material` primvars; the material names are in `bombcad:materials`.
///
/// USD's text form keeps all the frames of one attribute together, so the frames are written to
/// a temporary file per attribute as they come and joined by `finish()`.
public final class USDSceneWriter {
    /// A view to render from: a USD camera with a 16:9 frame.
    public struct Camera: Sendable {
        public var eye: SIMD3<Float>
        public var target: SIMD3<Float>
        /// Radians.
        public var verticalFieldOfView: Float

        public init(eye: SIMD3<Float>, target: SIMD3<Float>, verticalFieldOfView: Float) {
            self.eye = eye
            self.target = target
            self.verticalFieldOfView = verticalFieldOfView
        }
    }

    public let url: URL
    private let camera: Camera?
    private let volumeFields: [String]
    private var volumes: [(frame: Int, path: String)] = []
    private var pointSets:
        [(
            name: String, frames: [[SIMD3<Float>]], widths: [Float], colour: SIMD3<Float>,
            values: [(name: String, values: [Float])]
        )] = []
    private var cloud: (samples: [CloudSample], secondsPerFrame: Double)?
    private var craters: [CraterEstimate] = []
    public let frameInterval: Double
    /// The standing of the run's results (see `SceneStanding`), written into the layer's
    /// `customLayerData` when the scene is finished.
    public var standing: SceneStanding?
    private let scenario: Scenario
    private let playbackRate: Double
    private let parts: URL
    private var streams: [String: FileHandle] = [:]
    private var frames = 0
    private var lastQuads: [Int32]?
    private var lastMaterial: [Int32]?
    private var lastObject: [Int32]?
    private var objectIDs: [UUID] = []
    private var objectNames: [String] = []
    private var lastRubble: [Bool]?
    private var lastDamage: [Float]?
    private var materials: [StructureSurface.Material] = []
    private var hasBody = false
    private var finished = false

    /// Frames appended so far.
    public var frameCount: Int { frames }

    /// - Parameters:
    ///   - frameInterval: simulated seconds between frames.
    ///   - playbackRate: frames per second when the scene is played back.
    public init(
        url: URL, scenario: Scenario, frameInterval: Double, playbackRate: Double = 24, camera: Camera? = nil,
        volumeFields: [String] = []
    ) throws {
        guard frameInterval > 0, frameInterval.isFinite, playbackRate > 0, playbackRate.isFinite else {
            throw CocoaError(
                .featureUnsupported, userInfo: [NSLocalizedDescriptionKey: "Invalid frame timing."])
        }
        self.url = url
        self.scenario = scenario
        self.frameInterval = frameInterval
        self.playbackRate = playbackRate
        self.camera = camera
        self.volumeFields = volumeFields
        parts = url.deletingLastPathComponent().appending(
            path: ".\(url.lastPathComponent).parts-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: parts, withIntermediateDirectories: false)
        for name in ["points", "extent", "counts", "indices", "damage", "material", "rubble", "object"] {
            let file = parts.appending(path: name)
            FileManager.default.createFile(atPath: file.path, contents: nil)
            streams[name] = try FileHandle(forWritingTo: file)
        }
    }

    deinit {
        if !finished { discard() }
    }

    /// Removes the partial output.
    public func discard() {
        for stream in streams.values { try? stream.close() }
        streams = [:]
        try? FileManager.default.removeItem(at: parts)
        finished = true
    }

    /// Adds the next frame, `frameInterval` after the last; `surface` is nil without a body, and
    /// `volume` the asset path of the frame's OpenVDB file, holding the grids named in
    /// `volumeFields`, if it has one.
    public func append(_ surface: StructureSurface?, volume: String? = nil) throws {
        defer { frames += 1 }
        if let volume { volumes.append((frames, volume)) }
        guard let surface else { return }
        hasBody = true
        materials = surface.materials
        objectIDs = surface.objectIDs
        objectNames = surface.objectNames
        let frame = "            \(frames): "
        var text = Text()

        text.append(frame + "[")
        for (n, point) in surface.points.enumerated() {
            if n > 0 { text.append(", ") }
            text.append(point)
        }
        text.append("],\n")
        try write(&text, to: "points")

        let low = surface.points.reduce(SIMD3<Float>(repeating: .infinity)) { simd_min($0, $1) }
        let high = surface.points.reduce(SIMD3<Float>(repeating: -.infinity)) { simd_max($0, $1) }
        text.append(frame + "[")
        if surface.points.isEmpty {
            text.append("(0, 0, 0), (0, 0, 0)")
        } else {
            text.append(low)
            text.append(", ")
            text.append(high)
        }
        text.append("],\n")
        try write(&text, to: "extent")

        // Topology and materials change only as elements fail: write them only then.
        if surface.quads != lastQuads {
            text.append(frame + "[")
            text.appendList(repeatElement(4, count: surface.faceCount).map { $0 })
            text.append("],\n")
            try write(&text, to: "counts")
            text.append(frame + "[")
            text.appendList(surface.quads)
            text.append("],\n")
            try write(&text, to: "indices")
            lastQuads = surface.quads
        }
        if surface.material != lastMaterial {
            text.append(frame + "[")
            text.appendList(surface.material)
            text.append("],\n")
            try write(&text, to: "material")
            lastMaterial = surface.material
        }
        if surface.objectIDs.count > 1, surface.object != lastObject {
            text.append(frame + "[")
            text.appendList(surface.object)
            text.append("],\n")
            try write(&text, to: "object")
            lastObject = surface.object
        }
        if surface.rubble != lastRubble {
            text.append(frame + "[")
            text.append(surface.rubble.map { $0 ? "true" : "false" }.joined(separator: ", "))
            text.append("],\n")
            try write(&text, to: "rubble")
            lastRubble = surface.rubble
        }
        if surface.damage != lastDamage {
            text.append(frame + "[")
            for (n, value) in surface.damage.enumerated() {
                if n > 0 { text.append(", ") }
                text.append(value, decimals: 3)
            }
            text.append("],\n")
            try write(&text, to: "damage")
            lastDamage = surface.damage
        }
    }

    private func write(_ text: inout Text, to stream: String) throws {
        try streams[stream]!.write(contentsOf: text.bytes)
        text.bytes.removeAll(keepingCapacity: true)
    }

    /// Adds a set of points, such as fragments, with their positions at each frame from the first
    /// and their sizes; written with the rest by `finish()`.
    /// `values` are per-point numbers that do not change, as float primvars.
    public func addPoints(
        _ name: String, frames: [[SIMD3<Float>]], widths: [Float], colour: SIMD3<Float>,
        values: [(name: String, values: [Float])] = []
    ) {
        pointSets.append((name, frames, widths, colour, values))
    }

    /// Adds the ground points with open ground, as `/Scene/GroundShock`: Points just above the
    /// ground (the terrain's surface, where there is one), half their spacing along a line across, carrying what the ground did there as
    /// primvars: `peakOverpressure` (kPa), `impulse` (Pa·s), the surface's `verticalVelocity`
    /// (mm/s) and `verticalDisplacement` (mm), and `arrival` (ms, −1 where the blast never came).
    public func addGroundShock(_ result: GroundShockResult, spec: GroundShockSpec) {
        let open = result.points.filter { !$0.covered }
        guard !open.isEmpty else { return }
        var width: Float = 0.5
        if let line = spec.line, spec.points.isEmpty {
            width = simd_distance(line.from, line.to) / Float(max(line.count - 1, 1)) / 2
        }
        width = min(max(width, 0.1), 2)
        let soil = result.soil
        var values: [(String, [Float])] = [
            ("peakOverpressure", open.map { $0.peakOverpressure / 1000 }),
            ("impulse", open.map(\.impulse)),
            ("verticalVelocity", open.map { $0.surfaceVelocity(in: soil) * 1000 }),
            (
                "verticalDisplacement",
                open.map { ($0.profile?.displacement.first ?? $0.impulse / soil.impedance) * 1000 }
            ),
            ("arrival", open.map { $0.arrival.map { Float($0 * 1000) } ?? -1 }),
        ]
        // The column's: how far down the ground was left, mm.
        if result.model == .column {
            values.append(("settlement", open.map { ($0.profile?.residualDisplacement.first ?? 0) * 1000 }))
        }
        addPoints(
            "GroundShock",
            frames: [
                open.map { point in
                    // Placed on the terrain by the run, or here for results from before.
                    point.elevation == nil
                        ? SIMD3(
                            point.position.x, point.position.y,
                            (scenario.terrain?.height(at: point.position) ?? 0) + 0.05) : point.marker
                }
            ],
            widths: [Float](repeating: width, count: open.count), colour: SIMD3(0.6, 0.35, 0.9),
            values: values)
    }

    /// Adds a hazard distance as a ring of points on the ground round the charge, about a metre
    /// apart: `/Scene/<name>`, carrying its `hazardDistance` (m). Nothing without one.
    public func addHazard(_ hazard: GroundHazard, name: String) {
        guard let distance = hazard.hazardDistance else { return }
        let count = min(max(Int((2 * .pi * distance).rounded(.up)), 64), 4096)
        let ring = (0..<count).map { n -> SIMD3<Float> in
            let angle = 2 * Float.pi * Float(n) / Float(count)
            let xy = hazard.centre + distance * SIMD2(cos(angle), sin(angle))
            let point = SIMD3(xy, 0)
            return SIMD3(xy, (scenario.terrain?.height(at: point) ?? 0) + 0.05)
        }
        addPoints(
            name, frames: [ring], widths: [Float](repeating: 0.3, count: count),
            colour: SIMD3(0.86, 0.1, 0.24),
            values: [("hazardDistance", [Float](repeating: distance, count: count))])
    }

    /// Adds the cloud after the run, a sphere rising and drifting with one frame every
    /// `secondsPerFrame` of simulated time from the first sample. Its frames follow the run's on
    /// the timeline, at that slower rate, and it is hidden until then.
    public func addCloud(_ samples: [CloudSample], secondsPerFrame: Double) {
        guard !samples.isEmpty else { return }
        cloud = (samples, secondsPerFrame)
    }

    /// Adds the charges' craters, as `/Scene/Crater`, `Crater_1`, …: patches of ground over each,
    /// flat until the run's last frame and the crater with its lip at it, for the crater forms
    /// after the blast. The ground plane, or the terrain, is left open under each patch, so the
    /// bowl shows.
    public func addCraters(_ craters: [CraterEstimate]) {
        self.craters = craters
    }

    /// Joins the parts into `url`, which must not exist yet.
    public func finish() throws {
        guard !finished else { return }
        defer { discard() }
        do {
            try assemble()
        } catch {
            try? FileManager.default.removeItem(at: url)
            throw error
        }
    }

    private func assemble() throws {
        for stream in streams.values { try stream.close() }
        streams = [:]
        FileManager.default.createFile(atPath: url.path, contents: nil)
        let output = try FileHandle(forWritingTo: url)
        defer { try? output.close() }
        var text = Text()
        func flush() throws {
            try output.write(contentsOf: text.bytes)
            text.bytes.removeAll(keepingCapacity: true)
        }
        func copy(_ name: String) throws {
            let input = try FileHandle(forReadingFrom: parts.appending(path: name))
            defer { try? input.close() }
            while let chunk = try input.read(upToCount: 1 << 22), !chunk.isEmpty {
                try output.write(contentsOf: chunk)
            }
        }
        func timeSamples(_ declaration: String, _ name: String) throws {
            text.append("        \(declaration).timeSamples = {\n")
            try flush()
            try copy(name)
            text.append("        }\n")
        }

        let last = max(frames - 1, 0, cloud.map { frames + $0.samples.count - 1 } ?? 0)
        let cloudTiming =
            cloud.map {
                "\n        double cloudStartTimeCode = \(frames)\n        double simulatedSecondsPerCloudFrame = \($0.secondsPerFrame)"
            } ?? ""
        text.append(
            """
            #usda 1.0
            (
                customLayerData = {
                    string creator = "BombCAD"
                    string scenario = \(quoted(scenario.name))
                    double simulatedSecondsPerFrame = \(frameInterval)\(cloudTiming)\(standingData)\(attributionData)
                }
                defaultPrim = "Scene"
                startTimeCode = 0
                endTimeCode = \(last)
                framesPerSecond = \(playbackRate)
                timeCodesPerSecond = \(playbackRate)
                metersPerUnit = 1
                upAxis = "Z"
            )

            def Xform "Scene"
            {

            """)
        let domain = scenario.domainSize
        let terrain = scenario.terrain.flatMap { $0.isFlat ? nil : $0 }
        let patches = craters.map { craterPatch($0, terrain: terrain) }
        if patches.isEmpty || terrain != nil {
            appendMesh(
                "Ground", boxes: [],
                quad: [
                    SIMD3(0, 0, 0), SIMD3(domain.x, 0, 0), SIMD3(domain.x, domain.y, 0),
                    SIMD3(0, domain.y, 0),
                ],
                colour: SIMD3(0.46, 0.47, 0.49), to: &text)
        } else {
            appendGround(around: patches, domain: domain, to: &text)
        }
        if let terrain { appendTerrain(terrain, holes: patches, to: &text) }
        for (n, crater) in craters.enumerated() {
            appendCrater(
                n == 0 ? "Crater" : "Crater_\(n)", crater, patch: patches[n], terrain: terrain, to: &text)
        }
        let fixed =
            scenario.boxes
            + (scenario.importedModels ?? []).flatMap(\.rigidBoxes)
        if !fixed.isEmpty {
            appendMesh(
                "Blocks", boxes: fixed, quad: [], colour: SIMD3(0.80, 0.79, 0.76), to: &text)
        }
        for (index, object) in scenario.envelopeObjects.enumerated() {
            appendMesh(
                "Envelope_\(index)", boxes: object.envelope!.blocks, quad: [],
                colour: SIMD3(0.80, 0.79, 0.76), owner: object, to: &text)
        }
        for (n, charge) in ([scenario.charge] + (scenario.additionalCharges ?? [])).enumerated() {
            appendSphere(
                n == 0 ? "Charge" : "Charge_\(n)", at: charge.position, radius: 0.45,
                colour: SIMD3(0.95, 0.15, 0.10),
                label: "\(charge.mass) kg TNT", to: &text)
        }
        for (n, gauge) in scenario.gauges.enumerated() {
            appendSphere(
                "Gauge_\(n)", at: gauge.position, radius: 0.35, colour: SIMD3(0.10, 0.80, 0.90),
                label: gauge.name,
                to: &text)
        }
        if let camera { appendCamera(camera, to: &text) }
        if !volumes.isEmpty, !volumeFields.isEmpty { appendVolume(to: &text) }
        for set in pointSets {
            appendPoints(set.name, set.frames, set.widths, set.colour, set.values, to: &text)
        }
        if let cloud { appendCloud(cloud.samples, to: &text) }
        try flush()

        if hasBody {
            text.append(
                """
                    def Mesh "Structure"
                    {
                        uniform token subdivisionScheme = "none"
                        uniform token orientation = "rightHanded"
                        custom uniform string[] bombcad:materials = [\(materials.map { quoted($0.name) }.joined(separator: ", "))]
                        custom uniform bool[] bombcad:transparent = [\(materials.map { $0.isTransparent ? "true" : "false" }.joined(separator: ", "))]
                        float[] primvars:damage (
                            interpolation = "uniform"
                        )
                        int[] primvars:material (
                            interpolation = "uniform"
                        )
                        bool[] primvars:rubble (
                            interpolation = "uniform"
                        )

                """)
            if objectIDs.count > 1 {
                text.append(
                    "        custom uniform string[] bombcad:objectIds = ["
                        + objectIDs.map { quoted($0.uuidString) }.joined(separator: ", ") + "]\n")
                text.append(
                    "        custom uniform string[] bombcad:objectNames = ["
                        + objectNames.map(quoted).joined(separator: ", ") + "]\n")
                text.append("        int[] primvars:object (interpolation = \"uniform\")\n")
                try timeSamples("int[] primvars:object", "object")
            }
            try timeSamples("float3[] extent", "extent")
            try timeSamples("int[] faceVertexCounts", "counts")
            try timeSamples("int[] faceVertexIndices", "indices")
            try timeSamples("float[] primvars:damage", "damage")
            try timeSamples("int[] primvars:material", "material")
            try timeSamples("bool[] primvars:rubble", "rubble")
            try timeSamples("point3f[] points", "points")
            text.append("    }\n")
        }
        text.append("}\n")
        try flush()
    }

    private func appendMesh(
        _ name: String, boxes: [Box], quad: [SIMD3<Float>], colour: SIMD3<Float>,
        owner: SceneObject? = nil, to text: inout Text
    ) {
        var surface = StructureSurface()
        if !quad.isEmpty {
            surface.points = quad
            surface.appendFace([0, 1, 2, 3], damage: 0, material: 0)
        }
        for box in boxes {
            let corners = (0..<8).map { bit -> SIMD3<Float> in
                SIMD3(
                    bit & 1 == 0 ? box.min.x : box.max.x, bit & 2 == 0 ? box.min.y : box.max.y,
                    bit & 4 == 0 ? box.min.z : box.max.z)
            }
            surface.appendBox(corners, faces: StructureSurface.bitCubeFaces, damage: 0, material: 0)
        }
        let low = surface.points.reduce(SIMD3<Float>(repeating: .infinity)) { simd_min($0, $1) }
        let high = surface.points.reduce(SIMD3<Float>(repeating: -.infinity)) { simd_max($0, $1) }
        text.append("    def Mesh \"\(name)\"\n    {\n        uniform token subdivisionScheme = \"none\"\n")
        if let owner {
            text.append("        custom uniform string bombcad:objectId = \(quoted(owner.id.uuidString))\n")
            text.append("        custom uniform string bombcad:objectName = \(quoted(owner.name))\n")
            text.append("        custom uniform string bombcad:representation = \"stationary-envelope\"\n")
        }
        text.append("        float3[] extent = [")
        text.append(low)
        text.append(", ")
        text.append(high)
        text.append("]\n        int[] faceVertexCounts = [")
        text.appendList(repeatElement(Int32(4), count: surface.faceCount).map { $0 })
        text.append("]\n        int[] faceVertexIndices = [")
        text.appendList(surface.quads)
        text.append("]\n        point3f[] points = [")
        for (n, point) in surface.points.enumerated() {
            if n > 0 { text.append(", ") }
            text.append(point)
        }
        text.append("]\n        color3f[] primvars:displayColor = [")
        text.append(colour)
        text.append("]\n    }\n\n")
    }

    /// The terrain as `/Scene/Terrain`: a mesh of its nodes, one quad a cell of them, with the
    /// heights it was given and where they came from.
    /// The square of ground a crater's patch replaces, low and high corners in the plane: its lip
    /// and a tenth more, out to the terrain's nodes where there is terrain, so the patch's edges
    /// meet the terrain's.
    private func craterPatch(_ crater: CraterEstimate, terrain: Terrain?) -> (
        low: SIMD2<Float>, high: SIMD2<Float>
    ) {
        let half = 1.1 * max(crater.lipRadius, crater.apparentRadius)
        let centre = SIMD2(crater.centre.x, crater.centre.y)
        var low = centre - half
        var high = centre + half
        if let terrain {
            low = terrain.origin + ((low - terrain.origin) / terrain.spacing).rounded(.down) * terrain.spacing
            high = terrain.origin + ((high - terrain.origin) / terrain.spacing).rounded(.up) * terrain.spacing
        }
        return (low, high)
    }

    /// The flat ground as rectangles round the craters' patches.
    private func appendGround(
        around patches: [(low: SIMD2<Float>, high: SIMD2<Float>)], domain: SIMD3<Float>, to text: inout Text
    ) {
        func breaks(_ axis: Int, _ size: Float) -> [Float] {
            Array(
                Set(
                    [0, size]
                        + patches.flatMap { [$0.low[axis], $0.high[axis]] }.map { min(max($0, 0), size) })
            )
            .sorted()
        }
        let xs = breaks(0, domain.x)
        let ys = breaks(1, domain.y)
        var quads: [[SIMD3<Float>]] = []
        for j in 0..<(ys.count - 1) {
            for i in 0..<(xs.count - 1) {
                let middle = SIMD2((xs[i] + xs[i + 1]) / 2, (ys[j] + ys[j + 1]) / 2)
                guard
                    !patches.contains(where: { all(middle .> $0.low) && all(middle .< $0.high) }),
                    xs[i + 1] > xs[i], ys[j + 1] > ys[j]
                else { continue }
                quads.append([
                    SIMD3(xs[i], ys[j], 0), SIMD3(xs[i + 1], ys[j], 0), SIMD3(xs[i + 1], ys[j + 1], 0),
                    SIMD3(xs[i], ys[j + 1], 0),
                ])
            }
        }
        text.append("    def Mesh \"Ground\"\n    {\n        uniform token subdivisionScheme = \"none\"\n")
        text.append("        float3[] extent = [")
        text.append(SIMD3<Float>(0, 0, 0))
        text.append(", ")
        text.append(SIMD3(domain.x, domain.y, 0))
        text.append("]\n        int[] faceVertexCounts = [")
        text.appendList([Int32](repeating: 4, count: quads.count))
        text.append("]\n        int[] faceVertexIndices = [")
        text.appendList((0..<Int32(4 * quads.count)).map { $0 })
        text.append("]\n        point3f[] points = [")
        for (n, point) in quads.joined().enumerated() {
            if n > 0 { text.append(", ") }
            text.append(point)
        }
        text.append("]\n        color3f[] primvars:displayColor = [")
        text.append(SIMD3<Float>(0.46, 0.47, 0.49))
        text.append("]\n    }\n\n")
    }

    /// A crater's patch: a grid of the ground over its square, flat (or the terrain) until the
    /// run's last frame, cratered at it.
    private func appendCrater(
        _ name: String, _ crater: CraterEstimate, patch: (low: SIMD2<Float>, high: SIMD2<Float>),
        terrain: Terrain?, to text: inout Text
    ) {
        let n = 48
        let size = patch.high - patch.low
        var before: [SIMD3<Float>] = []
        var after: [SIMD3<Float>] = []
        for j in 0...n {
            for i in 0...n {
                let point = patch.low + size * SIMD2(Float(i), Float(j)) / Float(n)
                let base = terrain?.height(at: SIMD3(point.x, point.y, 0)) ?? 0
                before.append(SIMD3(point.x, point.y, base))
                after.append(SIMD3(point.x, point.y, base + crater.change(at: point)))
            }
        }
        let lowest = (before + after).map(\.z).min() ?? 0
        let highest = (before + after).map(\.z).max() ?? 0
        text.append("    def Mesh \"\(name)\"\n    {\n        uniform token subdivisionScheme = \"none\"\n")
        text.append("        custom uniform string bombcad:label = \(quoted(crater.summary))\n")
        text.append("        float3[] extent = [")
        text.append(SIMD3(patch.low.x, patch.low.y, lowest))
        text.append(", ")
        text.append(SIMD3(patch.high.x, patch.high.y, highest))
        text.append("]\n        int[] faceVertexCounts = [")
        text.appendList([Int32](repeating: 4, count: n * n))
        text.append("]\n        int[] faceVertexIndices = [")
        var indices: [Int32] = []
        for j in 0..<n {
            for i in 0..<n {
                let k = Int32(i + (n + 1) * j)
                indices += [k, k + 1, k + 2 + Int32(n), k + 1 + Int32(n)]
            }
        }
        text.appendList(indices)
        func list(_ points: [SIMD3<Float>]) {
            text.append("[")
            for (k, point) in points.enumerated() {
                if k > 0 { text.append(", ") }
                text.append(point)
            }
            text.append("]")
        }
        let last = max(frames - 1, 0)
        if last > 0 {
            text.append("]\n        point3f[] points.timeSamples = {\n            0: ")
            list(before)
            text.append(",\n            \(last): ")
            list(after)
            text.append(",\n        }\n")
        } else {
            text.append("]\n        point3f[] points = ")
            list(after)
            text.append("\n")
        }
        text.append("        color3f[] primvars:displayColor = [")
        text.append(SIMD3<Float>(0.42, 0.36, 0.30))
        text.append("]\n    }\n\n")
    }

    private func appendTerrain(
        _ terrain: Terrain, holes: [(low: SIMD2<Float>, high: SIMD2<Float>)] = [], to text: inout Text
    ) {
        let (columns, rows) = (terrain.columns, terrain.rows)
        // The quads under a crater's patch are left out.
        func open(_ i: Int, _ j: Int) -> Bool {
            let middle = terrain.origin + (SIMD2(Float(i), Float(j)) + 0.5) * terrain.spacing
            return !holes.contains { all(middle .> $0.low) && all(middle .< $0.high) }
        }
        text.append("    def Mesh \"Terrain\"\n    {\n        uniform token subdivisionScheme = \"none\"\n")
        if let source = terrain.source {
            text.append("        custom uniform string bombcad:terrainSource = \(quoted(source))\n")
        }
        text.append("        float3[] extent = [")
        text.append(SIMD3(terrain.origin.x, terrain.origin.y, terrain.heights.min() ?? 0))
        text.append(", ")
        text.append(SIMD3(terrain.extent.x, terrain.extent.y, terrain.highest))
        var indices: [Int32] = []
        indices.reserveCapacity(4 * (columns - 1) * (rows - 1))
        for j in 0..<(rows - 1) {
            for i in 0..<(columns - 1) where open(i, j) {
                let n = Int32(i + columns * j)
                // Counter-clockwise seen from above, so that the normals face up.
                indices += [n, n + 1, n + 1 + Int32(columns), n + Int32(columns)]
            }
        }
        text.append("]\n        int[] faceVertexCounts = [")
        text.appendList([Int32](repeating: 4, count: indices.count / 4))
        text.append("]\n        int[] faceVertexIndices = [")
        text.appendList(indices)
        text.append("]\n        point3f[] points = [")
        for j in 0..<rows {
            for i in 0..<columns {
                if i + j > 0 { text.append(", ") }
                text.append(
                    SIMD3(
                        terrain.origin.x + Float(i) * terrain.spacing,
                        terrain.origin.y + Float(j) * terrain.spacing,
                        terrain.height(column: i, row: j)))
            }
        }
        text.append("]\n        color3f[] primvars:displayColor = [")
        text.append(SIMD3<Float>(0.50, 0.49, 0.45))
        text.append("]\n    }\n\n")
    }

    private func appendSphere(
        _ name: String, at position: SIMD3<Float>, radius: Float, colour: SIMD3<Float>, label: String,
        to text: inout Text
    ) {
        text.append("    def Sphere \"\(name)\"\n    {\n        double radius = ")
        text.append(radius, decimals: 3)
        text.append("\n        float3[] extent = [")
        text.append(SIMD3(repeating: -radius))
        text.append(", ")
        text.append(SIMD3(repeating: radius))
        text.append("]\n        double3 xformOp:translate = ")
        text.append(position)
        text.append(
            "\n        uniform token[] xformOpOrder = [\"xformOp:translate\"]\n        color3f[] primvars:displayColor = ["
        )
        text.append(colour)
        text.append("]\n        custom uniform string bombcad:label = \(quoted(label))\n    }\n\n")
    }

    /// The cloud: a sphere whose centre, radius, temperature (the `temperature` primvar, in
    /// kelvin), liquid water and ice (`liquidWater` and `ice`, in grams a kilogram) are sampled
    /// from the frame after the run's last, scaled vertically to its depth once it spreads.
    private func appendCloud(_ samples: [CloudSample], to text: inout Text) {
        let first = frames
        text.append("    def Sphere \"Cloud\"\n    {\n")
        if first > 0 {
            text.append("        token visibility.timeSamples = {\n            0: \"invisible\",\n")
            text.append("            \(first): \"inherited\",\n        }\n")
        }
        text.append("        double radius.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(Float(sample.radius), decimals: 3)
            text.append(",\n")
        }
        text.append("        }\n        float3[] extent.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            let radius = Float(sample.radius)
            text.append("            \(first + n): [")
            text.append(SIMD3(repeating: -radius))
            text.append(", ")
            text.append(SIMD3(repeating: radius))
            text.append("],\n")
        }
        text.append("        }\n        double3 xformOp:translate.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(SIMD3(Float(sample.position.x), Float(sample.position.y), Float(sample.height)))
            text.append(",\n")
        }
        // Flattened once it spreads, its depth against its width.
        text.append("        }\n        float3 xformOp:scale.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(SIMD3(1, 1, Float(sample.halfDepth / max(sample.radius, 1e-9))))
            text.append(",\n")
        }
        text.append(
            "        }\n        uniform token[] xformOpOrder = [\"xformOp:translate\", \"xformOp:scale\"]\n")
        text.append("        color3f[] primvars:displayColor = [")
        text.append(SIMD3<Float>(0.55, 0.52, 0.5))
        text.append("]\n        float primvars:temperature.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(Float(sample.temperature), decimals: 1)
            text.append(",\n")
        }
        text.append("        }\n        float primvars:liquidWater.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(Float(1000 * sample.liquidWater), decimals: 3)
            text.append(",\n")
        }
        text.append("        }\n        float primvars:ice.timeSamples = {\n")
        for (n, sample) in samples.enumerated() {
            text.append("            \(first + n): ")
            text.append(Float(1000 * sample.ice), decimals: 3)
            text.append(",\n")
        }
        text.append("        }\n    }\n\n")
    }

    private func appendPoints(
        _ name: String, _ frames: [[SIMD3<Float>]], _ widths: [Float], _ colour: SIMD3<Float>,
        _ values: [(name: String, values: [Float])], to text: inout Text
    ) {
        let all = frames.joined()
        let low = all.reduce(SIMD3<Float>(repeating: .infinity)) { simd_min($0, $1) }
        let high = all.reduce(SIMD3<Float>(repeating: -.infinity)) { simd_max($0, $1) }
        text.append("    def Points \"\(name)\"\n    {\n        float3[] extent = [")
        text.append(all.isEmpty ? .zero : low)
        text.append(", ")
        text.append(all.isEmpty ? .zero : high)
        text.append("]\n        float[] widths = [")
        for (n, width) in widths.enumerated() {
            if n > 0 { text.append(", ") }
            text.append(width, decimals: 4)
        }
        text.append(
            "] (\n            interpolation = \"vertex\"\n        )\n        color3f[] primvars:displayColor = ["
        )
        text.append(colour)
        text.append("]\n")
        for (primvar, numbers) in values {
            text.append("        float[] primvars:\(primvar) = [")
            for (n, number) in numbers.enumerated() {
                if n > 0 { text.append(", ") }
                text.append(number, decimals: 3)
            }
            text.append("] (\n            interpolation = \"vertex\"\n        )\n")
        }
        text.append("        point3f[] points.timeSamples = {\n")
        for (frame, points) in frames.enumerated() {
            text.append("            \(frame): [")
            for (n, point) in points.enumerated() {
                if n > 0 { text.append(", ") }
                text.append(point)
            }
            text.append("],\n")
        }
        text.append("        }\n    }\n\n")
    }

    /// The air: a Volume whose fields read the frames' OpenVDB files.
    private func appendVolume(to text: inout Text) {
        let domain = scenario.domainSize
        text.append("    def Volume \"Blast\"\n    {\n        float3[] extent = [(0, 0, 0), ")
        text.append(domain)
        text.append("]\n")
        for field in volumeFields {
            text.append("        rel field:\(field) = </Scene/Blast/\(field)>\n")
        }
        for field in volumeFields {
            text.append(
                "\n        def OpenVDBAsset \"\(field)\"\n        {\n            token fieldName = \"\(field)\"\n"
            )
            text.append("            asset filePath.timeSamples = {\n")
            for (frame, path) in volumes {
                text.append("                \(frame): @\(path)@,\n")
            }
            text.append("            }\n        }\n")
        }
        text.append("    }\n\n")
    }

    /// USD cameras look down their local -Z with +Y up; the matrix's rows are the camera's axes
    /// and its position.
    private func appendCamera(_ camera: Camera, to text: inout Text) {
        let back = simd_normalize(camera.eye - camera.target)
        var right = simd_cross(SIMD3<Float>(0, 0, 1), back)
        right = simd_length(right) > 1e-6 ? simd_normalize(right) : SIMD3(1, 0, 0)
        let up = simd_cross(back, right)
        let horizontal: Float = 36
        let vertical = horizontal * 9 / 16
        let focal = vertical / (2 * tan(camera.verticalFieldOfView / 2))
        text.append("    def Camera \"Camera\"\n    {\n        float focalLength = ")
        text.append(focal, decimals: 3)
        text.append("\n        float horizontalAperture = 36\n        float verticalAperture = ")
        text.append(vertical, decimals: 3)
        text.append("\n        float2 clippingRange = (0.1, 5000)\n        matrix4d xformOp:transform = ( ")
        for (n, row) in [right, up, back, camera.eye].enumerated() {
            if n > 0 { text.append(", ") }
            text.append("(")
            text.append(row.x)
            text.append(", ")
            text.append(row.y)
            text.append(", ")
            text.append(row.z)
            text.append(n == 3 ? ", 1)" : ", 0)")
        }
        text.append(" )\n        uniform token[] xformOpOrder = [\"xformOp:transform\"]\n    }\n\n")
    }

    /// The credits the scene's data asks for (OpenStreetMap's, for map buildings), in the layer's
    /// metadata.
    private var attributionData: String {
        guard let credits = scenario.attributions, !credits.isEmpty else { return "" }
        return "\n        string[] attributions = [" + credits.map(quoted).joined(separator: ", ") + "]"
    }

    /// The standing as a dictionary of the layer's metadata: each result's level and summary, the
    /// notes on resolution and what the scene leaves out.
    private var standingData: String {
        guard let standing else { return "" }
        func list(_ lines: [String]) -> String { "[" + lines.map(quoted).joined(separator: ", ") + "]" }
        var lines = ["string table = \(quoted(standing.table))"]
        for result in standing.results {
            lines.append(
                "string \(result.kind.rawValue) = \(quoted("\(result.level.rawValue): \(result.summary)"))")
            if let bands = result.bands, !bands.isEmpty {
                lines.append(
                    "string[] \(result.kind.rawValue)Bands = ["
                        + bands.map {
                            quoted(
                                "\($0.summary), for \($0.validity)"
                                    + ($0.derivedMesh.map { "; derived on \($0)" } ?? "")
                                    + ($0.roundingSpread.map {
                                        String(format: "; roundings ±%.0f%%", 100 * $0)
                                    } ?? ""))
                        }
                        .joined(separator: ", ") + "]")
            }
        }
        lines.append(
            "string[] resolution = \(list(standing.resolution + standing.results.flatMap(\.resolution)))")
        lines.append("string[] notModelled = \(list(standing.unsupported))")
        lines.append(
            "string documentation = \"https://github.com/emmettl/bombcad/blob/main/docs/standing.md\"")
        return "\n        dictionary standing = {\n" + lines.map { "            " + $0 + "\n" }.joined()
            + "        }"
    }

    private func quoted(_ string: String) -> String {
        "\""
            + string.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "\n", with: "\\n") + "\""
    }
}

/// UTF-8 text with fast fixed-point numbers: a frame of a large body holds millions of them.
struct Text {
    var bytes: [UInt8] = []

    mutating func append(_ string: String) { bytes.append(contentsOf: string.utf8) }

    mutating func append(_ value: Float, decimals: Int = 4) {
        guard value.isFinite else {
            bytes.append(UInt8(ascii: "0"))
            return
        }
        var scale: Int64 = 1
        for _ in 0..<decimals { scale *= 10 }
        var fixed = Int64((Double(value) * Double(scale)).rounded())
        if fixed < 0 {
            bytes.append(UInt8(ascii: "-"))
            fixed = -fixed
        }
        appendDigits(fixed / scale)
        var fraction = fixed % scale
        guard fraction != 0 else { return }
        bytes.append(UInt8(ascii: "."))
        var digits = decimals
        while fraction % 10 == 0 {
            fraction /= 10
            digits -= 1
        }
        let start = bytes.count
        appendDigits(fraction)
        for _ in 0..<(digits - (bytes.count - start)) { bytes.insert(UInt8(ascii: "0"), at: start) }
    }

    mutating func append(_ point: SIMD3<Float>) {
        bytes.append(UInt8(ascii: "("))
        append(point.x)
        bytes.append(contentsOf: [UInt8(ascii: ","), UInt8(ascii: " ")])
        append(point.y)
        bytes.append(contentsOf: [UInt8(ascii: ","), UInt8(ascii: " ")])
        append(point.z)
        bytes.append(UInt8(ascii: ")"))
    }

    mutating func appendList(_ values: [Int32]) {
        for (n, value) in values.enumerated() {
            if n > 0 { bytes.append(contentsOf: [UInt8(ascii: ","), UInt8(ascii: " ")]) }
            if value < 0 { bytes.append(UInt8(ascii: "-")) }
            appendDigits(Int64(value.magnitude))
        }
    }

    private mutating func appendDigits(_ value: Int64) {
        guard value >= 10 else {
            bytes.append(UInt8(ascii: "0") + UInt8(value))
            return
        }
        appendDigits(value / 10)
        bytes.append(UInt8(ascii: "0") + UInt8(value % 10))
    }
}
