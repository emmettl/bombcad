import simd

/// Cell-average comparisons against the analytical piston wave before wall reflections.
public enum ExperimentalPistonWaveStudy {
    public struct Frame: Codable, Sendable {
        public let time: Double
        public let steps: Int
        public let rejectedSteps: Int
        public let relativePressureL1: Double
        public let relativeDensityL1: Double
        public let relativeMomentumL1: Double
        public let relativeEnergyL1: Double
        public let relativeWallWorkError: Double
        public let energyBudgetResidual: Double
        public let relativeMassChange: Double
        public let volumeResidual: Double
        public let momentumBudgetResidual: SIMD3<Double>

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            time: Double,
            steps: Int,
            rejectedSteps: Int,
            relativePressureL1: Double,
            relativeDensityL1: Double,
            relativeMomentumL1: Double,
            relativeEnergyL1: Double,
            relativeWallWorkError: Double,
            energyBudgetResidual: Double,
            relativeMassChange: Double,
            volumeResidual: Double,
            momentumBudgetResidual: SIMD3<Double>
        ) {
            self.time = time
            self.steps = steps
            self.rejectedSteps = rejectedSteps
            self.relativePressureL1 = relativePressureL1
            self.relativeDensityL1 = relativeDensityL1
            self.relativeMomentumL1 = relativeMomentumL1
            self.relativeEnergyL1 = relativeEnergyL1
            self.relativeWallWorkError = relativeWallWorkError
            self.energyBudgetResidual = energyBudgetResidual
            self.relativeMassChange = relativeMassChange
            self.volumeResidual = volumeResidual
            self.momentumBudgetResidual = momentumBudgetResidual
        }
    }
    public struct Result: Codable, Sendable {
        public let cellLength: Double
        public let cfl: Double
        public let mergeFraction: Double
        public let pistonVelocity: Double
        public let reconstruction: String
        public let stepControl: String
        public let frames: [Frame]

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            cellLength: Double,
            cfl: Double,
            mergeFraction: Double,
            pistonVelocity: Double,
            reconstruction: String,
            stepControl: String,
            frames: [Frame]
        ) {
            self.cellLength = cellLength
            self.cfl = cfl
            self.mergeFraction = mergeFraction
            self.pistonVelocity = pistonVelocity
            self.reconstruction = reconstruction
            self.stepControl = stepControl
            self.frames = frames
        }
    }
    public static func run(
        limited: Bool = false, halving: Bool = false, strong: Bool = false, mergeStudy: Bool = false,
        cellLengths: [Double] = [0.1, 0.05, 0.025, 0.0125], cfls: [Double] = [0.4, 0.2],
        progress: (Result) throws -> Void = { _ in }
    ) throws
        -> [Result]
    {
        var results: [Result] = []
        for h in cellLengths {
            for cfl in cfls {
                for merge in mergeStudy ? [0.125, 0.25, 0.5] : [0.25] {
                    for speed in strong ? [-100.0, 100.0] : [-20.0, 20.0] {
                        let start = speed < 0 ? 0.655 : 0.355
                        let wave = try PlanarPistonWave(
                            length: start, density: 1.225, pressure: 101325, velocity: speed)
                        let run = try PrescribedPistonTube.run(
                            cellLength: h, area: 0.01, length: start,
                            pistonVelocity: speed, duration: 0.0008, mergeFraction: merge,
                            cfl: cfl, outputTimes: [0.0005, 0.0008],
                            reconstruction: limited ? .minmod : .constant,
                            stepControl: halving ? .halving : .stageAware)
                        let frames = try run.snapshots.map { snapshot in
                            let totalVolume = snapshot.cells.reduce(0) { $0 + $1.volume }
                            var x = 0.0
                            var pressureError = 0.0
                            var densityError = 0.0
                            var momentumError = 0.0
                            var energyError = 0.0
                            for cell in snapshot.cells {
                                let next = x + cell.volume / 0.01
                                let exact = try wave.cell(
                                    lower: x, upper: next, time: snapshot.time, area: 0.01)
                                pressureError += cell.volume * abs(cell.pressure() - exact.pressure())
                                densityError += abs(cell.amount[0] - exact.amount[0])
                                momentumError += abs(cell.amount[1] - exact.amount[1])
                                energyError += abs(cell.amount[4] - exact.amount[4])
                                x = next
                            }
                            let after = snapshot.cells.reduce(SIMD8<Double>.zero) { $0 + $1.amount }
                            let exactWork = 0.01 * wave.wallPressure * speed * snapshot.time
                            return Frame(
                                time: snapshot.time, steps: snapshot.steps,
                                rejectedSteps: snapshot.rejectedSteps,
                                relativePressureL1: pressureError / (101325 * totalVolume),
                                relativeDensityL1: densityError / (1.225 * totalVolume),
                                relativeMomentumL1: momentumError / (1.225 * abs(speed) * totalVolume),
                                relativeEnergyL1: energyError / (101325 / 0.4 * totalVolume),
                                relativeWallWorkError: (snapshot.wallWork - exactWork) / abs(exactWork),
                                energyBudgetResidual: after[4] - run.initialAmount[4] + snapshot.wallWork,
                                relativeMassChange: after[0] / run.initialAmount[0] - 1,
                                volumeResidual: totalVolume - 0.01 * (start + speed * snapshot.time),
                                momentumBudgetResidual: SIMD3(after[1], after[2], after[3])
                                    + snapshot.wallImpulse)
                        }
                        let result = Result(
                            cellLength: h, cfl: cfl, mergeFraction: merge, pistonVelocity: speed,
                            reconstruction: limited ? "minmod" : "constant",
                            stepControl: limited ? (halving ? "halving" : "stageAware") : "singleStage",
                            frames: frames)
                        results.append(result)
                        try progress(result)
                    }
                }
            }
        }
        return results
    }
}
