import Foundation
import simd

/// Reinforced concrete beams struck at mid-span by a falling weight: S. Saatci, "Behaviour and
/// modelling of reinforced concrete structures subjected to impact loads", PhD thesis,
/// University of Toronto, 2007 (published with F. J. Vecchio in the ACI Structural Journal,
/// 2009). Eight beams in four pairs, differing only in their stirrups, each struck first with a
/// 211 kg or a 600 kg weight falling 3.26 m (8.0 m/s); the first impact on each is used here,
/// on an undamaged beam.
public enum ImpactBenchmark {
    /// 250 mm wide, 410 mm deep and 4,880 mm long, on supports 3,000 mm apart that hold it
    /// down as well as up but let it rotate and slide. Two No. 30 bars in the bottom and two in
    /// the top, centred 53 mm in (38 mm cover); closed D-6 stirrups.
    public static let width: Float = 0.25
    public static let depth: Float = 0.41
    public static let length: Float = 4.88
    public static let span: Float = 3.0
    public static let barArea: Float = 2 * 700e-6
    public static let barDepth: Float = 0.053
    /// The 50 mm steel plate, 300 mm square, that the weight struck (here 250 mm across, the
    /// beam's width).
    public static let plate = SIMD2<Float>(0.3, 0.05)
    public static let impactSpeed: Float = 8.0
    public static let bearingLength: Float = 0.1

    public struct Test: Sendable {
        public var name: String
        /// Stirrup spacing in metres, or nil for none.
        public var stirrupSpacing: Float?
        public var weight: Float
        /// Concrete strength at the time of the tests (cylinders tested in December 2005).
        public var concreteStrength: Float
        /// Measured peak and residual mid-span displacements, in metres; nil where the beam failed.
        public var peak: Float?
        public var residual: Float?
        /// Largest reaction recorded at a support (N), Table 5.4.
        public var reaction: Float
        public var remark: String
    }

    /// The first impacts (Table 6.3 of the thesis), and SS0b-1, which failed.
    public static let tests: [Test] = [
        Test(
            name: "SS0a-1", stirrupSpacing: nil, weight: 211, concreteStrength: 50.1e6, peak: 0.0093,
            residual: 0.0016, reaction: 305e3,
            remark: "diagonal cracks up to 0.5 mm"),
        Test(
            name: "SS1a-1", stirrupSpacing: 0.3, weight: 211, concreteStrength: 44.7e6, peak: 0.0121,
            residual: 0.0009, reaction: 356e3,
            remark: ""),
        Test(
            name: "SS2a-1", stirrupSpacing: 0.2, weight: 211, concreteStrength: 47.0e6, peak: 0.0100,
            residual: 0.0005, reaction: 327e3,
            remark: ""),
        Test(
            name: "SS0b-1", stirrupSpacing: nil, weight: 600, concreteStrength: 50.1e6, peak: nil,
            residual: nil,
            reaction: 399e3,
            remark: "punched through: a shear plug, the bars exposed and bent"),
        Test(
            name: "SS1b-1", stirrupSpacing: 0.3, weight: 600, concreteStrength: 44.7e6, peak: 0.0395,
            residual: 0.0177, reaction: 625e3,
            remark: ""),
        Test(
            name: "SS2b-1", stirrupSpacing: 0.2, weight: 600, concreteStrength: 47.0e6, peak: 0.0379,
            residual: 0.0185, reaction: 592e3,
            remark: ""),
        Test(
            name: "SS3b-1", stirrupSpacing: 0.1, weight: 600, concreteStrength: 46.7e6, peak: 0.0353,
            residual: 0.0177, reaction: 682e3,
            remark: ""),
    ]

    /// Concrete of the measured strength, 3.2 MPa in tension (measured after the tests: 3.1 to
    /// 3.4 MPa) and 10 mm aggregate, strengthening with strain rate; No. 30 bars yielding at 464
    /// MPa, 630 MPa at ultimate, 195 GPa. The D-6 stirrups (605 MPa) are taken with the bars'
    /// curve.
    public static func material(_ test: Test) -> StructureMaterial {
        var steel = SteelProperties(
            yieldStress: 464e6, ultimateStress: 630e6, ultimateStrain: 0.1, ruptureStrain: 0.15)
        steel.youngsModulus = 195e9
        var material = StructureMaterial.concrete(
            name: "Saatci beam", compressiveStrength: test.concreteStrength, density: 2437, steel: steel)
        material.tensileStrength = 3.2e6
        material.aggregateSize = 0.010
        material.rateDependent = true
        return material
    }

    /// A beam struck at mid-span: its section, span, bars, stirrups, the steel plate the weight
    /// strikes and the bearings, all in metres.
    public struct Specimen: Sendable {
        public var width: Float
        public var depth: Float
        public var length: Float
        /// Between the supports' centres, which are central on the beam.
        public var span: Float
        /// Bars along the beam: total area (m²) and the height of their centre above the bottom.
        public var bars: [(area: Float, height: Float)]
        /// Closed stirrups: the area of their two legs together, and their spacing.
        public var stirrups: (legs: Float, spacing: Float)?
        /// The plate struck: its length along the beam and its thickness (it spans the width).
        public var plate: SIMD2<Float>
        public var bearingLength: Float
        public var material: StructureMaterial
        /// Both supports hold the beam lengthwise (pins), rather than one (a pin and a roller).
        public var pinnedEnds = false
        /// Steel plates of this thickness, `bearingLength` long, under and over the beam at each
        /// support, held along their centre lines only: clamps that turn with the beam. Nil
        /// holds the beam's own faces over the bearing length instead, which resists its ends'
        /// turning.
        public var supportPlates: Float?
        /// An elastic pad between the weight and the plate, of this stiffness per unit area
        /// (Pa/m): the compliance of the weight's contact with a plate seated loose on the beam.
        /// It is one element thick, its modulus the stiffness times the element size. Nil strikes
        /// the plate's top nodes directly, a contact infinitely stiff.
        public var pad: Float?
        /// Where the weight strikes, its centre's distance from the first support; nil at
        /// mid-span.
        public var strike: Float?
        /// The supports hold the beam's top face down over the bearing length as well as bearing
        /// its bottom face; false lets it lift off them.
        public var heldDown = true
    }

    public static func specimen(_ test: Test) -> Specimen {
        Specimen(
            width: width, depth: depth, length: length, span: span,
            bars: [(barArea, barDepth), (barArea, depth - barDepth)],
            stirrups: test.stirrupSpacing.map { (2 * 38.71e-6, $0) }, plate: plate,
            bearingLength: bearingLength,
            material: material(test))
    }

    /// The beam meshed with solid elements, `elementsThroughDepth` of them, with the steel plate on
    /// top at mid-span.
    public static func model(_ test: Test, elementsThroughDepth: Int) -> StructureModel {
        model(specimen(test), elementsThroughDepth: elementsThroughDepth)
    }

    public static func model(_ specimen: Specimen, elementsThroughDepth: Int) -> StructureModel {
        let s = specimen
        let h = s.depth / Float(elementsThroughDepth)
        let base = (1 / h).rounded() * h
        let beam = Box(min: SIMD3(0, 0, base), max: SIMD3(s.length, s.width, base + s.depth))
        let middle = s.strike.map { (s.length - s.span) / 2 + $0 } ?? s.length / 2
        // The plate struck, if it has a thickness; the pad, if any, on it or on the beam.
        let plateBox = Box(
            min: SIMD3(middle - s.plate.x / 2, 0, base + s.depth),
            max: SIMD3(middle + s.plate.x / 2, s.width, base + s.depth + s.plate.y))
        var solids = [beam]
        if s.plate.y > 0 { solids.append(plateBox) }
        var padIndex: Int?
        if s.pad != nil {
            padIndex = solids.count
            solids.append(
                Box(
                    min: SIMD3(plateBox.min.x, 0, plateBox.max.z),
                    max: SIMD3(plateBox.max.x, s.width, plateBox.max.z + h)))
        }
        if let thickness = s.supportPlates {
            let t = max((thickness / h).rounded(), 1) * h
            for support in [(s.length - s.span) / 2, (s.length + s.span) / 2] {
                let x = (support - s.bearingLength / 2)...(support + s.bearingLength / 2)
                solids.append(
                    Box(min: SIMD3(x.lowerBound, 0, base - t), max: SIMD3(x.upperBound, s.width, base)))
                solids.append(
                    Box(
                        min: SIMD3(x.lowerBound, 0, base + s.depth),
                        max: SIMD3(x.upperBound, s.width, base + s.depth + t)))
            }
        }
        var model = StructureModel(
            solids: solids, material: s.material, elementSize: h, fixedBase: false)
        for index in 1..<solids.count { model.setMaterial(.structuralSteel, of: index) }
        if let stiffness = s.pad {
            model.setMaterial(
                StructureMaterial(
                    name: "Pad", density: 1000, youngsModulus: stiffness * h, poissonRatio: 0.3,
                    yieldStress: 1e12,
                    hardeningModulus: 0, failureStrain: 10),
                of: padIndex ?? 2)
        }
        var bands: [ReinforcementLayer] = []
        for bar in s.bars {
            let reach = h / 2
            var band = beam
            band.min.z = base + bar.height - reach
            band.max.z = base + bar.height + reach
            bands.append(
                ReinforcementLayer(region: band, ratio: SIMD3(bar.area / (s.width * 2 * reach), 0, 0)))
        }
        if let stirrups = s.stirrups {
            // Two legs each way, smeared through the section.
            bands.append(
                ReinforcementLayer(
                    region: beam,
                    ratio: SIMD3(
                        0, stirrups.legs / (s.depth * stirrups.spacing),
                        stirrups.legs / (s.width * stirrups.spacing))))
        }
        model.reinforcement = bands
        return model
    }

    public struct Result: Sendable {
        /// Mid-span displacement of the bottom face (m, downwards) against time (s).
        public var history: [SIMD2<Float>]
        public var peak: Float
        public var residual: Float
        /// Largest reaction at either support (N), averaged over 0.5 ms as the load cells, read
        /// 2,400 times a second, would see it.
        public var peakReaction: Float
        /// Largest impact force (N): the weight's mass times its deceleration, while it rides
        /// the plate, averaged over the 0.42 ms between the tests' readings of its accelerometers.
        public var peakImpactForce: Float = 0
        /// When the impact force peaks (s), and each support's largest reaction (N, over 0.5 ms)
        /// and when it comes, the first support first.
        public var impactPeakTime: Float = 0
        public var supportReactions: SIMD2<Float> = .zero
        public var supportReactionTimes: SIMD2<Float> = .zero
        public var summary: StructureSummary
        public var elementCount: Int
        public var wallSeconds: Double

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            history: [SIMD2<Float>],
            peak: Float,
            residual: Float,
            peakReaction: Float,
            peakImpactForce: Float = 0,
            impactPeakTime: Float = 0,
            supportReactions: SIMD2<Float> = .zero,
            supportReactionTimes: SIMD2<Float> = .zero,
            summary: StructureSummary,
            elementCount: Int,
            wallSeconds: Double
        ) {
            self.history = history
            self.peak = peak
            self.residual = residual
            self.peakReaction = peakReaction
            self.peakImpactForce = peakImpactForce
            self.impactPeakTime = impactPeakTime
            self.supportReactions = supportReactions
            self.supportReactionTimes = supportReactionTimes
            self.summary = summary
            self.elementCount = elementCount
            self.wallSeconds = wallSeconds
        }
    }

    public struct BeamResult: Sendable {
        public var peak: Float
        public var residual: Float
        public var peakReaction: Float
        /// Beams whose section failed in shear, and beams removed.
        public var sheared: Int
        public var removed: Int
        public var wallSeconds: Double

        /// The memberwise initialiser, written out so that BlastCore can use it.
        package init(
            peak: Float,
            residual: Float,
            peakReaction: Float,
            sheared: Int,
            removed: Int,
            wallSeconds: Double
        ) {
            self.peak = peak
            self.residual = residual
            self.peakReaction = peakReaction
            self.sheared = sheared
            self.removed = removed
            self.wallSeconds = wallSeconds
        }
    }

    /// Beams without stirrups struck once each, at increasing speeds, until they broke in shear:
    /// T. Ando, N. Kishi, H. Mikami and K. G. Matsuoka, "Weight falling impact tests on
    /// shear-failure type RC beams without stirrups", *Structures under Shock and Impact VI*, WIT
    /// Press, 2000 (open access). 150 × 250 mm beams, two bottom bars 40 mm up (D19 in series A,
    /// D13 in B), clamped top and bottom 200 mm in from each end, struck at mid-span by 300 kg.
    /// Assumed: the weight's face as a 100 mm steel plate, the clamps 50 mm long, 2,350 kg/m³ and
    /// 20 mm aggregate. 33 MPa concrete, 393 MPa bars.
    public struct ShearTest: Sendable {
        public var name: String
        /// Rebar series: true for A (2 D19, 1.82%), false for B (2 D13, 0.80%).
        public var heavyBars: Bool
        /// Shear span over effective depth (span = 2 a, d = 208 mm).
        public var shearSpanRatio: Float
        public var speed: Float
        /// What the paper reports: whether the beam broke apart in shear, and its peak and
        /// residual mid-span displacement where given (read off its plots, to about 2 mm).
        public var broken: Bool
        public var peak: Float?
        public var residual: Float?
        public var remark: String
    }

    /// The tests the paper's text and figures report: the 1.5 m beams' displacement histories,
    /// and the loops of load against displacement for the 1.0 m beams with D19 bars and the
    /// 2.0 m beams with D13, whose ends give the peak and where they come back to no load the
    /// residual.
    public static let shearTests: [ShearTest] = {
        func test(
            _ name: String, _ heavy: Bool, _ ratio: Float, _ speed: Float, _ peak: Float?, _ residual: Float?,
            broken: Bool = false, _ remark: String = ""
        ) -> ShearTest {
            ShearTest(
                name: name, heavyBars: heavy, shearSpanRatio: ratio, speed: speed, broken: broken,
                peak: peak.map { $0 / 1000 }, residual: residual.map { $0 / 1000 }, remark: remark)
        }
        return [
            test("A24-1", true, 2.4, 1, 2, 0),
            test("A24-3", true, 2.4, 3, 11, 8),
            test("A24-4", true, 2.4, 4, 16, 11),
            test("A24-5", true, 2.4, 5, 29, 25, broken: true, "broken by diagonal cracks"),
            test("A24-6", true, 2.4, 6, 54, 48, broken: true, "broken by diagonal cracks"),
            test("A36-1", true, 3.6, 1, 1.5, 0, "flexural cracks only"),
            test("A36-3", true, 3.6, 3, 13.5, 9.5, "a severe diagonal crack from the load to the support"),
            test("A36-4", true, 3.6, 4, 28, 24, "diagonal cracks"),
            test("A36-5", true, 3.6, 5, 66, 53, broken: true, "split into three by diagonal cracks"),
            test("A48-4", true, 4.8, 4, nil, 10.7, "bent, not failed"),
            test("B36-1", false, 3.6, 1, 2.7, 0, "flexural cracks only"),
            test("B36-3", false, 3.6, 3, 16, 11.4, "flexure cracks"),
            test("B36-4", false, 3.6, 4, 26, 22.6, "bent, flexure cracks only"),
            test("B36-5", false, 3.6, 5, 105, 88, broken: true, "broken by a wide diagonal crack"),
            test("B48-1", false, 4.8, 1, 4, 0, "flexure cracks"),
            test("B48-3", false, 4.8, 3, 21, 19, "bent"),
            test("B48-4", false, 4.8, 4, 36, 30, "bent"),
            test("B48-5", false, 4.8, 5, 55, 47, "bent far"),
            test("B48-6", false, 4.8, 6, 73, 70, "bent far"),
        ]
    }()

    /// The paper's measured materials (two casts, averaged): concrete of 33 MPa with a modulus
    /// of 23.3 GPa and Poisson's ratio 0.21; D19 bars yielding at 385 MPa and breaking at 577,
    /// D13 at 400 and 573, both 206 GPa.
    public static func specimen(_ test: ShearTest) -> Specimen {
        let span = 2 * test.shearSpanRatio * 0.208
        var steel = SteelProperties(
            yieldStress: test.heavyBars ? 385e6 : 400e6, ultimateStress: test.heavyBars ? 577e6 : 573e6,
            ultimateStrain: 0.1, ruptureStrain: 0.15)
        steel.youngsModulus = 206e9
        var material = StructureMaterial.concrete(
            name: "Ando beam", compressiveStrength: 33e6, density: 2350, steel: steel)
        material.youngsModulus = 23.3e9
        material.poissonRatio = 0.21
        material.aggregateSize = 0.02
        material.rateDependent = true
        // The paper describes the clamps as letting the beam turn and nothing else. Held as pins
        // at both ends, or on plates that turn freely, the beams went further than with the
        // clamps holding their faces over 50 mm, and further than the tests (docs/validation.md).
        return Specimen(
            width: 0.15, depth: 0.25, length: span + 0.4, span: span,
            bars: [(test.heavyBars ? 2 * 286.5e-6 : 2 * 126.7e-6, 0.04)], stirrups: nil,
            plate: SIMD2(0.1, 0.04), bearingLength: 0.05, material: material)
    }

    // MARK: - Peterson et al. (KTH, 2026): short beams struck to a shear failure

    /// One of V. Peterson, J. Magnusson, M. Hallgren and A. Ansell's beams, "Shear-type failure of
    /// deep, short and slender impact-loaded RC beams", International Journal of Impact Engineering
    /// 208, 105539 (2026), described in Peterson's KTH thesis (2026) and Data in Brief 65, 112487
    /// (2026). The records are V. Peterson's on Mendeley Data, doi:10.17632/kn28g6dbj5.3, CC BY 4.0;
    /// the measured values below are derived from them (docs/validation.md says how).
    public struct PetersonTest: Sendable {
        public var name: String
        /// The weight's centre from the first support (m): 48, 120 or 240 mm, shear spans of
        /// 0.4, 1 and 2 effective depths.
        public var strike: Float
        public var stirrupSpacing: Float?
        /// Measured, where the beam has a record: the largest impact force (N, the striker's 70 kg
        /// times its deceleration over 0.42 ms) and the largest reactions at the near and far
        /// supports (N, over 0.5 ms), and when each came after the impact began (s).
        public var impact: Float?
        public var nearReaction: Float?
        public var farReaction: Float?
        public var impactTime: Float?
        public var nearTime: Float?
        public var farTime: Float?
        /// The damage Peterson records: SC strut crushing, SCS strut crushing at the support,
        /// FS flexural-shear, F flexure.
        public var damage: String
    }

    public static let petersonWeight: Float = 70
    /// Dropped 2.4 m through a guiding tube.
    public static let petersonSpeed: Float = (2 * 9.81 * 2.4 as Float).squareRoot()

    public static let petersonTests: [PetersonTest] = {
        // name, strike (mm), stirrups (mm), impact, near, far (kN), at (ms), damage
        let rows: [(String, Float, Float?, [Float]?, String)] = [
            ("D-04d-NoS-1", 48, nil, [195, 206, 29, 0.94, 0.89, 4.69], "SC"),
            ("D-04d-NoS-2", 48, nil, [260, 220, 20, 0.78, 1.04, 4.69], "SCS"),
            ("D-04d-S90-1", 48, 90, nil, "SCS"),
            // The record filed as D-04d-S90-2, which the dataset's readme says has none: its
            // striker trace implies five times the striker's momentum, so its impact force is left
            // out; its load cells read as the others'.
            ("D-04d-S90-2", 48, 90, [.nan, 217, 12, .nan, 0.89, 11.88], "SCS"),
            ("D-04d-S45-1", 48, 45, nil, "SCS"),
            ("D-04d-S45-2", 48, 45, [211, 192, 13, 0.73, 0.83, 7.81], "SCS"),
            ("D-1d-NoS-1", 120, nil, [282, 161, 44, 0.94, 1.15, 2.66], "SC"),
            ("D-1d-NoS-2", 120, nil, [296, 179, 49, 0.83, 1.04, 3.70], "SC"),
            ("D-1d-S90-1", 120, 90, [227, 163, 54, 1.30, 1.61, 3.23], "SC"),
            ("D-1d-S90-2", 120, 90, [207, 160, 75, 1.25, 1.20, 3.39], "SC"),
            ("D-1d-S45-1", 120, 45, [237, 196, 78, 0.52, 0.99, 3.28], "SC"),
            ("D-1d-S45-2", 120, 45, [246, 157, 62, 0.89, 0.89, 3.02], "SC"),
            ("D-2d-NoS-1", 240, nil, [210, 107, 84, 0.47, 1.46, 2.29], "FS"),
            ("D-2d-NoS-2", 240, nil, [298, 140, 81, 0.68, 1.35, 2.50], "FS"),
            ("D-2d-S90-1", 240, 90, [214, 111, 81, 0.52, 0.99, 2.34], "F"),
            ("D-2d-S90-2", 240, 90, [263, 121, 86, 0.52, 1.25, 2.40], "F"),
            ("D-2d-S45-1", 240, 45, [208, 110, 76, 0.47, 1.09, 2.34], "F"),
            ("D-2d-S45-2", 240, 45, [219, 121, 80, 0.26, 1.09, 2.34], "F"),
        ]
        return rows.map { name, strike, spacing, values, damage in
            func value(_ i: Int, _ scale: Float) -> Float? {
                guard let v = values?[i], v.isFinite else { return nil }
                return v * scale
            }
            return PetersonTest(
                name: name, strike: strike / 1000, stirrupSpacing: spacing.map { $0 / 1000 },
                impact: value(0, 1000), nearReaction: value(1, 1000), farReaction: value(2, 1000),
                impactTime: value(3, 0.001), nearTime: value(4, 0.001), farTime: value(5, 0.001),
                damage: damage)
        }
    }()

    /// The fibreboard between striker and beam, as a pad of this stiffness per unit area (Pa/m),
    /// set so that the struck beams' impact forces come out as measured (see docs/validation.md).
    public static let petersonPad: Float = 2e9

    public static func specimen(_ test: PetersonTest) -> Specimen {
        // 0.80 m long, 150 x 150 mm, on supports 0.70 m apart; three 8 mm bars in the face struck
        // away from and two in the face struck, both 30 mm in (26 mm cover); 6 mm stirrups. K500C
        // bars: 8 mm 511 / 622 MPa, 6 mm 609 / 701 MPa (the model takes the 8 mm bars' steel for
        // both). Concrete 44 MPa on cubes, taken as 36 MPa on cylinders. Assumed: the striker's
        // face 100 mm long across the beam's width, the supports 30 mm wide, 16 mm aggregate.
        var steel = SteelProperties(
            yieldStress: 511e6, ultimateStress: 622e6, ultimateStrain: 0.08, ruptureStrain: 0.12)
        steel.youngsModulus = 200e9
        var material = StructureMaterial.concrete(
            name: "Peterson beam", compressiveStrength: 36e6, density: 2400, steel: steel)
        material.aggregateSize = 0.016
        material.rateDependent = true
        let bar: Float = .pi * 0.004 * 0.004
        let leg: Float = .pi * 0.003 * 0.003
        var specimen = Specimen(
            width: 0.15, depth: 0.15, length: 0.80, span: 0.70,
            bars: [(3 * bar, 0.030), (2 * bar, 0.120)],
            stirrups: test.stirrupSpacing.map { (2 * leg, $0) }, plate: SIMD2(0.1, 0),
            bearingLength: 0.03, material: material)
        specimen.pad = petersonPad
        specimen.strike = test.strike
        specimen.heldDown = false
        return specimen
    }
}
