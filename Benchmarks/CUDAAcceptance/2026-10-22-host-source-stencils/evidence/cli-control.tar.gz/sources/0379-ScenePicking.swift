import Foundation
import simd

/// Picking follows the sampled solids, including openings, rather than the source AABB.
public enum ScenePicking {
    public static func distance(to box: Box, origin: SIMD3<Float>, direction: SIMD3<Float>) -> Float? {
        guard simd_length_squared(direction) > 0 else { return nil }
        // Preserve the historical strictly-below threshold; the shared query uses <=.
        return box.intersection(
            origin: origin, direction: direction,
            parallelTolerance: Float(1e-8).nextDown)?.lowerBound
    }
    /// The envelope building a ray from `origin` along `direction` meets first: the scene's, or one of
    /// its far set's (`FarFieldSet`) beyond the air; the scene's other blocks hide what lies behind
    /// them. Nil if it meets none first.
    public static func envelope(
        in scenario: Scenario, far: FarFieldSet? = nil, origin: SIMD3<Float>, direction: SIMD3<Float>
    ) -> UUID? {
        var closest = Float.infinity
        var selected: UUID?
        func visit(_ boxes: [Box], id: UUID?) {
            for box in boxes {
                if let hit = distance(to: box, origin: origin, direction: direction), hit < closest {
                    closest = hit
                    selected = id
                }
            }
        }
        visit(scenario.boxes, id: nil)
        for object in scenario.envelopeObjects { visit(object.envelope!.blocks, id: object.id) }
        for building in far?.buildings ?? [] { visit(building.envelope.blocks, id: building.id) }
        return selected
    }

    public static func importedModel(in scenario: Scenario, origin: SIMD3<Float>, direction: SIMD3<Float>)
        -> UUID?
    {
        var closest = Float.infinity
        var selected: UUID?
        func visit(_ boxes: [Box], id: UUID?) {
            for box in boxes {
                if let hit = distance(to: box, origin: origin, direction: direction), hit < closest {
                    closest = hit
                    selected = id
                }
            }
        }
        visit(scenario.boxes, id: nil)
        visit(scenario.envelopeObjects.flatMap { $0.envelope!.blocks }, id: nil)
        let legacySources = (scenario.importedModels ?? []).filter {
            $0.isAttached && $0.behavior == .deformable
        }
        for object in scenario.structuralObjects {
            let body = object.structure!
            let owner = scenario.importedModels?.first { model in
                model.isAttached && model.behavior == .deformable
                    && (model.id == object.sourceModelID
                        || (object.sourceModelID == nil && scenario.structuralObjects.count == 1
                            && legacySources.count == 1))
            }
            for solid in body.solids {
                // Subtract openings before intersecting the ray. Work is bounded per member.
                let fragments = ImportPlacementReport.subtracting(body.openings, from: solid, limit: 4096)
                // In ambiguous over-budget cases, occlude rather than select through unknown geometry.
                visit(
                    fragments.complete ? fragments.boxes : [solid], id: fragments.complete ? owner?.id : nil)
            }
        }
        for model in scenario.importedModels ?? [] where model.isAttached && model.behavior == .rigid {
            visit(model.preview.boxes, id: model.id)
        }
        if direction.z < -1e-8 && origin.z >= 0 {
            let ground = -origin.z / direction.z
            if ground < closest { return nil }
        }
        return selected
    }

    /// The building a ray from `origin` along `direction` meets first: an exposure-only envelope or
    /// a structure, by the id of its scene object; nil where a block or the ground is nearer, or
    /// nothing is hit. For choosing the buildings the refinement goes toward.
    public static func building(in scenario: Scenario, origin: SIMD3<Float>, direction: SIMD3<Float>) -> UUID?
    {
        var closest = Float.infinity
        var selected: UUID?
        func visit(_ boxes: [Box], id: UUID?) {
            for box in boxes {
                if let hit = distance(to: box, origin: origin, direction: direction), hit < closest {
                    closest = hit
                    selected = id
                }
            }
        }
        visit(scenario.boxes, id: nil)
        for object in scenario.envelopeObjects { visit(object.envelope?.blocks ?? [], id: object.id) }
        for object in scenario.structuralObjects { visit(object.structure?.solids ?? [], id: object.id) }
        if direction.z < -1e-8 && origin.z >= 0 {
            let ground = -origin.z / direction.z
            if ground < closest { return nil }
        }
        return selected
    }
}
