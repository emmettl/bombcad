import Foundation

/// A building component as an equivalent single degree of freedom, after Biggs (1964) as UFC
/// 3-340-02 (2008, change 2 of 2014; "UFC" below) reproduces it in chapter 3. The deflection at
/// the component's middle, `x`, obeys
///
///     K_LM m ẍ + c ẋ + R(x) = p(t)
///
/// per unit area: `m` its mass per area, `R` its resistance per area (a backbone of pressure
/// against deflection, unloading at the elastic stiffness), `p` the net pressure pushing it in,
/// and `K_LM` the load–mass factor. One way: the air never sees it move.
public struct SDOFSystem: Codable, Hashable, Sendable {
    /// Mass per unit area, kg/m².
    public var massPerArea: Double
    /// Load–mass factors (UFC Tables 3-12 and 3-13). UFC §3-17.4: the elastic factor until the
    /// component first yields, then the mean of the elastic and plastic ones up to 2° of support
    /// rotation, and the plastic one beyond (or at once past yield when no span is given).
    public var loadMassElastic: Double
    public var loadMassPlastic: Double
    /// Resistance against inward deflection: (deflection m, resistance Pa) points beyond (0, 0),
    /// deflection increasing. The first segment is elastic; beyond the last point the resistance
    /// stays at the last value. A last value of 0 is a component that has lost all resistance.
    public var backbone: [SIMD2<Double>]
    /// Resistance against outward deflection (rebound) as a fraction of the inward resistance
    /// (UFC §3-19): the backbone at the furthest inward deflection reached, or at its elastic limit
    /// before that; a component that has lost its inward resistance has none outward either.
    public var reboundFactor: Double
    /// Viscous damping as a fraction of critical, on the elastic period; UFC takes none.
    public var dampingRatio: Double
    /// The span whose support rotation sets the load–mass factor (UFC §3-17.4), m, if known.
    public var span: Double?
    /// A brittle component that stiffens as it deflects (glass, `largeDeflectionGlass`): its
    /// resistance follows the backbone both ways, with no permanent set, until it breaks.
    public var brittle: Brittle?
    /// A laminated pane's interlayer: once the glass has cracked, the plies' fragments held on it
    /// carry the load as a membrane instead of the pane losing its resistance (`LaminatedGlass`).
    public var membrane: Membrane?

    /// A cracked laminated pane as a membrane under uniform tension T (N/m): pressure against
    /// deflection p = shape T x / span², both ways, until it tears (deflection over span reaching
    /// `tearRatio`) or pulls out of its frame (the tension, reached as the deflection grows to
    /// `plateauDeflection`, exceeding the edge's `edgeCapacity`, N/m).
    public struct Membrane: Codable, Hashable, Sendable {
        public var tension: Double
        public var shape: Double
        public var span: Double
        public var tearRatio: Double
        public var plateauDeflection: Double
        public var edgeCapacity: Double?
        /// Held while it is pushed in, gone once it first moves back out (daylight security film,
        /// `SecurityFilm.Anchorage.daylight`); nil for no such release (left out of the JSON).
        public var releasesOnRebound: Bool?

        public init(
            tension: Double, shape: Double, span: Double, tearRatio: Double, plateauDeflection: Double,
            edgeCapacity: Double?, releasesOnRebound: Bool? = nil
        ) {
            self.tension = tension
            self.shape = shape
            self.span = span
            self.tearRatio = tearRatio
            self.plateauDeflection = plateauDeflection
            self.edgeCapacity = edgeCapacity
            self.releasesOnRebound = releasesOnRebound
        }

        /// The resistance at deflection `x`, Pa, either way.
        public func resistance(at x: Double) -> Double { shape * tension * x / (span * span) }

        /// Whether it has torn or pulled out at deflection `x`, moving at `v` (inward positive).
        public func isLost(at x: Double, velocity v: Double = 0) -> Bool {
            if x.magnitude / span >= tearRatio { return true }
            if releasesOnRebound == true, v < 0 { return true }
            if let edgeCapacity, tension * smaller(x.magnitude / plateauDeflection, 1) > edgeCapacity {
                return true
            }
            return false
        }
    }

    /// When a brittle component breaks: its largest principal stress against its deflection, and
    /// glass's static fatigue (Brown's integral), a stress σ(t) breaking it when ∫ (σ/S)ⁿ dt
    /// reaches the reference duration, S its strength held for that long.
    public struct Brittle: Codable, Hashable, Sendable {
        /// (deflection m, largest principal stress Pa) points, deflection increasing.
        public var stress: [SIMD2<Double>]
        /// Pa, held for `referenceDuration`.
        public var strength: Double
        /// s.
        public var referenceDuration: Double
        /// n; nil breaks it as soon as the stress reaches the strength.
        public var fatigueExponent: Double?

        public init(
            stress: [SIMD2<Double>], strength: Double, referenceDuration: Double, fatigueExponent: Double?
        ) {
            self.stress = stress
            self.strength = strength
            self.referenceDuration = referenceDuration
            self.fatigueExponent = fatigueExponent
        }

        /// The largest principal stress at deflection `x` either way, Pa.
        public func stress(at x: Double) -> Double {
            var hint = 1
            return Self.stress(stress, at: x, hint: &hint)
        }

        /// The same on the (deflection, stress) points `stress`, its segment searched from `hint`
        /// (`SDOFSystem.interpolate`).
        static func stress(_ stress: [SIMD2<Double>], at x: Double, hint: inout Int) -> Double {
            let x = x.magnitude
            guard x > stress[0].x else { return stress[0].y * x / stress[0].x }
            return SDOFSystem.interpolate(stress, past: x, hint: &hint)
        }
    }

    public init(
        massPerArea: Double, loadMassElastic: Double, loadMassPlastic: Double, backbone: [SIMD2<Double>],
        reboundFactor: Double = 1, dampingRatio: Double = 0, span: Double? = nil, brittle: Brittle? = nil,
        membrane: Membrane? = nil
    ) {
        precondition(massPerArea > 0 && loadMassElastic > 0 && loadMassPlastic > 0)
        precondition(!backbone.isEmpty && backbone[0].x > 0 && backbone[0].y > 0)
        precondition(zip(backbone, backbone.dropFirst()).allSatisfy { $0.x < $1.x })
        self.massPerArea = massPerArea
        self.loadMassElastic = loadMassElastic
        self.loadMassPlastic = loadMassPlastic
        self.backbone = backbone
        self.reboundFactor = reboundFactor
        self.dampingRatio = dampingRatio
        self.span = span
        self.brittle = brittle
        self.membrane = membrane
    }

    /// An elastic–perfectly plastic system: stiffness `stiffness` (Pa/m) up to `ultimate` (Pa).
    public static func elasticPlastic(
        massPerArea: Double, stiffness: Double, ultimate: Double, loadMassElastic: Double = 1,
        loadMassPlastic: Double = 1, reboundFactor: Double = 1, span: Double? = nil
    ) -> SDOFSystem {
        SDOFSystem(
            massPerArea: massPerArea, loadMassElastic: loadMassElastic, loadMassPlastic: loadMassPlastic,
            backbone: [SIMD2(ultimate / stiffness, ultimate)], reboundFactor: reboundFactor, span: span)
    }

    /// Elastic stiffness, Pa/m.
    public var stiffness: Double { backbone[0].y / backbone[0].x }
    /// Largest resistance on the backbone, Pa.
    public var ultimateResistance: Double {
        // `backbone.map(\.y).max()!` by index (`Sequence.max` keeps the first of equals, replacing
        // it only by a larger): `integrate` reads this twice a call, and unspecialised in a debug
        // build the map and max cost more than a short response's steps.
        var ultimate = backbone[0].y
        var i = 1
        while i < backbone.count {
            if ultimate < backbone[i].y { ultimate = backbone[i].y }
            i += 1
        }
        return ultimate
    }
    /// The equivalent elastic deflection X_E of UFC eqs 3-34 to 3-36: the deflection at the
    /// ultimate resistance on a single line of the same area under the curve up to it.
    public var equivalentElasticDeflection: Double {
        let ultimate = ultimateResistance
        var area = 0.0
        var previous = SIMD2<Double>.zero
        var i = 0
        while i < backbone.count {
            let point = backbone[i]
            area += 0.5 * (previous.y + point.y) * (point.x - previous.x)
            previous = point
            if point.y == ultimate { break }
            i += 1
        }
        // The deflection where it reaches the ultimate resistance, less the area's excess over a
        // rectangle, is X_E (eq 3-34 for two segments, 3-35 for three).
        return 2 * (previous.x * ultimate - area) / ultimate
    }
    /// Natural period while elastic, s (UFC eq 3-60 on the equivalent elastic stiffness).
    public var period: Double {
        2 * .pi
            * (loadMassElastic * massPerArea * equivalentElasticDeflection / ultimateResistance).squareRoot()
    }

    /// The backbone's resistance at deflection `x` ≥ 0.
    func envelope(_ x: Double) -> Double {
        var hint = 1
        return Self.envelope(backbone, x, hint: &hint)
    }

    /// The same on the backbone `backbone`, its segment searched from
    /// `hint` (`interpolate`). Static, the table passed in: in a debug build, reading
    /// `self.backbone` retained and released it on each call, and `integrate` calls this twice a
    /// step.
    static func envelope(_ backbone: [SIMD2<Double>], _ x: Double, hint: inout Int) -> Double {
        if x <= backbone[0].x { return backbone[0].y / backbone[0].x * x }
        return interpolate(backbone, past: x, hint: &hint)
    }

    /// Linear in `table`'s (x, y) points at `x` past the first: between the first point with
    /// x ≤ its own and the one before, or the last point's y if there is none. That point is
    /// searched from index `hint` (≥ 1), back or on, and `hint` left at it. On a table whose x
    /// never decreases, `x <= table[i].x` is false and then true along it, so the search finds
    /// the same point from any start; on any other, start at 1 each time.
    ///
    /// By index, not over `zip(table, table.dropFirst())`: unspecialised in a debug build, the
    /// zip's iterators looked up generic metadata on every call, and a district's judgement took a
    /// minute in debug tests. From the last step's point, not the first: a pane's tables have
    /// 75–89 points, `integrate` looks in two of them each step, and the next step is almost always
    /// on the same segment.
    static func interpolate(_ table: [SIMD2<Double>], past x: Double, hint: inout Int) -> Double {
        let count = table.count
        var i = hint
        while i > 1, x <= table[i - 1].x { i -= 1 }
        while i < count, !(x <= table[i].x) { i += 1 }
        hint = i
        guard i < count else { return table[count - 1].y }
        let a = table[i - 1]
        let b = table[i]
        return a.y + (b.y - a.y) * (x - a.x) / (b.x - a.x)
    }

    /// Whether `table`'s x never decreases (`interpolate`).
    static func isOrdered(_ table: [SIMD2<Double>]) -> Bool {
        var i = 1
        while i < table.count {
            guard table[i].x >= table[i - 1].x else { return false }
            i += 1
        }
        return true
    }

    /// The response to a net pressure held at `pressures[i]` over [i·step, (i+1)·step) and then
    /// released, followed until `tail` elastic periods after the load ends. A recorded history's
    /// bins are impulses, so their mean pressures carry the impulse exactly. With `watch` (m), when
    /// the deflection first passes it either way and the velocity then (`passedAt`,
    /// `velocityPassing`): where a construction is taken to fail, for what it throws.
    public func response(pressures: [Double], step: Double, tail: Double = 3, watch: Double? = nil)
        -> SDOFResponse
    {
        if let memo = SDOFResponseMemo.active {
            return memo.response(
                SDOFResponseMemo.Key(system: self, pressures: pressures, step: step, tail: tail, watch: watch)
            ) { integrate(pressures: pressures, step: step, tail: tail, watch: watch) }
        }
        return integrate(pressures: pressures, step: step, tail: tail, watch: watch)
    }

    func integrate(pressures: [Double], step: Double, tail: Double, watch: Double?) -> SDOFResponse {
        precondition(step > 0 && tail >= 0)
        let period = period
        // Velocity Verlet is stable below T/π; T/200 keeps the closed-form cases in the tests
        // within 0.1%.
        // A stiffening backbone's steepest segment sets the shortest period it reaches.
        var steepest = stiffness
        if brittle != nil {
            var i = 1
            while i < backbone.count {
                let a = backbone[i - 1]
                let b = backbone[i]
                if b.y > a.y { steepest = larger(steepest, (b.y - a.y) / (b.x - a.x)) }
                i += 1
            }
        }
        let shortest = smaller(period, 2 * .pi * (loadMassElastic * massPerArea / steepest).squareRoot())
        let substeps = max(1, Int((step / (shortest / 200)).rounded(.up)))
        let h = step / Double(substeps)
        let k = stiffness
        let damping = 2 * dampingRatio * (loadMassElastic * massPerArea * k).squareRoot()
        var x = 0.0
        var v = 0.0
        var permanent = 0.0  // R = k (x − permanent) while elastic
        var yielded = false
        var response = SDOFResponse(
            yieldDeflection: backbone[0].x, equivalentElasticDeflection: equivalentElasticDeflection,
            period: period)
        // The backbone read once, for `Self.envelope`, and where its last look inward and outward
        // ended (`interpolate`).
        let backbone = backbone
        let backboneOrdered = Self.isOrdered(backbone)
        var inwardHint = 1
        var outwardHint = 1
        func envelope(_ x: Double, _ hint: inout Int) -> Double {
            if !backboneOrdered { hint = 1 }
            return Self.envelope(backbone, x, hint: &hint)
        }
        func loadMass() -> Double {
            guard yielded else { return loadMassElastic }
            if let span, atan(larger(x.magnitude, response.peakDeflection) / (span / 2)) <= 2 * .pi / 180 {
                return 0.5 * (loadMassElastic + loadMassPlastic)
            }
            return loadMassPlastic
        }
        var broken = false
        var cracked = false  // a laminated pane's glass, still held on its interlayer
        var fatigue = 0.0  // ∫ (σ/S)ⁿ dt so far, s
        // Read once: the loop below takes tens of thousands of steps, and reading the optional
        // struct in each copied (retained) its stress table.
        let isBrittle = brittle != nil
        let brittleStress = brittle?.stress ?? []
        let strength = brittle?.strength ?? 0
        let referenceDuration = brittle?.referenceDuration ?? 0
        let fatigueExponent = brittle?.fatigueExponent
        let stressOrdered = Self.isOrdered(brittleStress)
        var stressHint = 1
        // And the backbone's ends. Below, `larger`, `smaller` and `magnitude` stand for `max`, `min`
        // and `abs`: the same results, but concrete, where the generic ones, unspecialised in a
        // debug build, cost a metadata lookup (and the three-argument `max` an array) each call.
        let yieldDeflection = backbone[0].x
        let last = backbone[backbone.count - 1]
        func resistance(at x: Double) -> Double {
            if isBrittle {
                // Elastic on the backbone both ways until it breaks; a cracked laminated pane on
                // its interlayer's membrane until that tears or pulls out.
                guard !broken else { return 0 }
                if cracked, let membrane { return membrane.resistance(at: x) }
                return x < 0 ? -reboundFactor * envelope(-x, &outwardHint) : envelope(x, &inwardHint)
            }
            var r = k * (x - permanent)
            // Inward, the backbone at the furthest inward deflection yet (so unloading and
            // reloading follow the elastic line back to it); outward, the rebound resistance.
            let reached = larger(larger(x, response.peakDeflection), yieldDeflection)
            let upper = envelope(reached, &inwardHint)
            let outward = larger(larger(-x, -response.reboundDeflection), yieldDeflection)
            let lower = -reboundFactor * smaller(envelope(outward, &outwardHint), upper)
            if r > upper {
                r = upper
                permanent = x - r / k
                yielded = yielded || x > yieldDeflection
            } else if r < lower {
                r = lower
                permanent = x - r / k
                yielded = yielded || -x > yieldDeflection
            }
            return r
        }
        func acceleration(_ p: Double, _ r: Double, _ v: Double) -> Double {
            (p - r - damping * v) / (loadMass() * massPerArea)
        }
        let loaded = pressures.count * substeps
        let total = loaded + Int((tail * period / h).rounded(.up))
        var r = 0.0
        // A while loop, not `for n in 0..<total`: unspecialised in a debug build, the range's
        // iterator cost a fifth of the steps' time.
        var n = 0
        while n < total {
            // Both half-kicks of a substep take its own load, so each bin's impulse goes in whole.
            let p = n < loaded ? pressures[n / substeps] : 0
            v += 0.5 * h * acceleration(p, r, v)
            x += h * v
            r = resistance(at: x)
            v += 0.5 * h * acceleration(p, r, v)
            let time = Double(n + 1) * h
            if x > response.peakDeflection {
                response.peakDeflection = x
                response.peakTime = time
            }
            if x < response.reboundDeflection {
                response.reboundDeflection = x
                response.reboundTime = time
            }
            if let watch, response.passedAt == nil, x.magnitude >= watch {
                response.passedAt = time
                response.velocityPassing = v
            }
            if cracked, !broken, let membrane, membrane.isLost(at: x, velocity: v) {
                broken = true
                response.lostResistanceAt = time
                response.velocityAtLoss = v
                response.deflectionAtLoss = x.magnitude
            }
            if isBrittle, !broken, !cracked {
                if !stressOrdered { stressHint = 1 }
                let sigma = Brittle.stress(brittleStress, at: x, hint: &stressHint)
                response.peakStress = larger(response.peakStress ?? 0, sigma)
                if let n = fatigueExponent {
                    fatigue += h * pow(sigma / strength, n)
                    broken = fatigue >= referenceDuration
                } else {
                    broken = sigma >= strength
                }
                if broken, membrane != nil {
                    // Laminated: the glass cracks; the pane holds on its interlayer.
                    broken = false
                    cracked = true
                    response.crackedAt = time
                    response.stressAtBreak = sigma
                    response.deflectionAtBreak = x.magnitude
                } else if broken {
                    response.lostResistanceAt = time
                    response.velocityAtLoss = v
                    response.stressAtBreak = sigma
                    response.deflectionAtBreak = x.magnitude
                }
            }
            if !cracked, response.lostResistanceAt == nil, last.y == 0, x.magnitude >= last.x {
                response.lostResistanceAt = time
                response.velocityAtLoss = v
                if isBrittle {
                    broken = true
                    response.deflectionAtBreak = x.magnitude
                }
            }
            n += 1
        }
        response.residualDeflection = permanent
        if let brittle, let n = brittle.fatigueExponent {
            response.equivalentStress = brittle.strength * pow(fatigue / brittle.referenceDuration, 1 / n)
        }
        return response
    }
}

/// Peak, rebound and permanent deflection of an SDOF system, with what a damage level is judged by.
/// SDOF responses remembered by system and load while `remembering` runs: the same system under
/// the same load answers alike, so a district's façades under a few distinct loads
/// (`FacadeLoadSurrogate`'s pulses) are integrated once each. Exact: a response is reused only for
/// an equal system, load, step, tail and watch.
public final class SDOFResponseMemo: @unchecked Sendable {
    struct Key: Hashable {
        var system: SDOFSystem
        var pressures: [Double]
        var step: Double
        var tail: Double
        var watch: Double?

        /// From every sixteenth pressure, not all of them: a district's pulses are hundreds of
        /// bins long and looked up millions of times. Equal keys still compare every pressure.
        func hash(into hasher: inout Hasher) {
            hasher.combine(system)
            hasher.combine(pressures.count)
            for i in stride(from: 0, to: pressures.count, by: 16) { hasher.combine(pressures[i]) }
            if let last = pressures.last { hasher.combine(last) }
            hasher.combine(step)
            hasher.combine(tail)
            hasher.combine(watch)
        }
    }

    /// One of the memo's parts, by its keys' hash: its own lock and its own responses. The parts
    /// are classes in a `let` array, so that writing one never touches the array the others are
    /// read through.
    private final class Shard: @unchecked Sendable {
        let lock = NSLock()
        var responses: [Key: SDOFResponse] = [:]
    }

    private static let shardCount = 64
    private let shards = (0..<SDOFResponseMemo.shardCount).map { _ in Shard() }

    public init() {}

    /// Responses integrated, and found remembered.
    public private(set) var misses = 0
    public private(set) var hits = 0

    func response(_ key: Key, _ make: () -> SDOFResponse) -> SDOFResponse {
        let shard = shards[abs(key.hashValue % Self.shardCount)]
        shard.lock.lock()
        if let known = shard.responses[key] {
            shard.lock.unlock()
            Self.countLock.lock()
            hits += 1
            Self.countLock.unlock()
            return known
        }
        shard.lock.unlock()
        let made = make()
        shard.lock.lock()
        shard.responses[key] = made
        shard.lock.unlock()
        Self.countLock.lock()
        misses += 1
        Self.countLock.unlock()
        return made
    }

    private static let countLock = NSLock()
    private static let key = "BombCAD.SDOFResponseMemo"

    /// The memo `remembering` set on this thread, or on the thread that handed this one its work
    /// through `concurrently`; nil elsewhere, so concurrent callers never share one.
    static var active: SDOFResponseMemo? {
        get { Thread.current.threadDictionary[key] as? SDOFResponseMemo }
        set { Thread.current.threadDictionary[key] = newValue }
    }

    /// `body` with every SDOF response it asks for remembered (on this thread, and on the threads
    /// its `concurrently` loops run on); the memo returned with its result.
    /// Within another `remembering` (or `remembering(in:)`), the memo already set is kept: a
    /// response is the same whichever memo holds it.
    public static func remembering<T>(_ body: () throws -> T) rethrows -> (T, SDOFResponseMemo) {
        try remembering(in: active ?? SDOFResponseMemo(), body)
    }

    /// As `remembering`, into `memo`, kept from earlier calls: a district judged again and again
    /// (the charge dragged, emmettl/bombcad-work#34) integrates each system and load once.
    public static func remembering<T>(in memo: SDOFResponseMemo, _ body: () throws -> T) rethrows -> (
        T, SDOFResponseMemo
    ) {
        let before = active
        active = memo
        defer { active = before }
        return (try body(), memo)
    }
}

public struct SDOFResponse: Codable, Hashable, Sendable {
    /// Deflection at the end of the backbone's elastic segment, m.
    public var yieldDeflection: Double
    /// UFC's equivalent elastic deflection X_E, m, which ductility is measured against.
    public var equivalentElasticDeflection: Double
    /// Natural period while elastic, s.
    public var period: Double
    /// Largest inward deflection, m, and when, s.
    public var peakDeflection = 0.0
    public var peakTime = 0.0
    /// Largest outward deflection, as a negative number, m, and when, s (nil if it never went out).
    public var reboundDeflection = 0.0
    public var reboundTime: Double?
    /// When the deflection first passed the deflection watched for, either way, s, and the
    /// velocity then, m/s, inward positive (`SDOFSystem.response(watch:)`).
    public var passedAt: Double?
    public var velocityPassing: Double?
    /// Permanent set at the end, m.
    public var residualDeflection = 0.0
    /// When the deflection, either way, passed the backbone's last point with no resistance left,
    /// if it did.
    public var lostResistanceAt: Double?
    /// Its velocity then, m/s, inward positive.
    public var velocityAtLoss: Double?
    /// A brittle component's largest principal stress reached while whole, Pa, and the stress and
    /// the deflection (m, either way) at which it broke.
    public var peakStress: Double?
    public var stressAtBreak: Double?
    public var deflectionAtBreak: Double?
    /// A brittle component with static fatigue: the stress that, held for its reference duration
    /// (60 s for glass), does what its stress history did while it was whole, Pa
    /// (S (∫ (σ/S)ⁿ dt / t_ref)^(1/n)). For a component that never breaks (its strength set out of
    /// reach), the load's equivalent stress, from which a probability of breaking follows.
    public var equivalentStress: Double?
    /// A laminated pane's: when its glass cracked, s (its interlayer then carries it; it is lost
    /// only when that tears or pulls out, `lostResistanceAt`), and its deflection then, m.
    public var crackedAt: Double?
    public var deflectionAtLoss: Double?

    /// Peak deflection over X_E (UFC §3-14.2).
    public var ductility: Double { peakDeflection / equivalentElasticDeflection }
    /// The same, the larger of the inward and outward deflections: a section with bars in both faces
    /// judged either way alike (UFC 3-340-02 §4-26.2).
    public var ductilityEitherWay: Double {
        max(peakDeflection, -reboundDeflection) / equivalentElasticDeflection
    }

    /// Support rotation of a span loaded symmetrically, θ = atan(x / (L/2)) in degrees (UFC
    /// Table 3-5; PDC-TR 06-08 §3-2).
    public func supportRotationDegrees(span: Double) -> Double {
        atan(max(peakDeflection, 0) / (span / 2)) * 180 / .pi
    }
}

/// `Swift.max(x, y)` and `Swift.min(x, y)` on Doubles, to the bit (NaNs and signed zeros alike):
/// concrete, for `SDOFSystem.integrate`'s steps, where the generic ones are not specialised in a
/// debug build.
@inline(__always) private func larger(_ x: Double, _ y: Double) -> Double { y >= x ? y : x }
@inline(__always) private func smaller(_ x: Double, _ y: Double) -> Double { y < x ? y : x }
