// The view is drawn in two passes. The first ray-traces the analytic ground and rigid blocks,
// shaded by the solver's fields, then rasterises the deformable structure's mesh over them
// with a shared depth buffer. The second ray-marches the blast wave in the air, stopping at
// the depth the first pass recorded. Layouts here must match `SceneRenderer.swift`.

#include <metal_stdlib>
using namespace metal;

struct RenderUniforms {
    float4 eye;        // xyz
    float4 right;      // camera basis, pre-scaled by the field of view
    float4 up;
    float4 forward;
    float4 domain;     // xyz = size in metres, w = cell size
    float4 display;    // x = mode (0 now, 1 peak, 2 impulse), y = scale max, z = decades, w = volume opacity
    float4 counts;     // x = boxes, y = gauges, z = charge marker radius (0 hides it), w = volume scale max
    float4 charge;     // xyz = position
    float4 sun;        // xyz = direction towards the light
    float4 clip;       // x = near plane, y = far plane
    float4 highlightLow;   // xyz = low corner of the box to outline, w = 1 to draw it
    float4 highlightHigh;  // xyz = its high corner
    float4 craters[4];     // xy = centre, z = apparent radius, w = depth
    float4 lips[4];        // x = lip crest's height, y = how far the ejecta reach, z = 1 where there
                           // is a crater, w = the crest's radius
};

// The craters a run left, shaded into the ground rather than built: the ground's slope from each
// crater's profile (as `CraterEstimate.change`: a paraboloid bowl up to the original ground at the
// apparent radius, the lip rising on to its crest, the ejecta beyond thinning as r^-3.86), and how
// far into a crater the point is, 1 at the bottom of the bowl, for darkening it. Returns
// (dz/dx, dz/dy, darkness, earth).
static inline float4 craterRelief(float2 p, constant RenderUniforms &u) {
    float2 slope = float2(0.0f);
    float dark = 0.0f;
    float earth = 0.0f;
    for (int n = 0; n < 4; ++n) {
        if (u.lips[n].z < 0.5f) {
            continue;
        }
        float2 offset = p - u.craters[n].xy;
        float r = length(offset);
        float radius = u.craters[n].z;
        float depth = u.craters[n].w;
        float lip = u.lips[n].x;
        float reach = u.lips[n].y;
        float crest = max(u.lips[n].w, radius * 1.0001f);
        if (r >= reach || radius <= 0.0f) {
            continue;
        }
        float2 along = r > 1e-6f ? offset / r : float2(0.0f);
        float rate;
        if (r < radius) {
            float s = r / radius;
            rate = 2.0f * depth * r / (radius * radius);
            dark = max(dark, 1.0f - s * s);
        } else if (r < crest) {
            float s = (r - radius) / (crest - radius);
            rate = 2.0f * lip * (1.0f - s) / (crest - radius);
        } else {
            float edge = pow(crest / reach, 3.86f);
            rate = -lip * 3.86f * pow(crest / r, 3.86f) / r / (1.0f - edge);
        }
        slope += rate * along;
        earth = max(earth, 1.0f - smoothstep(0.85f * reach, reach, r));
    }
    return float4(slope, dark, earth);
}

// The ground's colour and light where it is cratered, from the relief above; returns how much of
// a crater the point is in, for laying its earth back over the air's paint.
static inline float shadeCrater(float2 p, constant RenderUniforms &u, thread float3 &base, thread float &light) {
    float4 relief = craterRelief(p, u);
    if (relief.w <= 0.0f) {
        return 0.0f;
    }
    float3 normal = normalize(float3(-relief.x, -relief.y, 1.0f));
    float3 earth = float3(0.45f, 0.39f, 0.32f) * (1.0f - 0.35f * relief.z);
    base = mix(base, earth, relief.w);
    light = mix(light, 0.40f + 0.60f * max(dot(normal, u.sun.xyz), 0.0f), relief.w);
    return relief.w;
}

struct MeshUniforms {
    float4 eye;
    float4 right;       // unit camera basis
    float4 up;
    float4 forward;
    float4 projection;  // x, y = focal scales, z = near, w = far
    float4 lattice;     // xyz = origin, w = element size
    float4 dims;        // xyz = lattice cells, w = floats of state per element
    float4 sun;
};

// Matches `StructureNode` in Structure.metal.
struct MeshNode {
    packed_float3 displacement;
    float mass;
    packed_float3 velocity;
    uint flags;
};

struct BoxData {
    float4 low;
    float4 high;
};

struct VertexOut {
    float4 position [[position]];
    float2 ndc;
};

vertex VertexOut fullscreenVertex(uint vertexID [[vertex_id]]) {
    float2 corner = float2((vertexID << 1) & 2, vertexID & 2);
    VertexOut out;
    out.position = float4(corner * 2.0f - 1.0f, 0.0f, 1.0f);
    out.ndc = corner * 2.0f - 1.0f;
    return out;
}

static inline float3 heat(float t) {
    const float3 stops[6] = {
        float3(0.05f, 0.04f, 0.22f), float3(0.30f, 0.07f, 0.50f), float3(0.67f, 0.14f, 0.42f),
        float3(0.92f, 0.33f, 0.16f), float3(0.99f, 0.68f, 0.10f), float3(0.99f, 0.98f, 0.70f),
    };
    float x = clamp(t, 0.0f, 1.0f) * 5.0f;
    int i = min(int(x), 4);
    return mix(stops[i], stops[i + 1], x - float(i));
}

// Maps a value onto [0, 1] logarithmically: `scaleMax` -> 1, `decades` below it -> 0.
static inline float logScale(float value, float scaleMax, float decades) {
    return clamp(1.0f + log10(max(value, 1e-12f) / scaleMax) / decades, 0.0f, 1.0f);
}

static inline bool hitBox(float3 origin, float3 inverseDirection, float3 low, float3 high,
                          thread float &distance, thread float3 &normal) {
    float3 t0 = (low - origin) * inverseDirection;
    float3 t1 = (high - origin) * inverseDirection;
    float3 nearT = min(t0, t1);
    float3 farT = max(t0, t1);
    float enter = max(nearT.x, max(nearT.y, nearT.z));
    float leave = min(farT.x, min(farT.y, farT.z));
    if (enter > leave || enter <= 0.0f) {
        return false;
    }
    distance = enter;
    normal = float3(0.0f);
    if (enter == nearT.x) {
        normal.x = inverseDirection.x > 0.0f ? -1.0f : 1.0f;
    } else if (enter == nearT.y) {
        normal.y = inverseDirection.y > 0.0f ? -1.0f : 1.0f;
    } else {
        normal.z = inverseDirection.z > 0.0f ? -1.0f : 1.0f;
    }
    return true;
}

static inline bool hitSphere(float3 origin, float3 direction, float3 centre, float radius,
                             thread float &distance) {
    float3 offset = origin - centre;
    float b = dot(offset, direction);
    float c = dot(offset, offset) - radius * radius;
    float discriminant = b * b - c;
    if (discriminant < 0.0f) {
        return false;
    }
    float t = -b - sqrt(discriminant);
    if (t <= 0.0f) {
        return false;
    }
    distance = t;
    return true;
}

// The blocks in columns, for scenes of many (a district's map buildings): a grid over their
// footprints, each column listing the blocks over it (`starts` a column's first entry in `items`,
// one more than the columns). A ray walks the columns it crosses, nearest first.
struct BoxGrid {
    float4 frame;   // the grid's south-west corner (x, y), its column width, the blocks' top
    uint4 dims;     // columns along x and y; 1 to walk the grid, 0 to test every block
};

// The nearest block the ray meets (with `first`, the first it meets, for a shadow), testing only the blocks
// over the columns it crosses: a block it meets is over the column where it meets it, so once the
// nearest so far lies before the ray leaves a column, none further can be nearer.
static inline int gridHit(float3 origin, float3 direction, const device BoxData *boxes,
                          constant BoxGrid &g, const device uint *starts, const device uint *items, bool first,
                          thread float &nearest, thread float3 &nearestNormal) {
    float3 inverseDirection = 1.0f / direction;
    float width = g.frame.z;
    int2 columns = int2(g.dims.xy);
    float3 low = float3(g.frame.xy, -1.0e9f);
    float3 high = float3(g.frame.xy + float2(columns) * width, g.frame.w);
    float3 t0 = (low - origin) * inverseDirection;
    float3 t1 = (high - origin) * inverseDirection;
    float3 nearT = min(t0, t1);
    float3 farT = max(t0, t1);
    float enter = max(max(nearT.x, nearT.y), max(nearT.z, 0.0f));
    float leave = min(farT.x, min(farT.y, farT.z));
    if (enter > leave) {
        return -1;
    }
    float2 start = (origin.xy + enter * direction.xy - g.frame.xy) / width;
    int2 cell = clamp(int2(floor(start)), int2(0), columns - 1);
    int2 step = int2(direction.x >= 0.0f ? 1 : -1, direction.y >= 0.0f ? 1 : -1);
    float2 next = (g.frame.xy + float2(cell + max(step, int2(0))) * width - origin.xy) * inverseDirection.xy;
    float2 delta = abs(width * inverseDirection.xy);
    int found = -1;
    for (int walked = 0; walked < 4096; ++walked) {
        uint begin = starts[cell.x + columns.x * cell.y];
        uint end = starts[cell.x + columns.x * cell.y + 1];
        for (uint e = begin; e < end; ++e) {
            uint n = items[e];
            float distance;
            float3 normal;
            if (hitBox(origin, inverseDirection, boxes[n].low.xyz, boxes[n].high.xyz, distance, normal)
                && (distance < nearest || (distance == nearest && int(n) < found))) {
                if (first) {
                    return int(n);
                }
                nearest = distance;
                nearestNormal = normal;
                found = int(n);
            }
        }
        float exit = min(next.x, next.y);
        if (found >= 0 && nearest <= exit) {
            break;
        }
        if (exit > leave) {
            break;
        }
        if (next.x < next.y) {
            cell.x += step.x;
            next.x += delta.x;
        } else {
            cell.y += step.y;
            next.y += delta.y;
        }
        if (any(cell < int2(0)) || any(cell >= columns)) {
            break;
        }
    }
    return found;
}

static inline bool occluded(float3 origin, float3 direction, const device BoxData *boxes, int boxCount,
                            constant BoxGrid &g, const device uint *starts, const device uint *items) {
    float3 inverseDirection = 1.0f / direction;
    if (g.dims.z != 0) {
        float nearest = 1.0e9f;
        float3 normal;
        return gridHit(origin, direction, boxes, g, starts, items, true, nearest, normal) >= 0;
    }
    for (int n = 0; n < boxCount; ++n) {
        float distance;
        float3 normal;
        if (hitBox(origin, inverseDirection, boxes[n].low.xyz, boxes[n].high.xyz, distance, normal)) {
            return true;
        }
    }
    return false;
}

// Colour of a lit surface point, tinted by the field channel the display mode selects.
// The tint is only lightly shaded so that shadows do not distort the data.
static inline float3 fieldTint(float3 base, float light, float4 field, constant RenderUniforms &u) {
    int mode = int(u.display.x);
    float value = mode == 0 ? field.r : (mode == 1 ? field.g : field.b);
    float t = logScale(value, u.display.y, u.display.z);
    float dataLight = 0.78f + 0.22f * light;
    float3 colour = mix(base * light, heat(t) * dataLight, smoothstep(0.0f, 0.12f, t) * 0.92f);
    if (mode == 0 && value < 0.0f) {
        // Negative phase (suction) in blue.
        float suction = logScale(-value, u.display.y * 0.3f, u.display.z);
        colour = mix(colour, float3(0.10f, 0.35f, 0.85f) * dataLight, smoothstep(0.0f, 0.3f, suction) * 0.7f);
    }
    return colour;
}

struct SceneOut {
    float4 colour [[color(0)]];
    float depth [[depth(any)]];
};

// Depth-buffer value of a point at view-space distance `z` along the camera axis.
static inline float depthFromView(float z, float near, float far) {
    return far / (far - near) * (1.0f - near / z);
}

static inline float viewFromDepth(float depth, float near, float far) {
    return near / (1.0f - depth * (far - near) / far);
}

fragment SceneOut sceneFragment(VertexOut in [[stage_in]],
                                constant RenderUniforms &u [[buffer(0)]],
                                const device BoxData *boxes [[buffer(1)]],
                                const device float4 *gauges [[buffer(2)]],
                                constant BoxGrid &boxGrid [[buffer(3)]],
                                const device uint *gridStarts [[buffer(4)]],
                                const device uint *gridItems [[buffer(5)]],
                                texture3d<float> field [[texture(0)]]) {
    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);

    float3 origin = u.eye.xyz;
    float3 direction = normalize(u.forward.xyz + in.ndc.x * u.right.xyz + in.ndc.y * u.up.xyz);
    float3 inverseDirection = 1.0f / direction;
    float3 domain = u.domain.xyz;
    float cellSize = u.domain.w;
    float3 sun = u.sun.xyz;
    int boxCount = int(u.counts.x);
    int gaugeCount = int(u.counts.y);

    // Background sky.
    float3 colour = mix(float3(0.62f, 0.70f, 0.80f), float3(0.22f, 0.36f, 0.62f),
                        clamp(direction.z * 1.6f, 0.0f, 1.0f));
    float nearest = 1.0e9f;

    // Ground plane z = 0.
    if (direction.z < 0.0f) {
        float t = -origin.z / direction.z;
        if (t > 0.0f) {
            nearest = t;
            float3 p = origin + t * direction;
            bool inside = p.x >= 0.0f && p.y >= 0.0f && p.x <= domain.x && p.y <= domain.y;
            float3 base = inside ? float3(0.46f, 0.47f, 0.49f) : float3(0.33f, 0.34f, 0.36f);
            // 10 m grid, antialiased with screen-space derivatives.
            float2 cell = p.xy / 10.0f;
            float2 line = abs(fract(cell - 0.5f) - 0.5f) / max(fwidth(cell), 1e-5f);
            float grid = 1.0f - clamp(min(line.x, line.y), 0.0f, 1.0f);
            base = mix(base, base * 1.3f, grid * (inside ? 0.6f : 0.3f));
            float light = 0.45f + 0.55f * max(sun.z, 0.0f);
            float crater = inside ? shadeCrater(p.xy, u, base, light) : 0.0f;
            if (occluded(p + float3(0.0f, 0.0f, 0.01f), sun, boxes, boxCount, boxGrid, gridStarts, gridItems)) {
                light *= 0.62f;
            }
            colour = base * light;
            if (inside) {
                float3 uvw = float3(p.xy, 0.5f * cellSize) / domain;
                colour = fieldTint(base, light, field.sample(linearSampler, uvw), u);
                // The crater's earth over the paint, so that it reads once the run has left it.
                colour = mix(colour, base * light, 0.7f * crater);
            }
        }
    }

    // Blocks: the nearest, by the grid's columns or among them all.
    int hit = -1;
    float3 normal = float3(0.0f);
    if (boxGrid.dims.z != 0) {
        hit = gridHit(origin, direction, boxes, boxGrid, gridStarts, gridItems, false, nearest, normal);
    } else {
        for (int n = 0; n < boxCount; ++n) {
            float t;
            float3 faceNormal;
            if (hitBox(origin, inverseDirection, boxes[n].low.xyz, boxes[n].high.xyz, t, faceNormal) && t < nearest) {
                nearest = t;
                normal = faceNormal;
                hit = n;
            }
        }
    }
    if (hit >= 0) {
        int n = hit;
        float t = nearest;
        float3 p = origin + t * direction;
        // Sample half a cell inside the wall, where solid cells hold the adjacent air values.
        float3 uvw = (p - normal * 0.5f * cellSize) / domain;
        float diffuse = max(dot(normal, sun), 0.0f);
        if (diffuse > 0.0f && occluded(p + normal * 0.01f, sun, boxes, boxCount, boxGrid, gridStarts, gridItems)) {
            diffuse = 0.0f;
        }
        // Faint storey lines give the blocks a sense of scale.
        float storey = normal.z == 0.0f ? smoothstep(0.42f, 0.5f, abs(fract(p.z / 3.0f) - 0.5f)) : 0.0f;
        float light = (0.50f + 0.50f * diffuse) * (1.0f - 0.10f * storey);
        // An envelope's one-way damage, when judged: none, glass broken alone, then moderate,
        // heavy, hazardous and failed.
        // EnvelopeDamageColour.palette; a test keeps the two the same.
        const float3 damage[6] = {
            float3(0.851f, 0.910f, 0.824f), float3(0.310f, 0.659f, 0.878f), float3(0.949f, 0.871f, 0.227f),
            float3(0.878f, 0.541f, 0.000f), float3(0.702f, 0.227f, 0.039f), float3(0.420f, 0.118f, 0.333f)};
        // An exposure-only building by its walls' construction, a plain block neutral
        // (MaterialAppearance.colour in allCases' order, from code 1; a test keeps the two the same).
        const float3 looks[8] = {
            float3(0.80f, 0.79f, 0.76f), float3(0.30f, 0.36f, 0.46f), float3(0.76f, 0.79f, 0.82f),
            float3(0.55f, 0.74f, 0.74f), float3(0.66f, 0.50f, 0.34f), float3(0.64f, 0.40f, 0.31f),
            float3(0.73f, 0.71f, 0.66f), float3(0.72f, 0.72f, 0.72f)};
        int look = int(boxes[n].high.w + 0.5f);
        float3 base = look >= 1 && look <= 8 ? looks[look - 1] : float3(0.72f, 0.72f, 0.72f);
        // Drawn in its own colour, lit but without the air's paint, which would hide it.
        int code = int(boxes[n].low.w + 0.5f);
        // A building side's glass chance, in eighths, from 16 up: three bits a side, −x, +x, −y,
        // +y; a roof its worst side's (EnvelopeChanceColour; a test keeps the ramps the same).
        const float3 chance[8] = {
            float3(0.992f, 0.906f, 0.145f), float3(0.627f, 0.855f, 0.224f), float3(0.290f, 0.757f, 0.427f),
            float3(0.122f, 0.631f, 0.529f), float3(0.153f, 0.498f, 0.557f), float3(0.212f, 0.361f, 0.553f),
            float3(0.275f, 0.196f, 0.494f), float3(0.267f, 0.005f, 0.329f)};
        if (code >= 16) {
            int sides = code - 16;
            int eighth = 0;
            if (abs(normal.x) > 0.5f) {
                eighth = (sides >> (normal.x > 0.0f ? 3 : 0)) & 7;
            } else if (abs(normal.y) > 0.5f) {
                eighth = (sides >> (normal.y > 0.0f ? 9 : 6)) & 7;
            } else {
                for (int side = 0; side < 4; ++side) { eighth = max(eighth, (sides >> (3 * side)) & 7); }
            }
            colour = chance[eighth] * light;
        } else if (code >= 8 && code <= 10) {
            // Whether finer cells could flip it: settled, in doubt, likely different
            // (EnvelopeDoubtColour; a test keeps the two the same).
            const float3 doubt[3] = {
                float3(0.780f, 0.800f, 0.820f), float3(0.929f, 0.502f, 0.098f), float3(0.533f, 0.200f, 0.600f)};
            colour = doubt[code - 8] * light;
        } else {
            colour = code >= 1 && code <= 6
                ? damage[code - 1] * light
                : fieldTint(base, light, field.sample(linearSampler, uvw), u);
        }
    }

    // Gauge markers and the charge marker.
    for (int n = 0; n < gaugeCount; ++n) {
        float t;
        if (hitSphere(origin, direction, gauges[n].xyz, gauges[n].w, t) && t < nearest) {
            nearest = t;
            float3 normal = normalize(origin + t * direction - gauges[n].xyz);
            colour = float3(0.10f, 0.80f, 0.90f) * (0.55f + 0.45f * max(dot(normal, sun), 0.0f));
        }
    }
    if (u.counts.z > 0.0f) {
        float t;
        if (hitSphere(origin, direction, u.charge.xyz, u.counts.z, t) && t < nearest) {
            nearest = t;
            float3 normal = normalize(origin + t * direction - u.charge.xyz);
            colour = float3(0.95f, 0.15f, 0.10f) * (0.55f + 0.45f * max(dot(normal, sun), 0.0f));
        }
    }

    SceneOut out;
    out.colour = float4(colour, 1.0f);
    out.depth = nearest < 1.0e8f
        ? depthFromView(nearest * dot(direction, u.forward.xyz), u.clip.x, u.clip.y) : 1.0f;
    return out;
}

struct MeshOut {
    float4 position [[position]];
    float3 world;
    float damage [[flat]];
    // The element's material: linear RGB under full light, and in w its highlight's strength
    // (`MaterialAppearance`).
    float4 appearance [[flat]];
};

// Entries in a material palette, as `MaterialAppearance.paletteSize`.
constant uint paletteSize = 16;

// Which shells a draw takes: all of them, all but the glass, or the glass alone.
constant uint drawAll = 0;
constant uint drawOpaque = 1;
constant uint drawGlass = 2;

// Draws the outer faces of the structure's elements, pulled straight from the solver's buffers:
// 36 vertices per element, with hidden and eroded faces collapsed to nothing.
vertex MeshOut structureVertex(uint vertexID [[vertex_id]],
                               uint instanceID [[instance_id]],
                               const device uint *instances [[buffer(0)]],
                               const device MeshNode *nodes [[buffer(1)]],
                               const device uchar *flags [[buffer(2)]],
                               const device float *states [[buffer(3)]],
                               constant MeshUniforms &u [[buffer(4)]],
                               const device uint *nodeMap [[buffer(5)]],
                               const device uchar *materialIndex [[buffer(6)]],
                               constant float4 *palette [[buffer(7)]],
                               constant uint &indexed [[buffer(8)]]) {
    MeshOut out;
    out.position = float4(0.0f, 0.0f, 0.0f, 1.0f);
    out.world = float3(0.0f);
    out.damage = 0.0f;
    // The low four bits are the material; bits 4 to 6 mark mortar joints.
    out.appearance = palette[indexed != 0u ? uint(materialIndex[instanceID] & uchar(15)) : 0u];

    int3 dims = int3(u.dims.xyz);
    int element = int(instances[instanceID]);
    uint flag = flags[element];
    int3 cell = int3(element % dims.x, (element / dims.x) % dims.y, element / (dims.x * dims.y));
    uint face = vertexID / 6;
    uint axis = face >> 1;
    uint side = face & 1u;
    const uint2 quad[6] = {uint2(0, 0), uint2(1, 0), uint2(1, 1), uint2(0, 0), uint2(1, 1), uint2(0, 1)};
    uint2 corner = quad[vertexID % 6];
    int3 offset = int3(0);
    offset[axis] = int(side);
    offset[(axis + 1) % 3] = int(corner.x);
    offset[(axis + 2) % 3] = int(corner.y);
    int nodesX = dims.x + 1;
    int nodesY = dims.y + 1;

    float3 world;
    if (flag == 1) {
        // Intact element: draw only faces that are not shared with another intact element.
        int3 outward = int3(0);
        outward[axis] = side == 0 ? -1 : 1;
        int3 neighbour = cell + outward;
        if (all(neighbour >= 0) && all(neighbour < dims)
            && flags[neighbour.x + dims.x * (neighbour.y + dims.y * neighbour.z)] == 1) {
            return out;
        }
        int3 point = cell + offset;
        MeshNode node = nodes[nodeMap[point.x + nodesX * (point.y + nodesY * point.z)]];
        world = u.lattice.xyz + float3(point) * u.lattice.w + float3(node.displacement);
        out.damage = states[instanceID * uint(u.dims.w) + 7];
    } else if (flag == 2) {
        // Failed element: a small lump of rubble at the middle of its (now free) nodes.
        float3 centre = float3(0.0f);
        for (int a = 0; a < 8; ++a) {
            int3 point = cell + int3(a & 1, (a >> 1) & 1, (a >> 2) & 1);
            MeshNode node = nodes[nodeMap[point.x + nodesX * (point.y + nodesY * point.z)]];
            centre += 0.125f * (u.lattice.xyz + float3(point) * u.lattice.w + float3(node.displacement));
        }
        world = centre + (float3(offset) - 0.5f) * (0.6f * u.lattice.w);
        out.damage = 2.0f;
    } else {
        return out;
    }

    float3 relative = world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    out.world = world;
    return out;
}

// Matches `ShellNode` and `ShellElement` in Shell.metal.
struct ShellMeshNode {
    packed_float3 displacement;
    float mass;
    packed_float3 velocity;
    uint flags;
    packed_float3 spin;
    float inertia;
    float4 rotation;
};

struct ShellMeshElement {
    uint node[4];
    uint axis;
    uint material;
    uint barCount;
    float thickness;
    float a;
    float b;
    int shield[2];
    uint pane;
};

// Draws each shell as the slab it stands for: a box between its two faces, which lie half its
// thickness either side of the midsurface along the directors. A failed shell becomes a small
// lump of rubble at the middle of its nodes.
vertex MeshOut shellVertex(uint vertexID [[vertex_id]],
                           uint instanceID [[instance_id]],
                           const device ShellMeshElement *elements [[buffer(0)]],
                           const device ShellMeshNode *nodes [[buffer(1)]],
                           const device uchar *flags [[buffer(2)]],
                           const device float *damage [[buffer(3)]],
                           constant MeshUniforms &u [[buffer(4)]],
                           const device float4 *reference [[buffer(5)]],
                           constant uint &transparentMaterials [[buffer(6)]],
                           constant uint &draw [[buffer(7)]],
                           constant float4 *palette [[buffer(8)]]) {
    MeshOut out;
    out.position = float4(0.0f, 0.0f, 0.0f, 1.0f);
    out.world = float3(0.0f);
    out.damage = 0.0f;
    out.appearance = float4(0.0f);
    uint flag = flags[instanceID];
    if (flag == 0) {
        return out;
    }
    ShellMeshElement el = elements[instanceID];
    out.appearance = palette[min(el.material, paletteSize - 1u)];
    // Steel thinner than a few millimetres is profiled cladding, lighter as galvanised sheet reads
    // (`MaterialAppearance.sheeting`, `sheetingThickness`).
    if (out.appearance.w > 0.2f && el.thickness < 0.004f) {
        out.appearance = float4(0.76f, 0.79f, 0.82f, 0.30f);
    }
    bool glass = ((transparentMaterials >> min(el.material, 31u)) & 1u) != 0u;
    if ((draw == drawOpaque && glass) || (draw == drawGlass && !glass)) {
        return out;
    }
    // A pane is a sheet: blended, its thin sides and its second face would stack up into
    // grid lines and moiré between neighbouring elements, so only its first face is drawn.
    if (draw == drawGlass && (flag == 1 || flag == 3) && vertexID >= 6) {
        return out;
    }
    float3 normal = float3(0.0f);
    if (el.axis == 3u) {
        // At a pitch: square to its first and second edges, from its reference corners.
        float3 origin = reference[el.node[0]].xyz;
        normal = normalize(cross(reference[el.node[1]].xyz - origin, reference[el.node[3]].xyz - origin));
    } else {
        normal[el.axis] = 1.0f;
    }
    // Box corners: the four nodes on the lower face, then on the upper.
    const uint faces[6][4] = {{0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {1, 2, 6, 5}, {2, 3, 7, 6}, {3, 0, 4, 7}};
    const uint triangle[6] = {0, 1, 2, 0, 2, 3};
    uint corner = faces[vertexID / 6][triangle[vertexID % 6]];
    uint c = corner & 3u;
    float side = corner < 4 ? -1.0f : 1.0f;
    float3 world;
    if (flag == 1 || flag == 3) {
        ShellMeshNode node = nodes[el.node[c]];
        float4 q = node.rotation;
        float3 t = 2.0f * cross(q.xyz, normal);
        float3 director = normal + q.w * t + cross(q.xyz, t);
        world = reference[el.node[c]].xyz + float3(node.displacement) + side * 0.5f * el.thickness * director;
        out.damage = damage[instanceID];
    } else {
        float3 centre = float3(0.0f);
        for (uint n = 0; n < 4; ++n) {
            centre += 0.25f * (reference[el.node[n]].xyz + float3(nodes[el.node[n]].displacement));
        }
        float size = 0.3f * min(min(el.a, el.b), max(el.thickness, 0.05f) * 2.0f);
        float3 offset = float3((c == 1 || c == 2) ? 0.5f : -0.5f, c >= 2 ? 0.5f : -0.5f, 0.5f * side);
        world = centre + offset * size;
        out.damage = 2.0f;
    }
    float3 relative = world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    out.world = world;
    return out;
}

// Matches `BeamElement` in Shell.metal.
struct BeamMeshElement {
    uint node[2];
    uint axis;
    uint material;
    float width;
    float depth;
    float length;
    uint barCount;
    float tieRatio;
    float padding0;
    float padding1;
};

// Draws each beam as the bar it stands for: a box around its centreline, its section carried by
// the rotated section axes at each end.
vertex MeshOut beamVertex(uint vertexID [[vertex_id]],
                          uint instanceID [[instance_id]],
                          const device BeamMeshElement *beams [[buffer(0)]],
                          const device ShellMeshNode *nodes [[buffer(1)]],
                          const device uchar *flags [[buffer(2)]],
                          const device float *damage [[buffer(3)]],
                          constant MeshUniforms &u [[buffer(4)]],
                          const device float4 *reference [[buffer(5)]],
                          constant float4 *palette [[buffer(8)]]) {
    MeshOut out;
    out.position = float4(0.0f, 0.0f, 0.0f, 1.0f);
    out.world = float3(0.0f);
    out.damage = 0.0f;
    out.appearance = float4(0.0f);
    uint flag = flags[instanceID];
    if (flag != 1 && flag != 3) {
        return out;
    }
    BeamMeshElement beam = beams[instanceID];
    out.appearance = palette[min(beam.material, paletteSize - 1u)];
    float3 e2 = float3(0.0f);
    float3 e3 = float3(0.0f);
    e2[(beam.axis + 1) % 3] = 1.0f;
    e3[(beam.axis + 2) % 3] = 1.0f;
    // Box corners: bit 0 picks the end, bits 1 and 2 the side of the section.
    const uint faces[6][4] = {{0, 2, 6, 4}, {1, 3, 7, 5}, {0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}};
    const uint triangle[6] = {0, 1, 2, 0, 2, 3};
    uint corner = faces[vertexID / 6][triangle[vertexID % 6]];
    uint end = corner & 1u;
    ShellMeshNode node = nodes[beam.node[end]];
    float4 q = node.rotation;
    float3 t2 = 2.0f * cross(q.xyz, e2);
    float3 t3 = 2.0f * cross(q.xyz, e3);
    float3 d2 = e2 + q.w * t2 + cross(q.xyz, t2);
    float3 d3 = e3 + q.w * t3 + cross(q.xyz, t3);
    float s2 = (corner & 2u) != 0 ? 0.5f : -0.5f;
    float s3 = (corner & 4u) != 0 ? 0.5f : -0.5f;
    float3 world = reference[beam.node[end]].xyz + float3(node.displacement) + s2 * beam.width * d2
        + s3 * beam.depth * d3;
    out.damage = damage[instanceID];
    float3 relative = world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    out.world = world;
    return out;
}

struct DotOut {
    float4 position [[position]];
    float2 corner;
    float3 colour [[flat]];
};

// Draws fragments, tracers, landings and ground points as round dots of a fixed size on screen,
// depth-tested at their centres. Each is a position and a code: the kind (0 a fragment in flight,
// 1 a tracer, 2 a landing, 3 a ground point) plus a value from 0 to 1, a fragment's speed, a
// landing's energy or how fast the ground under a point has moved (0 before the blast arrives).
vertex DotOut dotVertex(uint vertexID [[vertex_id]],
                        uint instanceID [[instance_id]],
                        const device float4 *dots [[buffer(0)]],
                        constant MeshUniforms &u [[buffer(1)]],
                        constant float4 &viewport [[buffer(2)]]) {
    float4 p = dots[instanceID];
    float kind = floor(p.w);
    float value = p.w - kind;
    float3 relative = p.xyz - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    float4 clip = float4(view.x * u.projection.x, view.y * u.projection.y,
                         far / (far - near) * (view.z - near), view.z);
    const float2 corners[6] = {float2(-1, -1), float2(1, -1), float2(1, 1),
                               float2(-1, -1), float2(1, 1), float2(-1, 1)};
    float2 corner = corners[vertexID];
    float size = viewport.z * (kind > 3.5f ? 1.6f : (kind > 2.5f ? 1.15f : (kind > 1.5f ? 1.3f : (kind > 0.5f ? 0.7f : 1.0f))));
    clip.xy += corner * size / viewport.xy * clip.w;

    DotOut out;
    out.position = clip;
    out.corner = corner;
    if (kind > 3.5f) {
        // A fragment's strike on a judged target: grey where it stopped, amber where it spalled
        // the far face, crimson where it went through.
        out.colour = value < 0.33f ? float3(0.62f, 0.64f, 0.68f)
            : value < 0.67f ? float3(0.98f, 0.66f, 0.12f) : float3(0.86f, 0.08f, 0.32f);
    } else if (kind > 2.5f) {
        // A ground point: grey until the blast arrives, then from blue at a millimetre a second,
        // through violet, to near white at ten metres a second.
        out.colour = value < 0.0005f ? float3(0.55f, 0.55f, 0.58f)
            : value < 0.5f ? mix(float3(0.2f, 0.45f, 0.95f), float3(0.8f, 0.25f, 0.85f), value * 2.0f)
                           : mix(float3(0.8f, 0.25f, 0.85f), float3(1.0f, 0.9f, 0.95f), value * 2.0f - 1.0f);
    } else if (kind > 1.5f) {
        // A landing: yellow at a joule, through orange, to dark red at ten megajoules.
        out.colour = value < 0.5f ? mix(float3(0.98f, 0.85f, 0.2f), float3(0.95f, 0.4f, 0.1f), value * 2.0f)
                                  : mix(float3(0.95f, 0.4f, 0.1f), float3(0.45f, 0.03f, 0.05f), value * 2.0f - 1.0f);
    } else if (kind > 0.5f) {
        out.colour = float3(0.3f, 0.85f, 1.0f);
    } else {
        // A fragment in flight: dark when slow, white-hot at its launch speed.
        out.colour = mix(float3(0.12f, 0.12f, 0.14f), float3(1.0f, 0.95f, 0.8f), value);
    }
    return out;
}

fragment float4 dotFragment(DotOut in [[stage_in]]) {
    float r2 = dot(in.corner, in.corner);
    if (r2 > 1.0f) {
        discard_fragment();
    }
    // Lit as a ball from the upper left, with a dark rim to stand out against any background.
    float shade = 0.75f + 0.25f * (1.0f - r2) - 0.15f * (in.corner.x - in.corner.y) * 0.5f;
    float rim = smoothstep(0.7f, 1.0f, r2);
    return float4(mix(in.colour * shade, float3(0.05f), rim * 0.6f), 1.0f);
}

// The thermal radiation painted onto a surface: a rectangle of the ground or a face, lifted off it
// and drawn over it, its values interpolated between its cells' centres. Each patch is four
// vectors: a corner and its columns, the edge along the columns and the rows, the edge along the
// rows and where its values start, and the normal and whether it is on the ground.
struct PaintOut {
    float4 position [[position]];
    float2 uv;
    uint patch [[flat]];
};

// The thermal radiation's colour scale, from dark red through orange to pale yellow, as metal
// glows hotter. Matches `ThermalLegendView` in ContentView.swift.
static inline float3 glow(float t) {
    const float3 stops[5] = {
        float3(0.30f, 0.04f, 0.07f), float3(0.62f, 0.08f, 0.06f), float3(0.91f, 0.32f, 0.07f),
        float3(0.99f, 0.67f, 0.17f), float3(1.00f, 0.96f, 0.78f),
    };
    float x = clamp(t, 0.0f, 1.0f) * 4.0f;
    int i = min(int(x), 3);
    return mix(stops[i], stops[i + 1], x - float(i));
}

// A patch's value at `uv` across it: bilinear between its cells' centres, constant beyond the
// outermost.
static float paintValue(const device float4 *patch, const device float *values, float2 uv) {
    int columns = int(patch[0].w);
    int rows = int(patch[1].w);
    int first = int(patch[2].w);
    float2 cell = clamp(uv * float2(columns, rows) - 0.5f, float2(0.0f), float2(columns - 1, rows - 1));
    int2 low = int2(floor(cell));
    int2 high = min(low + 1, int2(columns - 1, rows - 1));
    float2 f = cell - float2(low);
    float bottom = mix(values[first + low.y * columns + low.x], values[first + low.y * columns + high.x], f.x);
    float top = mix(values[first + high.y * columns + low.x], values[first + high.y * columns + high.x], f.x);
    return mix(bottom, top, f.y);
}

vertex PaintOut paintVertex(uint vertexID [[vertex_id]],
                            uint instanceID [[instance_id]],
                            const device float4 *patches [[buffer(0)]],
                            constant MeshUniforms &u [[buffer(1)]]) {
    const float2 corners[6] = {float2(0, 0), float2(1, 0), float2(1, 1),
                               float2(0, 0), float2(1, 1), float2(0, 1)};
    const device float4 *patch = patches + 4 * instanceID;
    // A centimetre past each edge, so that the faces lifted off a block's corner overlap there
    // rather than leave a sliver between them.
    float2 margin = 0.01f / float2(length(patch[1].xyz), length(patch[2].xyz));
    float2 corner = corners[vertexID] * (1.0f + 2.0f * margin) - margin;
    float3 world = patch[0].xyz + corner.x * patch[1].xyz + corner.y * patch[2].xyz + 0.005f * patch[3].xyz;
    // Drawn a thousandth of the way nearer the eye than the surface it lies on, along the line of
    // sight, so that it covers that surface at any distance without moving on the screen.
    world += 0.001f * (u.eye.xyz - world);
    float3 relative = world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    PaintOut out;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    // A face turned away from the eye is hidden by its own block, but for its margin; the ground's
    // patch is left to a terrain that wears it (`dims.x` 1).
    if (dot(patch[3].xyz, u.eye.xyz - patch[0].xyz) <= 0.0f || (u.dims.x > 0.5f && patch[3].w > 0.5f)) {
        out.position = float4(0.0f, 0.0f, 2.0f, 1.0f);
    }
    out.uv = corner;
    out.patch = instanceID;
    return out;
}

fragment float4 paintFragment(PaintOut in [[stage_in]],
                              const device float4 *patches [[buffer(0)]],
                              const device float *values [[buffer(1)]],
                              constant MeshUniforms &u [[buffer(2)]]) {
    const device float4 *patch = patches + 4 * in.patch;
    float t = paintValue(patch, values, in.uv);

    // Shaded as the surface beneath is, without its shadows, and tinted as `fieldTint` tints it.
    float3 normal = patch[3].xyz;
    bool ground = patch[3].w > 0.5f;
    float light = ground ? 0.45f + 0.55f * max(u.sun.z, 0.0f) : 0.50f + 0.50f * max(dot(normal, u.sun.xyz), 0.0f);
    float3 base = ground ? float3(0.46f, 0.47f, 0.49f) : float3(0.80f, 0.79f, 0.76f);
    float dataLight = 0.78f + 0.22f * light;
    return float4(mix(base * light, glow(t) * dataLight, smoothstep(0.0f, 0.12f, t) * 0.92f), 1.0f);
}

// Lines of a fixed width on screen, depth-tested along their length: where the fireball's cloud
// went. Each is two vectors, one end and its kind (0 the centre's track, 1 an outline along it,
// 2 the cloud where it stopped rising, 3 its track across the ground; 5 to 9 the hazards'; 10 a
// building the solver refined), and the other end.
struct LineOut {
    float4 position [[position]];
    float across;
    float3 colour [[flat]];
    float edge [[flat]];
};

static inline float4 projectPoint(float3 p, constant MeshUniforms &u) {
    float near = u.projection.z;
    float far = u.projection.w;
    float3 relative = p - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    return float4(view.x * u.projection.x, view.y * u.projection.y, far / (far - near) * (view.z - near), view.z);
}

vertex LineOut lineVertex(uint vertexID [[vertex_id]],
                          uint instanceID [[instance_id]],
                          const device float4 *lines [[buffer(0)]],
                          constant MeshUniforms &u [[buffer(1)]],
                          constant float4 &viewport [[buffer(2)]]) {
    float4 a = lines[2 * instanceID];
    float3 b = lines[2 * instanceID + 1].xyz;
    int kind = int(a.w + 0.5f);
    float near = u.projection.z;
    float4 ca = projectPoint(a.xyz, u);
    float4 cb = projectPoint(b, u);
    LineOut out;
    // Drawn only where both ends are in front of the eye.
    if (ca.w < near || cb.w < near) {
        out.position = float4(0.0f, 0.0f, 2.0f, 1.0f);
        return out;
    }
    float2 pixels = viewport.xy * 0.5f;
    float2 along = cb.xy / cb.w * pixels - ca.xy / ca.w * pixels;
    float2 direction = length(along) > 1e-4f ? normalize(along) : float2(1.0f, 0.0f);
    float2 normal = float2(-direction.y, direction.x);
    // Each end of the quad, and which side of the line.
    const float2 corners[6] = {float2(0, -1), float2(1, -1), float2(1, 1),
                               float2(0, -1), float2(1, 1), float2(0, 1)};
    float2 corner = corners[vertexID];
    const float widths[11] = {3.0f, 1.6f, 3.0f, 1.6f, 1.6f, 3.0f, 2.0f, 2.0f, 2.2f, 2.6f, 2.4f};
    // Half the width in pixels, and half a pixel more to smooth its edge.
    float halfWidth = 0.5f * widths[kind] * viewport.z + 0.5f;
    float4 clip = corner.x > 0.5f ? cb : ca;
    clip.xy += corner.y * normal * halfWidth / pixels * clip.w;
    out.position = clip;
    out.across = corner.y * halfWidth;
    out.edge = halfWidth;
    const float3 colours[11] = {float3(0.97f, 0.97f, 0.95f), float3(0.92f, 0.93f, 0.95f),
                                float3(1.00f, 0.62f, 0.12f), float3(0.16f, 0.18f, 0.22f),
                                float3(0.36f, 0.80f, 0.86f), float3(0.86f, 0.10f, 0.24f),
                                float3(1.00f, 0.42f, 0.52f), float3(0.35f, 0.55f, 1.00f),
                                float3(1.00f, 0.78f, 0.20f), float3(0.62f, 0.05f, 0.10f),
                                float3(0.30f, 0.95f, 0.50f)};
    out.colour = colours[kind];
    return out;
}

fragment float4 lineFragment(LineOut in [[stage_in]]) {
    // A dark rim a pixel wide, so that light lines stand out against the sky.
    float distance = fabs(in.across);
    if (distance > in.edge) {
        discard_fragment();
    }
    float rim = smoothstep(in.edge - 1.5f, in.edge - 0.5f, distance);
    return float4(mix(in.colour, float3(0.08f, 0.09f, 0.11f), rim * 0.7f), 1.0f);
}

// Matches `TerrainMesh` in `SceneRenderer.swift`.
struct TerrainMesh {
    float4 grid;   // xy = first node, z = spacing, w = lift off the surface
    uint4 dims;    // x = columns, y = rows, z = 1 to tint by the blast's field, w = 1 + the
                   // ground's paint patch to wear, 0 for none
};

struct TerrainOut {
    float4 position [[position]];
    float3 world;
    float3 normal;
};

// The terrain as a mesh of its nodes, two triangles a cell of them, pulled from its heights.
vertex TerrainOut terrainVertex(uint vertexID [[vertex_id]],
                                uint instanceID [[instance_id]],
                                const device float *heights [[buffer(0)]],
                                constant TerrainMesh &t [[buffer(1)]],
                                constant MeshUniforms &u [[buffer(2)]]) {
    int columns = int(t.dims.x);
    int rows = int(t.dims.y);
    int2 cell = int2(int(instanceID) % (columns - 1), int(instanceID) / (columns - 1));
    const int2 quad[6] = {int2(0, 0), int2(1, 0), int2(1, 1), int2(0, 0), int2(1, 1), int2(0, 1)};
    int2 node = cell + quad[vertexID];
    float spacing = t.grid.z;
    float h = heights[node.x + columns * node.y];
    // The normal from the neighbouring nodes' heights.
    int2 west = max(node - int2(1, 0), int2(0));
    int2 east = min(node + int2(1, 0), int2(columns - 1, rows - 1));
    int2 south = max(node - int2(0, 1), int2(0));
    int2 north = min(node + int2(0, 1), int2(columns - 1, rows - 1));
    float dx = (heights[east.x + columns * east.y] - heights[west.x + columns * west.y]) / (float(east.x - west.x) * spacing);
    float dy = (heights[north.x + columns * north.y] - heights[south.x + columns * south.y]) / (float(north.y - south.y) * spacing);
    TerrainOut out;
    out.world = float3(t.grid.xy + float2(node) * spacing, h + t.grid.w);
    out.normal = normalize(float3(-dx, -dy, 1.0f));
    float3 relative = out.world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    return out;
}

// Shaded as the ground is, lit along its own normal, and tinted by the blast's field in the air
// half a cell above it, inside the domain; or painted, as the ground's patch is painted, with the
// thermal radiation of the ground's receivers, which lie on the terrain.
fragment float4 terrainFragment(TerrainOut in [[stage_in]],
                                constant RenderUniforms &u [[buffer(0)]],
                                constant TerrainMesh &t [[buffer(1)]],
                                const device float4 *patches [[buffer(2)]],
                                const device float *values [[buffer(3)]],
                                texture3d<float> field [[texture(0)]]) {
    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);
    float3 domain = u.domain.xyz;
    float3 p = in.world;
    bool inside = p.x >= 0.0f && p.y >= 0.0f && p.x <= domain.x && p.y <= domain.y;
    // Earth: a restrained brown, under the blast's field and the paint.
    float3 base = inside ? float3(0.53f, 0.47f, 0.38f) : float3(0.38f, 0.34f, 0.28f);
    // 10 m contour lines, antialiased with screen-space derivatives.
    float level = p.z / 10.0f;
    float line = abs(fract(level - 0.5f) - 0.5f) / max(fwidth(level), 1e-5f);
    base = mix(base, base * 0.75f, (1.0f - clamp(line, 0.0f, 1.0f)) * 0.5f);
    float3 normal = normalize(in.normal);
    float light = 0.45f + 0.55f * max(dot(normal, u.sun.xyz), 0.0f);
    float crater = inside ? shadeCrater(p.xy, u, base, light) : 0.0f;
    float3 colour = base * light;
    if (inside && t.dims.z != 0) {
        float3 uvw = (p + float3(0.0f, 0.0f, 0.5f * u.domain.w)) / domain;
        colour = mix(fieldTint(base, light, field.sample(linearSampler, uvw), u), base * light, 0.7f * crater);
    }
    if (inside && t.dims.w != 0) {
        const device float4 *patch = patches + 4 * (t.dims.w - 1);
        // Where the point lies across the ground's patch, seen from above.
        float2 offset = p.xy - patch[0].xy;
        float2 uv = float2(dot(offset, patch[1].xy) / dot(patch[1].xy, patch[1].xy),
                           dot(offset, patch[2].xy) / dot(patch[2].xy, patch[2].xy));
        float value = paintValue(patch, values, uv);
        float dataLight = 0.78f + 0.22f * light;
        colour = mix(base * light, glow(value) * dataLight, smoothstep(0.0f, 0.12f, value) * 0.92f);
    }
    return float4(colour, 1.0f);
}

fragment float4 structureFragment(MeshOut in [[stage_in]], constant MeshUniforms &u [[buffer(0)]]) {
    float3 normal = normalize(cross(dfdx(in.world), dfdy(in.world)));
    if (dot(normal, u.eye.xyz - in.world) < 0.0f) {
        normal = -normal;
    }
    float light = 0.50f + 0.50f * max(dot(normal, u.sun.xyz), 0.0f);
    float dataLight = 0.78f + 0.22f * light;

    // The material's own colour, with steel's highlight of the sun; shading through amber to dark
    // red as plastic strain approaches failure (`MaterialAppearance.damage`), the same over every
    // material.
    float3 base = in.appearance.rgb;
    float3 view = normalize(u.eye.xyz - in.world);
    float highlight = in.appearance.w * pow(saturate(dot(reflect(-view, normal), u.sun.xyz)), 24.0f);
    float damage = clamp(in.damage, 0.0f, 1.0f);
    float3 tint = damage < 0.5f
        ? mix(float3(0.98f, 0.82f, 0.25f), float3(0.93f, 0.42f, 0.12f), damage * 2.0f)
        : mix(float3(0.93f, 0.42f, 0.12f), float3(0.55f, 0.06f, 0.08f), damage * 2.0f - 1.0f);
    float3 colour = mix(base * light + highlight, tint * dataLight, smoothstep(0.0f, 0.08f, damage));
    if (in.damage > 1.5f) {
        // Rubble: a dark grey at a fifth of the material's luminance (`MaterialAppearance.rubble`).
        colour = float3(0.20f * dot(base, float3(0.2126f, 0.7152f, 0.0722f))) * light;
    }
    return float4(colour, 1.0f);
}

// Freestanding objects (rigid boxes and cars): one oriented box per instance, `centre.w` 1 for a
// car's shell, 0 for a box, `rotation` a unit quaternion (x, y, z, w) from body to world axes.
struct OrientedBox {
    float4 centre;
    float4 rotation;
    float4 halfSize;
};

static inline float3 rotate(float4 q, float3 v) {
    float3 t = 2.0f * cross(q.xyz, v);
    return v + q.w * t + cross(q.xyz, t);
}

vertex MeshOut freestandingVertex(uint vertexID [[vertex_id]],
                                  uint instanceID [[instance_id]],
                                  const device OrientedBox *boxes [[buffer(0)]],
                                  constant MeshUniforms &u [[buffer(1)]]) {
    OrientedBox box = boxes[instanceID];
    uint face = vertexID / 6;
    uint axis = face >> 1;
    const uint2 quad[6] = {uint2(0, 0), uint2(1, 0), uint2(1, 1), uint2(0, 0), uint2(1, 1), uint2(0, 1)};
    uint2 corner = quad[vertexID % 6];
    float3 local = float3(0.0f);
    local[axis] = (face & 1u) == 0 ? -1.0f : 1.0f;
    local[(axis + 1) % 3] = corner.x == 0 ? -1.0f : 1.0f;
    local[(axis + 2) % 3] = corner.y == 0 ? -1.0f : 1.0f;
    float3 world = box.centre.xyz + rotate(box.rotation, local * box.halfSize.xyz);
    float3 relative = world - u.eye.xyz;
    float3 view = float3(dot(relative, u.right.xyz), dot(relative, u.up.xyz), dot(relative, u.forward.xyz));
    float near = u.projection.z;
    float far = u.projection.w;
    MeshOut out;
    out.position = float4(view.x * u.projection.x, view.y * u.projection.y,
                          far / (far - near) * (view.z - near), view.z);
    out.world = world;
    out.damage = box.centre.w;
    out.appearance = float4(0.0f);
    return out;
}

// Cars in a muted blue, boxes in tan, lit like the structure.
fragment float4 freestandingFragment(MeshOut in [[stage_in]], constant MeshUniforms &u [[buffer(0)]]) {
    float3 normal = normalize(cross(dfdx(in.world), dfdy(in.world)));
    if (dot(normal, u.eye.xyz - in.world) < 0.0f) {
        normal = -normal;
    }
    float light = 0.50f + 0.50f * max(dot(normal, u.sun.xyz), 0.0f);
    float3 colour = in.damage > 0.5f ? float3(0.30f, 0.45f, 0.70f) : float3(0.78f, 0.66f, 0.46f);
    return float4(colour * light, 1.0f);
}

// Glass, drawn after everything opaque and blended over it without writing depth. Clear float
// glass is a faint green-blue; it reflects the sky more as the view grazes it (Schlick's
// approximation to the Fresnel term, with 4% reflected head-on) and shows a sharp highlight
// of the sun. Cracking turns it milky and opaque, so damage still reads, and its shards are
// pale, glinting chips.
fragment float4 glassFragment(MeshOut in [[stage_in]], constant MeshUniforms &u [[buffer(0)]]) {
    float3 normal = normalize(cross(dfdx(in.world), dfdy(in.world)));
    float3 view = normalize(u.eye.xyz - in.world);
    if (dot(normal, view) < 0.0f) {
        normal = -normal;
    }
    float facing = saturate(dot(normal, view));
    float fresnel = 0.04f + 0.96f * pow(1.0f - facing, 5.0f);
    float3 reflected = reflect(-view, normal);
    float3 sky = mix(float3(0.36f, 0.37f, 0.38f), mix(float3(0.78f, 0.84f, 0.90f), float3(0.40f, 0.55f, 0.80f),
                                                      saturate(reflected.z)),
                     smoothstep(-0.15f, 0.15f, reflected.z));
    float glint = pow(saturate(dot(reflected, u.sun.xyz)), 300.0f);
    float3 tint = float3(0.55f, 0.74f, 0.74f);

    if (in.damage > 1.5f) {
        float light = 0.6f + 0.4f * saturate(dot(normal, u.sun.xyz));
        float3 colour = mix(float3(0.70f, 0.84f, 0.86f) * light, sky, 0.35f) + 4.0f * glint;
        return float4(colour, 0.85f);
    }
    float3 colour = mix(tint * 0.5f, sky, fresnel) + 3.0f * glint;
    float alpha = 0.16f + 0.75f * fresnel + glint;
    // Cracked: frosted white, from a hairline to fully crazed as the damage index rises.
    float crazed = smoothstep(0.02f, 0.6f, saturate(in.damage));
    float light = 0.65f + 0.35f * saturate(dot(normal, u.sun.xyz));
    colour = mix(colour, float3(0.90f, 0.93f, 0.94f) * light, crazed);
    alpha = mix(alpha, 0.85f, crazed);
    return float4(colour, saturate(alpha));
}

// Second pass: lays the blast wave over the finished scene.
fragment float4 compositeFragment(VertexOut in [[stage_in]],
                                  constant RenderUniforms &u [[buffer(0)]],
                                  texture2d<float> sceneColour [[texture(0)]],
                                  depth2d<float> sceneDepth [[texture(1)]],
                                  texture3d<float> field [[texture(2)]]) {
    constexpr sampler linearSampler(filter::linear, address::clamp_to_edge);
    uint2 pixel = uint2(in.position.xy);
    float3 colour = sceneColour.read(pixel).rgb;
    float depth = sceneDepth.read(pixel);

    float3 origin = u.eye.xyz;
    float3 direction = normalize(u.forward.xyz + in.ndc.x * u.right.xyz + in.ndc.y * u.up.xyz);
    float3 inverseDirection = 1.0f / direction;
    float3 domain = u.domain.xyz;
    float nearest = depth < 1.0f
        ? viewFromDepth(depth, u.clip.x, u.clip.y) / dot(direction, u.forward.xyz) : 1.0e9f;

    // Outline of the box being edited, drawn over whatever surface it coincides with.
    if (u.highlightLow.w > 0.0f) {
        float t;
        float3 normal;
        float3 low = u.highlightLow.xyz - 0.03f;
        float3 high = u.highlightHigh.xyz + 0.03f;
        if (hitBox(origin, inverseDirection, low, high, t, normal) && t < nearest + 0.25f) {
            float3 p = origin + t * direction;
            float3 inset = min(p - low, high - p);
            float edge = fabs(normal.x) > 0.5f ? min(inset.y, inset.z)
                : (fabs(normal.y) > 0.5f ? min(inset.x, inset.z) : min(inset.x, inset.y));
            float thickness = 0.004f * t;  // a few pixels at any distance
            float line = 1.0f - smoothstep(thickness, 2.0f * thickness, edge);
            colour = mix(colour, float3(0.10f, 0.85f, 1.0f), max(line, 0.22f));
        }
    }

    // Blast wave: march the shock indicator between the domain bounds and the first surface.
    float opacity = u.display.w;
    if (opacity > 0.0f) {
        float3 t0 = (float3(0.0f) - origin) * inverseDirection;
        float3 t1 = (domain - origin) * inverseDirection;
        float3 nearT = min(t0, t1);
        float3 farT = max(t0, t1);
        float enter = max(max(nearT.x, max(nearT.y, nearT.z)), 0.0f);
        float leave = min(min(farT.x, min(farT.y, farT.z)), nearest);
        if (leave > enter) {
            const int steps = 192;
            float stepLength = (leave - enter) / float(steps);
            float jitter = fract(sin(dot(in.position.xy, float2(12.9898f, 78.233f))) * 43758.5453f);
            float3 accumulated = float3(0.0f);
            float transmittance = 1.0f;
            float3 inverseDomain = 1.0f / domain;
            for (int s = 0; s < steps; ++s) {
                float3 p = origin + (enter + (float(s) + jitter) * stepLength) * direction;
                float t = logScale(field.sample(linearSampler, p * inverseDomain).a, u.counts.w, u.display.z);
                float alpha = 1.0f - exp(-t * t * t * opacity * stepLength);
                accumulated += transmittance * alpha * heat(0.25f + 0.75f * t);
                transmittance *= 1.0f - alpha;
                if (transmittance < 0.02f) {
                    break;
                }
            }
            colour = colour * transmittance + accumulated;
        }
    }

    return float4(colour, 1.0f);
}
