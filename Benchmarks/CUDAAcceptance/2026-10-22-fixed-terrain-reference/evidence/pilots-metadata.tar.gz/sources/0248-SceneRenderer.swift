import BlastCore
import CoreGraphics
import Foundation
import Metal
import simd

public enum DisplayMode: Int, CaseIterable, Identifiable, Sendable {
    case overpressure = 0
    case peakOverpressure = 1
    case impulse = 2

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .overpressure: "Overpressure now"
        case .peakOverpressure: "Peak overpressure"
        case .impulse: "Impulse"
        }
    }

    public var unit: String { self == .impulse ? "kPa·ms" : "kPa" }
}

/// What of the fireball's thermal radiation is painted onto the surfaces in place of the blast's
/// field: the fluence and the peak irradiance on a log scale over four decades, 0.1 to 1,000 kJ/m²
/// and kW/m²; the peak surface temperature's rise on one over three, 1 to 1,000 K; and the
/// receivers past a test threshold for igniting their material, illustratively.
public enum ThermalQuantity: Int, CaseIterable, Identifiable, Sendable {
    case fluence = 0
    case peakIrradiance = 1
    case surfaceTemperature = 2
    case ignition = 3

    public var id: Int { rawValue }

    public var title: String {
        switch self {
        case .fluence: "Thermal fluence"
        case .peakIrradiance: "Peak irradiance"
        case .surfaceTemperature: "Peak surface temperature"
        case .ignition: "Ignition (illustrative)"
        }
    }

    public var unit: String {
        switch self {
        case .fluence: "kJ/m²"
        case .peakIrradiance: "kW/m²"
        case .surfaceTemperature: "K above ambient"
        case .ignition: ""
        }
    }

    /// The labels at each decade of the scale, lowest first, in `unit`; none for the ignition.
    public var ticks: [String] {
        switch self {
        case .fluence, .peakIrradiance:
            (0...Int(Self.decades)).map { step in
                let value = Double(Self.scaleBottom) / 1000 * pow(10, Double(step))
                return value >= 1 ? String(format: "%.0f", value) : String(format: "%.1f", value)
            }
        case .surfaceTemperature: ["1", "10", "100", "1000"]
        case .ignition: []
        }
    }

    /// A value on this quantity's scale, from 0 at its bottom to 1 at its top: J/m² or W/m², a
    /// rise in kelvin, or `IgnitionFlags`' raw value.
    public func shade(_ value: Float) -> Float {
        switch self {
        case .fluence, .peakIrradiance: Self.shade(value)
        case .surfaceTemperature: min(max(log10(max(value, 1e-6)) / 3, 0), 1)
        case .ignition: Self.ignitionShade(UInt8(max(0, min(value, 255))))
        }
    }

    /// Past the short-pulse fluence, the top of the scale; hot enough alone, part of the way.
    public static func ignitionShade(_ flags: UInt8) -> Float {
        flags & 2 != 0 ? 1 : (flags & 1 != 0 ? 0.55 : 0)
    }

    /// The scale's bottom and top in SI units, J/m² or W/m², and its decades.
    public static let scaleBottom: Float = 100
    public static let decades: Float = 4

    /// A value in J/m² or W/m² on the scale, from 0 at its bottom to 1 at its top.
    public static func shade(_ value: Float) -> Float {
        min(max(log10(max(value, 1e-6) / scaleBottom) / decades, 0), 1)
    }
}

/// Values painted onto the scene's surfaces, each surface a grid of them interpolated between
/// its cells' centres: the thermal radiation's receivers, on the ground and the faces.
public struct SurfacePaint: Sendable, Equatable {
    public struct Patch: Sendable, Equatable {
        /// A corner and the edges from it along which the columns and the rows run, and the
        /// normal out of the surface.
        public var origin: SIMD3<Float>
        public var u: SIMD3<Float>
        public var v: SIMD3<Float>
        public var normal: SIMD3<Float>
        public var columns: Int
        public var rows: Int
        /// Whether it is on the ground, which is shaded as the ground is.
        public var ground: Bool
        /// Where its values start in `values`, row by row.
        public var first: Int
    }

    public var patches: [Patch] = []
    /// From 0 to 1 on the colour scale.
    public var values: [Float] = []

    public init() {}

    /// Each grid painted with `shades`, one for each of the scene's receivers, those at cells
    /// with none filled from their neighbours; grids with no receiver are left out.
    public init(grids: [ThermalSurfaceGrid], shades: [Float]) {
        for grid in grids {
            guard let filled = grid.filled({ shades[$0] }) else { continue }
            patches.append(
                Patch(
                    origin: grid.origin, u: grid.u, v: grid.v, normal: grid.normal, columns: grid.columns,
                    rows: grid.rows, ground: grid.surface == "ground", first: values.count))
            values += filled
        }
    }
}

public struct RenderSettings: Sendable, Hashable {
    /// Field painted onto the ground and the blocks.
    public var mode: DisplayMode = .peakOverpressure
    /// Top of the surface colour scale, in kPa.
    public var pressureScale: Float = 300
    /// Top of the surface colour scale in impulse mode, in kPa ms (equal to Pa s).
    public var impulseScale: Float = 1000
    /// Pressure jump across one cell, in kPa, at which the blast wave in the air is drawn brightest.
    public var waveScale: Float = 30
    /// Decades spanned by the logarithmic colour scales.
    public var decades: Float = 2
    public var showWave = true
    public var waveOpacity: Float = 0.3
    public var showCharge = true
    /// Where to draw the charge, when it is not where the loaded scene has it: being dragged.
    public var chargeAt: SIMD3<Float>?
    /// Fragments in flight and where they landed, and tracers, when a run flies them.
    public var showFragments = true
    public var showTracers = true
    /// Ground points where the ground's shaking is estimated, when the project has any.
    public var showGroundPoints = true
    /// The thermal radiation painted onto the surfaces in place of `mode`'s field, when a run
    /// reckons it; nil for the blast's.
    public var thermal: ThermalQuantity?
    /// Their dots' diameter on screen, in points, whatever their true size.
    public var dotSize: Float = 5
    /// Where the fireball's cloud went, when a run follows it.
    public var showCloud = true
    /// The hazardous fragment distance on the ground, when a run's fragments have landed.
    public var showHazard = true
    /// The safety standards' K-factor distances, the minimum safe distance and the run's injury
    /// contours at standing height.
    public var showBlastHazards = true
    /// A box to outline in the view, such as the one being edited.
    public var highlight: Box?
    /// Craters to shade into the ground (see `CraterMark`), up to four, once a run has dug them.
    public var craters: [CraterMark] = []

    public init() {}

    public var surfaceScale: Float { mode == .impulse ? impulseScale : pressureScale }
}

/// A crater as the view shades it into the ground: its centre in the plane, the apparent crater's
/// radius and depth, and its lip's height and reach (see `CraterEstimate`).
public struct CraterMark: Sendable, Hashable {
    public var centre: SIMD2<Float>
    public var radius: Float
    public var depth: Float
    public var lipHeight: Float
    public var lipCrestRadius: Float
    public var lipRadius: Float

    public init(_ crater: CraterEstimate) {
        centre = SIMD2(crater.centre.x, crater.centre.y)
        radius = crater.apparentRadius
        depth = crater.apparentDepth
        lipHeight = crater.lipHeight
        lipCrestRadius = crater.lipCrestRadius
        lipRadius = crater.lipRadius
    }
}

/// Layout matches `RenderUniforms` in `Render.metal`.
private struct RenderUniforms {
    var eye: SIMD4<Float>
    var right: SIMD4<Float>
    var up: SIMD4<Float>
    var forward: SIMD4<Float>
    var domain: SIMD4<Float>
    var display: SIMD4<Float>
    var counts: SIMD4<Float>
    var charge: SIMD4<Float>
    var sun: SIMD4<Float>
    var clip: SIMD4<Float>
    var highlightLow: SIMD4<Float>
    var highlightHigh: SIMD4<Float>
    /// Up to four craters: centre, radius and depth, then lip height, reach and 1 where one is.
    var craters: (SIMD4<Float>, SIMD4<Float>, SIMD4<Float>, SIMD4<Float>)
    var lips: (SIMD4<Float>, SIMD4<Float>, SIMD4<Float>, SIMD4<Float>)
}

/// Layout matches `MeshUniforms` in `Render.metal`.
private struct MeshUniforms {
    var eye: SIMD4<Float>
    var right: SIMD4<Float>
    var up: SIMD4<Float>
    var forward: SIMD4<Float>
    var projection: SIMD4<Float>
    var lattice: SIMD4<Float>
    var dims: SIMD4<Float>
    var sun: SIMD4<Float>
}

/// Layout matches `TerrainMesh` in `Render.metal`.
private struct TerrainMesh {
    var grid: SIMD4<Float>
    var dims: SIMD4<UInt32>
}

/// Draws a scenario, its deformable structure and the blast's field, from a `SceneViewState`:
/// a solver's own on this Mac, or one kept up to date from a run elsewhere.
///
/// A frame takes two passes: the scene and the structure's mesh go into an offscreen colour and
/// depth target, then the blast wave is ray-marched over them into the destination.
public final class SceneRenderer {
    /// Blocks drawn: as many as a scene holds. Beyond `gridBoxes` the shader finds them through a
    /// grid of columns over their footprints (`BoxGrid`) rather than testing every one.
    /// Binds a material palette (`MaterialAppearance.palette`) for the structure's vertex
    /// shaders, always `MaterialAppearance.paletteSize` colours.
    static func setPalette(_ palette: [SIMD4<Float>], on encoder: MTLRenderCommandEncoder, index: Int = 7) {
        var colours = Array(palette.prefix(MaterialAppearance.paletteSize))
        while colours.count < MaterialAppearance.paletteSize {
            colours.append(MaterialAppearance.concrete.colour)
        }
        encoder.setVertexBytes(
            colours, length: MemoryLayout<SIMD4<Float>>.stride * colours.count, index: index)
    }

    public static let maxBoxes = Scenario.maximumRigidBoxes
    public static let pixelFormat = MTLPixelFormat.bgra8Unorm
    private static let depthFormat = MTLPixelFormat.depth32Float
    private static let nearPlane: Float = 0.5
    /// Far enough for a cloud carried kilometres downwind.
    private static let farPlane: Float = 20_000

    public let device: MTLDevice
    public var settings = RenderSettings()

    private let scenePipeline: MTLRenderPipelineState
    private let meshPipeline: MTLRenderPipelineState
    private let shellPipeline: MTLRenderPipelineState
    private let beamPipeline: MTLRenderPipelineState
    private let glassPipeline: MTLRenderPipelineState
    private let dotPipeline: MTLRenderPipelineState
    private let paintPipeline: MTLRenderPipelineState
    private let linePipeline: MTLRenderPipelineState
    private var lineBuffer: MTLBuffer?
    private var lineCount = 0
    private var paintPatches: MTLBuffer?
    private var paintValues: MTLBuffer?
    private var paintCount = 0
    /// The ground's patch among them, which a terrain wears.
    private var paintGround: Int?
    /// Whether the terrain's nodes cover the domain's floor, so that it alone shows the ground.
    private var terrainCoversFloor = false
    private var dotBuffer: MTLBuffer?
    private var dotCount = 0
    private let freestandingPipeline: MTLRenderPipelineState
    private let terrainPipeline: MTLRenderPipelineState
    private var terrainHeights: MTLBuffer?
    private var terrainMesh: TerrainMesh?
    private var freestandingBuffer: MTLBuffer?
    private var freestandingCount = 0
    private let compositePipeline: MTLRenderPipelineState
    private let sceneDepthState: MTLDepthStencilState
    private let meshDepthState: MTLDepthStencilState
    /// Tested against what is drawn but not written, for glass.
    private let glassDepthState: MTLDepthStencilState
    private let boxBuffer: MTLBuffer
    /// The blocks in columns (Render.metal's `BoxGrid`): each column's first entry in `gridItems`.
    private var grid = BoxGrid(frame: .zero, dims: .zero)
    /// The most blocks tested one by one; read when a scene is set.
    var gridBoxes = 256
    private var gridStarts: MTLBuffer?
    private var gridItems: MTLBuffer?
    private let gaugeBuffer: MTLBuffer
    private var boxCount = 0
    private var ventPanels: [Box] = []
    /// The far buildings' blocks, each with its damage code and its look.
    private var farBlocks: [(Box, Float, Float)] = []
    /// The scenario's blocks, at the start of the box buffer; closed vent panels follow them.
    private var rigidBoxCount = 0
    private var gaugeCount = 0
    private var scenario: Scenario?
    /// The field's cell edge, not necessarily the solver's.
    private var cellSize: Float = 1
    private var field: MTLTexture?
    private var bodies: [SceneViewState.Body] = []
    private var ambientPressure: Float = 101_325
    private var colourTarget: MTLTexture?
    private var depthTarget: MTLTexture?

    public init(device: MTLDevice) throws {
        self.device = device
        guard
            let url = Bundle.module.url(
                forResource: "Render", withExtension: "metal", subdirectory: "Shaders")
        else {
            throw BlastError.missingShader("Render.metal")
        }
        let library = try device.makeLibrary(source: String(contentsOf: url, encoding: .utf8), options: nil)
        func pipeline(vertex: String, fragment: String, depth: Bool, blended: Bool = false) throws
            -> MTLRenderPipelineState
        {
            let descriptor = MTLRenderPipelineDescriptor()
            descriptor.vertexFunction = library.makeFunction(name: vertex)
            descriptor.fragmentFunction = library.makeFunction(name: fragment)
            descriptor.colorAttachments[0].pixelFormat = Self.pixelFormat
            if blended {
                let attachment = descriptor.colorAttachments[0]!
                attachment.isBlendingEnabled = true
                attachment.sourceRGBBlendFactor = .sourceAlpha
                attachment.destinationRGBBlendFactor = .oneMinusSourceAlpha
                attachment.sourceAlphaBlendFactor = .one
                attachment.destinationAlphaBlendFactor = .oneMinusSourceAlpha
            }
            if depth {
                descriptor.depthAttachmentPixelFormat = Self.depthFormat
            }
            return try device.makeRenderPipelineState(descriptor: descriptor)
        }
        scenePipeline = try pipeline(vertex: "fullscreenVertex", fragment: "sceneFragment", depth: true)
        meshPipeline = try pipeline(vertex: "structureVertex", fragment: "structureFragment", depth: true)
        shellPipeline = try pipeline(vertex: "shellVertex", fragment: "structureFragment", depth: true)
        beamPipeline = try pipeline(vertex: "beamVertex", fragment: "structureFragment", depth: true)
        glassPipeline = try pipeline(
            vertex: "shellVertex", fragment: "glassFragment", depth: true, blended: true)
        dotPipeline = try pipeline(vertex: "dotVertex", fragment: "dotFragment", depth: true)
        freestandingPipeline = try pipeline(
            vertex: "freestandingVertex", fragment: "freestandingFragment", depth: true)
        paintPipeline = try pipeline(vertex: "paintVertex", fragment: "paintFragment", depth: true)
        terrainPipeline = try pipeline(vertex: "terrainVertex", fragment: "terrainFragment", depth: true)
        linePipeline = try pipeline(vertex: "lineVertex", fragment: "lineFragment", depth: true)
        compositePipeline = try pipeline(
            vertex: "fullscreenVertex", fragment: "compositeFragment", depth: false)

        func depthState(_ compare: MTLCompareFunction, writes: Bool = true) throws -> MTLDepthStencilState {
            let descriptor = MTLDepthStencilDescriptor()
            descriptor.depthCompareFunction = compare
            descriptor.isDepthWriteEnabled = writes
            guard let state = device.makeDepthStencilState(descriptor: descriptor) else {
                throw BlastError.allocationFailed("depth state")
            }
            return state
        }
        sceneDepthState = try depthState(.always)
        meshDepthState = try depthState(.less)
        glassDepthState = try depthState(.less, writes: false)

        let vectorStride = MemoryLayout<SIMD4<Float>>.stride
        guard
            let boxes = device.makeBuffer(
                length: Self.maxBoxes * 2 * vectorStride, options: .storageModeShared),
            let gauges = device.makeBuffer(
                length: BlastSolver.maxGauges * vectorStride, options: .storageModeShared)
        else {
            throw BlastError.allocationFailed("scene buffers")
        }
        boxBuffer = boxes
        gaugeBuffer = gauges
    }

    /// Points the renderer at a scenario and the solver simulating it on this Mac.
    public func setScene(_ scenario: Scenario, solver: BlastSolver) {
        setScene(scenario, view: SceneViewState(solver: solver))
    }

    /// Points the renderer at a scenario and the view of its run, here or elsewhere.
    public func setScene(_ scenario: Scenario, view: SceneViewState) {
        self.scenario = scenario
        setView(view)
        ambientPressure = scenario.atmosphere.pressure

        rigidBoxCount = min(scenario.rigidBoxes.count, Self.maxBoxes)
        let boxes = boxBuffer.contents().bindMemory(to: SIMD4<Float>.self, capacity: Self.maxBoxes * 2)
        for (n, box) in scenario.rigidBoxes.prefix(rigidBoxCount).enumerated() {
            boxes[2 * n] = SIMD4(box.min, 0)
            boxes[2 * n + 1] = SIMD4(box.max, 0)
        }
        // Exposure-only buildings' blocks, after the scenario's own, drawn by their walls'
        // construction (`MaterialAppearance.blockCode`, in the high corner's w).
        var index = scenario.boxes.count
        for object in scenario.envelopeObjects {
            let code = MaterialAppearance(scenario.envelopeConstruction(for: object.id).walls).blockCode
            for _ in object.envelope!.blocks where index < rigidBoxCount {
                boxes[2 * index + 1].w = code
                index += 1
            }
        }
        setTerrain(scenario.terrain)
        setVentPanels((scenario.ventPanels ?? []).filter { $0.releasePressure > 0 }.map(\.box))
        gaugeCount = min(scenario.gauges.count, BlastSolver.maxGauges)
        let gauges = gaugeBuffer.contents().bindMemory(to: SIMD4<Float>.self, capacity: BlastSolver.maxGauges)
        for (n, gauge) in scenario.gauges.prefix(gaugeCount).enumerated() {
            gauges[n] = SIMD4(gauge.position, 0.35)
        }
    }

    /// Draws from `view` from the next frame on, for the same scenario.
    public func setView(_ view: SceneViewState) {
        cellSize = view.fieldCellSize
        field = view.field
        bodies = view.bodies
    }

    /// Colours each envelope's blocks by its damage: `codes[id]` 1 for none, 2 for glass broken
    /// alone, 3 to 6 for moderate, heavy, hazardous and failed (`EnvelopeDamageLevel` + 2);
    /// envelopes without a code, and every other block, keep the plain colour.
    public func setEnvelopeDamage(_ codes: [UUID: Int]) {
        guard let scenario else { return }
        let boxes = boxBuffer.contents().bindMemory(to: SIMD4<Float>.self, capacity: Self.maxBoxes * 2)
        var index = scenario.boxes.count
        for object in scenario.envelopeObjects {
            let code = Float(codes[object.id] ?? 0)
            for _ in object.envelope!.blocks where index < rigidBoxCount {
                boxes[2 * index].w = code
                index += 1
            }
        }
    }

    /// The vent panels still closed, drawn as blocks after the scenario's own.
    public func setVentPanels(_ panels: [Box]) {
        ventPanels = panels
        writeAppendedBoxes()
    }

    /// A district's far buildings (`FarFieldSet`), drawn after the scenario's blocks and its vent
    /// panels, outside its domain: by their walls' construction, or coloured by `damage[id]` as
    /// `setEnvelopeDamage` colours the scenario's own once the far field has judged them.
    public func setFarField(_ set: FarFieldSet?, damage: [UUID: Int] = [:]) {
        farBlocks = (set?.buildings ?? []).flatMap { building -> [(Box, Float, Float)] in
            let look = MaterialAppearance(set!.construction(for: building.id).walls).blockCode
            let code = Float(damage[building.id] ?? 0)
            return building.envelope.blocks.map { ($0, code, look) }
        }
        writeAppendedBoxes()
    }

    /// The blocks after the scenario's own: the vent panels, then the far buildings', as many as fit.
    private func writeAppendedBoxes() {
        let boxes = boxBuffer.contents().bindMemory(to: SIMD4<Float>.self, capacity: Self.maxBoxes * 2)
        var index = rigidBoxCount
        for box in ventPanels where index < Self.maxBoxes {
            boxes[2 * index] = SIMD4(box.min, 0)
            boxes[2 * index + 1] = SIMD4(box.max, 0)
            index += 1
        }
        for (box, code, look) in farBlocks where index < Self.maxBoxes {
            boxes[2 * index] = SIMD4(box.min, code)
            boxes[2 * index + 1] = SIMD4(box.max, look)
            index += 1
        }
        boxCount = index
        buildGrid()
    }

    /// Lays the blocks into columns, about two a block along each side and at most 1,024: each
    /// block listed in every column its footprint touches.
    private func buildGrid() {
        grid = BoxGrid(frame: .zero, dims: .zero)
        guard boxCount > gridBoxes else { return }
        let boxes = boxBuffer.contents().bindMemory(to: SIMD4<Float>.self, capacity: Self.maxBoxes * 2)
        var low = SIMD2<Float>(repeating: .greatestFiniteMagnitude)
        var high = -low
        var top = -Float.greatestFiniteMagnitude
        for n in 0..<boxCount {
            low = simd_min(low, SIMD2(boxes[2 * n].x, boxes[2 * n].y))
            high = simd_max(high, SIMD2(boxes[2 * n + 1].x, boxes[2 * n + 1].y))
            top = max(top, boxes[2 * n + 1].z)
        }
        let extent = simd_max(high - low, SIMD2(repeating: 1e-3))
        let across = min(1024, max(16, Int((2 * Double(boxCount).squareRoot()).rounded(.up))))
        let target = max(extent.x, extent.y) / Float(across)
        let columns = simd_min(SIMD2(repeating: 1024), SIMD2<Int>((extent / target).rounded(.up)))
        // As wide as covers the blocks in that many columns.
        let width = max(extent.x / Float(columns.x), extent.y / Float(columns.y))
        func span(_ n: Int) -> (SIMD2<Int>, SIMD2<Int>) {
            let a = SIMD2<Int>(((SIMD2(boxes[2 * n].x, boxes[2 * n].y) - low) / width).rounded(.down))
            let b = SIMD2<Int>(((SIMD2(boxes[2 * n + 1].x, boxes[2 * n + 1].y) - low) / width).rounded(.down))
            return (simd_clamp(a, .zero, columns &- 1), simd_clamp(b, .zero, columns &- 1))
        }
        var counts = [UInt32](repeating: 0, count: columns.x * columns.y + 1)
        for n in 0..<boxCount {
            let (a, b) = span(n)
            for j in a.y...b.y { for i in a.x...b.x { counts[i + columns.x * j + 1] += 1 } }
        }
        for c in 1..<counts.count { counts[c] += counts[c - 1] }
        var items = [UInt32](repeating: 0, count: Int(counts.last!))
        var fill = counts
        for n in 0..<boxCount {
            let (a, b) = span(n)
            for j in a.y...b.y {
                for i in a.x...b.x {
                    items[Int(fill[i + columns.x * j])] = UInt32(n)
                    fill[i + columns.x * j] += 1
                }
            }
        }
        guard
            let starts = device.makeBuffer(
                bytes: counts, length: counts.count * MemoryLayout<UInt32>.stride, options: .storageModeShared
            ),
            let list = device.makeBuffer(
                bytes: items, length: max(items.count, 1) * MemoryLayout<UInt32>.stride,
                options: .storageModeShared)
        else { return }
        gridStarts = starts
        gridItems = list
        grid = BoxGrid(
            frame: SIMD4(low.x, low.y, width, top), dims: SIMD4(UInt32(columns.x), UInt32(columns.y), 1, 0))
    }

    /// The terrain's mesh, from its heights; none for flat ground, which the ground plane draws.
    private func setTerrain(_ terrain: Terrain?) {
        guard let terrain, !terrain.isFlat else {
            terrainMesh = nil
            terrainHeights = nil
            terrainCoversFloor = false
            return
        }
        terrainHeights = terrain.heights.withUnsafeBytes { bytes in
            bytes.baseAddress.flatMap {
                device.makeBuffer(bytes: $0, length: bytes.count, options: .storageModeShared)
            }
        }
        // Lifted a couple of centimetres, so that where it lies on the floor it is drawn over the
        // ground plane rather than fighting it.
        terrainMesh = TerrainMesh(
            grid: SIMD4(terrain.origin.x, terrain.origin.y, terrain.spacing, 0.02),
            dims: SIMD4(UInt32(terrain.columns), UInt32(terrain.rows), 1, 0))
        let domain = scenario?.domainSize ?? .zero
        terrainCoversFloor =
            terrain.origin.x <= 0 && terrain.origin.y <= 0 && terrain.extent.x >= domain.x
            && terrain.extent.y >= domain.y
    }

    /// Pixels to a point on the screen drawn to, for dots of a size in points.
    public var pixelsPerPoint: Float = 1

    /// Dots to draw over the scene: each a position and a code, its kind (0 a fragment in flight,
    /// 1 a tracer, 2 a fragment's landing, 3 a ground point, 4 a fragment's strike on a judged
    /// target) plus a value from 0 to 1 that colours it (a fragment's speed, a landing's energy,
    /// how fast the ground under a point has moved, a strike's outcome: under ⅓ stopped, under ⅔
    /// spalled, above through).
    /// The first four craters packed for `RenderUniforms`, empty slots zero.
    private static func craterSlots(_ marks: [CraterMark]) -> (
        craters: (SIMD4<Float>, SIMD4<Float>, SIMD4<Float>, SIMD4<Float>),
        lips: (SIMD4<Float>, SIMD4<Float>, SIMD4<Float>, SIMD4<Float>)
    ) {
        var craters = [SIMD4<Float>](repeating: .zero, count: 4)
        var lips = [SIMD4<Float>](repeating: .zero, count: 4)
        for (n, mark) in marks.prefix(4).enumerated() {
            craters[n] = SIMD4(mark.centre.x, mark.centre.y, mark.radius, mark.depth)
            lips[n] = SIMD4(mark.lipHeight, max(mark.lipRadius, mark.radius), 1, mark.lipCrestRadius)
        }
        return ((craters[0], craters[1], craters[2], craters[3]), (lips[0], lips[1], lips[2], lips[3]))
    }

    public func setDots(_ dots: [SIMD4<Float>]) {
        dotCount = dots.count
        guard !dots.isEmpty else { return }
        let length = dots.count * MemoryLayout<SIMD4<Float>>.stride
        if (dotBuffer?.length ?? 0) < length {
            dotBuffer = device.makeBuffer(length: max(length, 4096) * 2, options: .storageModeShared)
        }
        guard let dotBuffer else {
            dotCount = 0
            return
        }
        dots.withUnsafeBytes { dotBuffer.contents().copyMemory(from: $0.baseAddress!, byteCount: length) }
    }

    /// A freestanding object to draw: an oriented box, a car's shell or a rigid box.
    public struct OrientedBox: Sendable, Hashable {
        public var centre: SIMD3<Float>
        /// Body to world, as a unit quaternion.
        public var orientation: simd_quatf
        public var size: SIMD3<Float>
        public var isCar: Bool

        public init(centre: SIMD3<Float>, orientation: simd_quatf, size: SIMD3<Float>, isCar: Bool) {
            self.centre = centre
            self.orientation = orientation
            self.size = size
            self.isCar = isCar
        }
    }

    /// Freestanding objects to draw over the scene, at their current poses.
    public func setFreestanding(_ boxes: [OrientedBox]) {
        freestandingCount = boxes.count
        guard !boxes.isEmpty else { return }
        let values = boxes.flatMap {
            [SIMD4($0.centre, $0.isCar ? 1 : 0), $0.orientation.vector, SIMD4($0.size / 2, 0)]
        }
        let length = values.count * MemoryLayout<SIMD4<Float>>.stride
        if (freestandingBuffer?.length ?? 0) < length {
            freestandingBuffer = device.makeBuffer(length: max(length, 4096), options: .storageModeShared)
        }
        guard let freestandingBuffer else {
            freestandingCount = 0
            return
        }
        values.withUnsafeBytes {
            freestandingBuffer.contents().copyMemory(from: $0.baseAddress!, byteCount: length)
        }
    }

    /// Lines to draw over the scene, of a width on screen whatever their length: each two vectors,
    /// one end and a kind (0 to 4, as `CloudOverlay.Kind`; 5 to 9, as `HazardOverlay.Kind`; 10, a
    /// building the solver refined, `refinedOutlines`), and the other end and 0. The caller leaves out the kinds its settings hide.
    public func setLines(_ lines: [SIMD4<Float>]) {
        lineCount = lines.count / 2
        guard lineCount > 0 else { return }
        let length = lineCount * 2 * MemoryLayout<SIMD4<Float>>.stride
        if (lineBuffer?.length ?? 0) < length {
            lineBuffer = device.makeBuffer(length: max(length, 4096) * 2, options: .storageModeShared)
        }
        guard let lineBuffer else {
            lineCount = 0
            return
        }
        lines.withUnsafeBytes { lineBuffer.contents().copyMemory(from: $0.baseAddress!, byteCount: length) }
    }

    /// Values to paint onto the surfaces while `settings.thermal` is set; nil for none.
    public func setSurfacePaint(_ paint: SurfacePaint?) {
        paintCount = 0
        paintGround = nil
        guard let paint, !paint.patches.isEmpty else { return }
        paintGround = paint.patches.firstIndex { $0.ground }
        // Four vectors a patch: the origin and its columns, the u edge and its rows, the v edge
        // and where its values start, and the normal and whether it is on the ground.
        let patches = paint.patches.flatMap { patch in
            [
                SIMD4(patch.origin, Float(patch.columns)), SIMD4(patch.u, Float(patch.rows)),
                SIMD4(patch.v, Float(patch.first)), SIMD4(patch.normal, patch.ground ? 1 : 0),
            ]
        }
        func upload<T>(_ array: [T], into buffer: inout MTLBuffer?) -> Bool {
            let length = array.count * MemoryLayout<T>.stride
            if (buffer?.length ?? 0) < length {
                buffer = device.makeBuffer(length: max(length, 4096) * 2, options: .storageModeShared)
            }
            guard let buffer else { return false }
            array.withUnsafeBytes { buffer.contents().copyMemory(from: $0.baseAddress!, byteCount: length) }
            return true
        }
        guard upload(patches, into: &paintPatches), upload(paint.values, into: &paintValues) else { return }
        paintCount = paint.patches.count
    }

    /// Encodes a frame into `descriptor`'s first colour attachment.
    public func encode(
        into commandBuffer: MTLCommandBuffer, descriptor: MTLRenderPassDescriptor, camera: OrbitCamera
    ) {
        guard let scenario, let field, let destination = descriptor.colorAttachments[0].texture,
            let (colourTarget, depthTarget) = targets(width: destination.width, height: destination.height)
        else { return }

        let aspectRatio = Float(destination.width) / Float(max(destination.height, 1))
        let eye = camera.eye
        let forward = simd_normalize(camera.target - eye)
        let right = simd_normalize(simd_cross(forward, SIMD3(0, 0, 1)))
        let up = simd_cross(right, forward)
        let halfHeight = tan(camera.fieldOfView / 2)
        let sun = SIMD4(simd_normalize(SIMD3<Float>(0.35, -0.55, 0.75)), 0)
        // Pressure channels are stored in units of ambient pressure, impulse in Pa s (= kPa ms).
        let kiloPascal = 1000 / ambientPressure
        let surfaceScale =
            settings.mode == .impulse ? settings.impulseScale : settings.pressureScale * kiloPascal
        var uniforms = RenderUniforms(
            eye: SIMD4(eye, 1),
            right: SIMD4(right * halfHeight * aspectRatio, 0),
            up: SIMD4(up * halfHeight, 0),
            forward: SIMD4(forward, 0),
            domain: SIMD4(scenario.domainSize, cellSize),
            display: SIMD4(
                Float(settings.mode.rawValue), surfaceScale, settings.decades,
                settings.showWave ? settings.waveOpacity : 0),
            counts: SIMD4(
                Float(boxCount), Float(gaugeCount), settings.showCharge ? 0.45 : 0,
                settings.waveScale * kiloPascal),
            charge: SIMD4(settings.chargeAt ?? scenario.charge.position, 0),
            sun: sun,
            clip: SIMD4(Self.nearPlane, Self.farPlane, 0, 0),
            highlightLow: SIMD4(settings.highlight?.min ?? .zero, settings.highlight == nil ? 0 : 1),
            highlightHigh: SIMD4(settings.highlight?.max ?? .zero, 0),
            craters: Self.craterSlots(settings.craters).craters, lips: Self.craterSlots(settings.craters).lips
        )

        // Pass 1: ground, blocks and markers, then the structure's mesh, sharing a depth buffer.
        let scenePass = MTLRenderPassDescriptor()
        scenePass.colorAttachments[0].texture = colourTarget
        scenePass.colorAttachments[0].loadAction = .dontCare
        scenePass.colorAttachments[0].storeAction = .store
        scenePass.depthAttachment.texture = depthTarget
        scenePass.depthAttachment.loadAction = .clear
        scenePass.depthAttachment.clearDepth = 1
        scenePass.depthAttachment.storeAction = .store
        guard let sceneEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: scenePass) else { return }
        sceneEncoder.setRenderPipelineState(scenePipeline)
        sceneEncoder.setDepthStencilState(sceneDepthState)
        sceneEncoder.setFragmentBytes(&uniforms, length: MemoryLayout<RenderUniforms>.stride, index: 0)
        sceneEncoder.setFragmentBuffer(boxBuffer, offset: 0, index: 1)
        sceneEncoder.setFragmentBuffer(gaugeBuffer, offset: 0, index: 2)
        sceneEncoder.setFragmentBytes(&grid, length: MemoryLayout<BoxGrid>.stride, index: 3)
        if grid.dims.z != 0, let gridStarts, let gridItems {
            sceneEncoder.setFragmentBuffer(gridStarts, offset: 0, index: 4)
            sceneEncoder.setFragmentBuffer(gridItems, offset: 0, index: 5)
        } else {
            // Unread, but bound.
            sceneEncoder.setFragmentBytes([UInt32](repeating: 0, count: 4), length: 16, index: 4)
            sceneEncoder.setFragmentBytes([UInt32](repeating: 0, count: 4), length: 16, index: 5)
        }
        sceneEncoder.setFragmentTexture(field, index: 0)
        sceneEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)

        if var terrain = terrainMesh, let terrainHeights {
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: .zero, sun: sun)
            // Tinted by the blast's field, or, while the thermal radiation is shown, painted with the
            // ground's receivers' values (`dims.w` one more than their patch).
            terrain.dims.z = settings.thermal == nil ? 1 : 0
            let groundPaint = settings.thermal != nil && paintCount > 0 ? paintGround : nil
            terrain.dims.w = groundPaint.map { UInt32($0 + 1) } ?? 0
            sceneEncoder.setRenderPipelineState(terrainPipeline)
            sceneEncoder.setDepthStencilState(meshDepthState)
            sceneEncoder.setCullMode(.none)
            sceneEncoder.setVertexBuffer(terrainHeights, offset: 0, index: 0)
            sceneEncoder.setVertexBytes(&terrain, length: MemoryLayout<TerrainMesh>.stride, index: 1)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 2)
            sceneEncoder.setFragmentBytes(&uniforms, length: MemoryLayout<RenderUniforms>.stride, index: 0)
            sceneEncoder.setFragmentBytes(&terrain, length: MemoryLayout<TerrainMesh>.stride, index: 1)
            sceneEncoder.setFragmentTexture(field, index: 0)
            if groundPaint != nil, let paintPatches, let paintValues {
                sceneEncoder.setFragmentBuffer(paintPatches, offset: 0, index: 2)
                sceneEncoder.setFragmentBuffer(paintValues, offset: 0, index: 3)
            } else {
                // Unread, but bound.
                sceneEncoder.setFragmentBytes([Float](repeating: 0, count: 16), length: 64, index: 2)
                sceneEncoder.setFragmentBytes([Float](repeating: 0, count: 4), length: 16, index: 3)
            }
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 6,
                instanceCount: (Int(terrain.dims.x) - 1) * (Int(terrain.dims.y) - 1))
        }

        var transparentBodies: [SceneViewState.Shells] = []
        for body in bodies {
            if let structure = body.solids, structure.elementCount > 0 {
                var mesh = MeshUniforms(
                    eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                    projection: SIMD4(
                        1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                    lattice: SIMD4(structure.origin, structure.elementSize),
                    dims: SIMD4(
                        Float(structure.ex), Float(structure.ey), Float(structure.ez),
                        Float(structure.stateStride / 4)),
                    sun: sun)
                sceneEncoder.setRenderPipelineState(meshPipeline)
                sceneEncoder.setDepthStencilState(meshDepthState)
                sceneEncoder.setCullMode(.none)
                sceneEncoder.setVertexBuffer(structure.instances, offset: 0, index: 0)
                sceneEncoder.setVertexBuffer(structure.nodes, offset: 0, index: 1)
                sceneEncoder.setVertexBuffer(structure.flags, offset: 0, index: 2)
                sceneEncoder.setVertexBuffer(structure.states, offset: 0, index: 3)
                sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 4)
                sceneEncoder.setVertexBuffer(structure.nodeMap, offset: 0, index: 5)
                // Each element's material, and its colour (`MaterialAppearance`).
                var indexed: UInt32 = structure.materialIndex == nil ? 0 : 1
                if let materialIndex = structure.materialIndex {
                    sceneEncoder.setVertexBuffer(materialIndex, offset: 0, index: 6)
                } else {
                    sceneEncoder.setVertexBytes([UInt32](repeating: 0, count: 4), length: 16, index: 6)
                }
                Self.setPalette(structure.palette, on: sceneEncoder)
                sceneEncoder.setVertexBytes(&indexed, length: 4, index: 8)
                sceneEncoder.setFragmentBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 0)
                sceneEncoder.drawPrimitives(
                    type: .triangle, vertexStart: 0, vertexCount: 36, instanceCount: structure.elementCount)
            }
            if let shells = body.shells, shells.elementCount + shells.beamCount > 0 {
                var mesh = MeshUniforms(
                    eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                    projection: SIMD4(
                        1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                    lattice: .zero, dims: .zero, sun: sun)
                sceneEncoder.setRenderPipelineState(shellPipeline)
                sceneEncoder.setDepthStencilState(meshDepthState)
                sceneEncoder.setCullMode(.none)
                sceneEncoder.setVertexBuffer(shells.elements, offset: 0, index: 0)
                sceneEncoder.setVertexBuffer(shells.nodes, offset: 0, index: 1)
                sceneEncoder.setVertexBuffer(shells.flags, offset: 0, index: 2)
                sceneEncoder.setVertexBuffer(shells.damage, offset: 0, index: 3)
                sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 4)
                sceneEncoder.setVertexBuffer(shells.reference, offset: 0, index: 5)
                sceneEncoder.setFragmentBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 0)
                Self.setPalette(shells.palette, on: sceneEncoder, index: 8)
                // Glass is drawn last, over everything opaque (below).
                var transparent = shells.transparentMaterials
                var draw: UInt32 = transparent == 0 ? 0 : 1
                sceneEncoder.setVertexBytes(&transparent, length: 4, index: 6)
                sceneEncoder.setVertexBytes(&draw, length: 4, index: 7)
                if shells.elementCount > 0 {
                    sceneEncoder.drawPrimitives(
                        type: .triangle, vertexStart: 0, vertexCount: 36, instanceCount: shells.elementCount)
                }
                if transparent != 0 && shells.elementCount > 0 { transparentBodies.append(shells) }
                if shells.beamCount > 0 {
                    sceneEncoder.setRenderPipelineState(beamPipeline)
                    sceneEncoder.setVertexBuffer(shells.beams, offset: 0, index: 0)
                    sceneEncoder.setVertexBuffer(shells.beamFlags, offset: 0, index: 2)
                    sceneEncoder.setVertexBuffer(shells.beamDamage, offset: 0, index: 3)
                    sceneEncoder.drawPrimitives(
                        type: .triangle, vertexStart: 0, vertexCount: 36, instanceCount: shells.beamCount)
                }
            }
        }
        if freestandingCount > 0, let freestandingBuffer {
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: .zero, sun: sun)
            sceneEncoder.setRenderPipelineState(freestandingPipeline)
            sceneEncoder.setDepthStencilState(meshDepthState)
            sceneEncoder.setCullMode(.none)
            sceneEncoder.setVertexBuffer(freestandingBuffer, offset: 0, index: 0)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 1)
            sceneEncoder.setFragmentBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 0)
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 36, instanceCount: freestandingCount)
        }
        if settings.thermal != nil, paintCount > 0, let paintPatches, let paintValues {
            // Over a terrain that covers the floor, the terrain wears the ground's paint (above).
            let groundOnTerrain: Float = terrainMesh != nil && terrainCoversFloor ? 1 : 0
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: SIMD4(groundOnTerrain, 0, 0, 0), sun: sun)
            sceneEncoder.setRenderPipelineState(paintPipeline)
            sceneEncoder.setDepthStencilState(meshDepthState)
            sceneEncoder.setCullMode(.none)
            sceneEncoder.setVertexBuffer(paintPatches, offset: 0, index: 0)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 1)
            sceneEncoder.setFragmentBuffer(paintPatches, offset: 0, index: 0)
            sceneEncoder.setFragmentBuffer(paintValues, offset: 0, index: 1)
            sceneEncoder.setFragmentBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 2)
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 6, instanceCount: paintCount)
        }
        if dotCount > 0, let dotBuffer {
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: .zero, sun: sun)
            // The dot's size in pixels: points scaled as the drawable is to the view.
            var viewport = SIMD4<Float>(
                Float(destination.width), Float(destination.height), settings.dotSize * pixelsPerPoint, 0)
            sceneEncoder.setRenderPipelineState(dotPipeline)
            sceneEncoder.setDepthStencilState(meshDepthState)
            sceneEncoder.setVertexBuffer(dotBuffer, offset: 0, index: 0)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 1)
            sceneEncoder.setVertexBytes(&viewport, length: MemoryLayout<SIMD4<Float>>.stride, index: 2)
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 6, instanceCount: dotCount)
        }
        if lineCount > 0, let lineBuffer {
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: .zero, sun: sun)
            var viewport = SIMD4<Float>(
                Float(destination.width), Float(destination.height), pixelsPerPoint, 0)
            sceneEncoder.setRenderPipelineState(linePipeline)
            sceneEncoder.setDepthStencilState(meshDepthState)
            sceneEncoder.setVertexBuffer(lineBuffer, offset: 0, index: 0)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 1)
            sceneEncoder.setVertexBytes(&viewport, length: MemoryLayout<SIMD4<Float>>.stride, index: 2)
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 6, instanceCount: lineCount)
        }
        for glass in transparentBodies {
            sceneEncoder.setRenderPipelineState(glassPipeline)
            sceneEncoder.setDepthStencilState(glassDepthState)
            var mesh = MeshUniforms(
                eye: SIMD4(eye, 1), right: SIMD4(right, 0), up: SIMD4(up, 0), forward: SIMD4(forward, 0),
                projection: SIMD4(
                    1 / (halfHeight * aspectRatio), 1 / halfHeight, Self.nearPlane, Self.farPlane),
                lattice: .zero, dims: .zero, sun: sun)
            var transparent = glass.transparentMaterials
            sceneEncoder.setVertexBuffer(glass.nodes, offset: 0, index: 1)
            sceneEncoder.setVertexBuffer(glass.reference, offset: 0, index: 5)
            sceneEncoder.setVertexBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 4)
            sceneEncoder.setFragmentBytes(&mesh, length: MemoryLayout<MeshUniforms>.stride, index: 0)
            sceneEncoder.setVertexBytes(&transparent, length: 4, index: 6)
            Self.setPalette(glass.palette, on: sceneEncoder, index: 8)
            sceneEncoder.setVertexBuffer(glass.elements, offset: 0, index: 0)
            sceneEncoder.setVertexBuffer(glass.flags, offset: 0, index: 2)
            sceneEncoder.setVertexBuffer(glass.damage, offset: 0, index: 3)
            var draw: UInt32 = 2
            sceneEncoder.setVertexBytes(&draw, length: 4, index: 7)
            sceneEncoder.drawPrimitives(
                type: .triangle, vertexStart: 0, vertexCount: 36, instanceCount: glass.elementCount)
        }
        sceneEncoder.endEncoding()

        // Pass 2: the blast wave over the finished scene.
        guard let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor) else { return }
        encoder.setRenderPipelineState(compositePipeline)
        encoder.setFragmentBytes(&uniforms, length: MemoryLayout<RenderUniforms>.stride, index: 0)
        encoder.setFragmentTexture(colourTarget, index: 0)
        encoder.setFragmentTexture(depthTarget, index: 1)
        encoder.setFragmentTexture(field, index: 2)
        encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        encoder.endEncoding()
    }

    /// Offscreen colour and depth targets matching the destination, recreated when it resizes.
    private func targets(width: Int, height: Int) -> (MTLTexture, MTLTexture)? {
        if let colourTarget, let depthTarget, colourTarget.width == width, colourTarget.height == height {
            return (colourTarget, depthTarget)
        }
        func texture(_ format: MTLPixelFormat) -> MTLTexture? {
            let descriptor = MTLTextureDescriptor.texture2DDescriptor(
                pixelFormat: format, width: max(width, 1), height: max(height, 1), mipmapped: false)
            descriptor.usage = [.renderTarget, .shaderRead]
            descriptor.storageMode = .private
            return device.makeTexture(descriptor: descriptor)
        }
        guard let colour = texture(Self.pixelFormat), let depth = texture(Self.depthFormat) else {
            return nil
        }
        colourTarget = colour
        depthTarget = depth
        return (colour, depth)
    }

    /// Renders one frame offscreen and returns it, blocking until the GPU has finished.
    public func snapshot(
        commandQueue: MTLCommandQueue, width: Int, height: Int, camera: OrbitCamera
    ) -> (image: CGImage, gpuSeconds: Double)? {
        let textureDescriptor = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: Self.pixelFormat, width: width, height: height, mipmapped: false)
        textureDescriptor.usage = [.renderTarget, .shaderRead]
        textureDescriptor.storageMode = .shared
        guard let target = device.makeTexture(descriptor: textureDescriptor),
            let commandBuffer = commandQueue.makeCommandBuffer()
        else { return nil }

        let pass = MTLRenderPassDescriptor()
        pass.colorAttachments[0].texture = target
        pass.colorAttachments[0].loadAction = .dontCare
        pass.colorAttachments[0].storeAction = .store
        encode(into: commandBuffer, descriptor: pass, camera: camera)
        commandBuffer.commit()
        commandBuffer.waitUntilCompleted()

        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        target.getBytes(
            &pixels, bytesPerRow: width * 4, from: MTLRegionMake2D(0, 0, width, height), mipmapLevel: 0)
        let bitmapInfo = CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.noneSkipFirst.rawValue
        guard let provider = CGDataProvider(data: Data(pixels) as CFData),
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
            let image = CGImage(
                width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: width * 4,
                space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: bitmapInfo), provider: provider,
                decode: nil, shouldInterpolate: false, intent: .defaultIntent)
        else { return nil }
        return (image, commandBuffer.gpuEndTime - commandBuffer.gpuStartTime)
    }
}

/// Render.metal's `BoxGrid`.
struct BoxGrid {
    var frame: SIMD4<Float>
    var dims: SIMD4<UInt32>
}
