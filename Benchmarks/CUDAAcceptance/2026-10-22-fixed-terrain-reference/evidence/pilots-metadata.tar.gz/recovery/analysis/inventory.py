import subprocess,json,base64,shlex
from pathlib import Path
r=Path('/Volumes/StudioData/bombcad/experiments/2026-10-22-fixed-terrain-reference/recovery');jobs=json.loads((r/'jobs.json').read_text())
script='''import base64,json,hashlib
from pathlib import Path
import sys
jobs=json.loads(base64.b64decode(sys.argv[1]));result={}
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
 return dict(sha256=h.hexdigest(),bytes=p.stat().st_size)
for j in jobs:
 for kind in ['current','control']:
  root=Path(j[kind]);assert (root/'out/result.json').is_file()
  items={str(p.relative_to(root)):pin(p) for p in sorted((root/'out').rglob('*')) if p.is_file()}
  for name in ['job.json','columns.bin']+(['inputs.npy','mask.npy','meta.json'] if kind=='control' else []):
   p=root/'input'/name;items['input/'+name]=pin(p)
  result[j['id']+'/'+kind]=dict(remote=j[kind],files=items)
print(json.dumps(result,indent=2))'''
encoded=base64.b64encode(json.dumps(jobs).encode()).decode();command=' '.join(shlex.quote(x) for x in ['python3','-c',script,encoded])
with (r/'remote-inventory.json').open('x') as output:subprocess.run(['ssh','-o','BatchMode=yes','bombcad-pc',command],stdout=output,check=True)
print('Full remote outputs and control templates inventoried')
